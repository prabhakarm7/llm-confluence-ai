// hooks/useGraphData.ts - Complete Updated File for API Integration
import { useState, useEffect, useCallback } from 'react';
import { Node, Edge } from 'reactflow';
import ApiNeo4jService from '../services/ApiNeo4jService'; // 🆕 NEW: Use API service instead of mock
import type { FilterCriteria, FilterOptions } from '../services/MockNeo4jService';
import { AppNodeData, EdgeData } from '../types/GraphTypes';
import dagre from 'dagre';

interface Neo4jNode {
  id: string;
  labels: string[];
  properties: Record<string, any>;
}

interface Neo4jRelationship {
  id: string;
  type: string;
  start_node_id: string;
  end_node_id: string;
  properties: Record<string, any>;
}

interface Neo4jResult {
  nodes: Neo4jNode[];
  relationships: Neo4jRelationship[];
}

// Layout configuration
const NODE_W = 240;
const NODE_H = 120;

const layoutWithDagre = (nodes: Node[], edges: Edge[]) => {
  const g = new dagre.graphlib.Graph();
  g.setDefaultEdgeLabel(() => ({}));
  g.setGraph({ rankdir: 'TB', nodesep: 120, ranksep: 160 });

  nodes.forEach((n) => g.setNode(n.id, { width: NODE_W, height: NODE_H }));
  edges.forEach((e) => g.setEdge(e.source, e.target));
  dagre.layout(g);

  const layoutedNodes = nodes.map((n) => {
    const pos = g.node(n.id);
    return { ...n, position: { x: pos.x - NODE_W / 2, y: pos.y - NODE_H / 2 } };
  });

  return { nodes: layoutedNodes, edges };
};

// Transform Neo4j data to ReactFlow format
const transformNeo4jToReactFlow = (data: Neo4jResult): { nodes: Node<AppNodeData>[], edges: Edge<EdgeData>[] } => {
  console.log('🔄 Starting Neo4j to ReactFlow transformation:', {
    inputNodes: data.nodes.length,
    inputRelationships: data.relationships.length
  });
  
  const nodes: Node<AppNodeData>[] = data.nodes.map(neo4jNode => {
    const reactFlowNode = {
      id: neo4jNode.id,
      type: neo4jNode.labels[0],
      data: {
        ...neo4jNode.properties,
        // Ensure required fields are present
        id: neo4jNode.properties.id || neo4jNode.id,
        name: neo4jNode.properties.name || neo4jNode.id,
        label: neo4jNode.properties.label || neo4jNode.properties.name || neo4jNode.id
      } as AppNodeData,
      position: { x: 0, y: 0 }
    };
    
    console.log(`🔍 Transformed node ${neo4jNode.id}:`, {
      id: reactFlowNode.id,
      type: reactFlowNode.type,
      name: reactFlowNode.data.name,
      hasData: !!reactFlowNode.data
    });
    
    return reactFlowNode;
  });
  
  const edges: Edge<EdgeData>[] = data.relationships.map(rel => {
    const reactFlowEdge = {
      id: rel.id,
      source: rel.start_node_id, // 🆕 UPDATED: Use API response field names
      target: rel.end_node_id,   // 🆕 UPDATED: Use API response field names
      type: 'custom',
      data: {
        relType: rel.type as any,
        ...rel.properties
      } as EdgeData
    };
    
    console.log(`🔗 Transformed edge ${rel.id}:`, {
      id: reactFlowEdge.id,
      source: reactFlowEdge.source,
      target: reactFlowEdge.target,
      relType: reactFlowEdge.data?.relType
    });
    
    return reactFlowEdge;
  });
  
  console.log('✅ Transformation complete:', {
    outputNodes: nodes.length,
    outputEdges: edges.length,
    nodeTypes: Array.from(new Set(nodes.map(n => n.type).filter(Boolean))),
    edgeTypes: Array.from(new Set(edges.map(e => e.data?.relType).filter(Boolean)))
  });
  
  return { nodes, edges };
};

export const useGraphData = () => {
  // Loading states
  const [initialLoading, setInitialLoading] = useState(true);
  const [filterLoading, setFilterLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Data states
  const [currentRegions, setCurrentRegions] = useState<string[]>(['NAI']);
  const [regionData, setRegionData] = useState<Neo4jResult | null>(null);
  const [filterOptions, setFilterOptions] = useState<FilterOptions | null>(null);
  
  // FIXED: Add debug to setGraphData to track when it's called
  const [graphData, setGraphDataInternal] = useState<{ nodes: Node<AppNodeData>[], edges: Edge<EdgeData>[] }>({ 
    nodes: [], 
    edges: [] 
  });
  
  // FIXED: Force state updates with a counter to ensure React detects changes
  const [updateCounter, setUpdateCounter] = useState(0);
  
  const setGraphData = useCallback((newData: { nodes: Node<AppNodeData>[], edges: Edge<EdgeData>[] }) => {
    console.log('🚀 HOOK: setGraphData called with:', {
      nodes: newData.nodes.length,
      edges: newData.edges.length,
      timestamp: Date.now(),
      updateCounter: updateCounter + 1
    });
    
    // Force new object reference with unique properties
    const forceUpdate = {
      nodes: newData.nodes,
      edges: newData.edges,
      _timestamp: Date.now(), // Unique property to force React update
      _updateId: Math.random().toString(36) // Another unique property
    };
    
    setGraphDataInternal(forceUpdate as any);
    setUpdateCounter(prev => prev + 1); // Trigger additional state change
  }, [updateCounter]);
  
  // ✅ FIXED: Current filter state with all properties
  const [currentFilters, setCurrentFilters] = useState<FilterCriteria>({
    regions: ['NAI'],
    nodeTypes: ['CONSULTANT', 'FIELD_CONSULTANT', 'COMPANY', 'PRODUCT', 'INCUMBENT_PRODUCT'],
    showInactive: true,
    sales_regions: [],
    channels: [],
    ratings: [],              // ✅ Changed from rankgroups to ratings
    assetClasses: [],
    consultantIds: [],
    fieldConsultantIds: [],
    clientIds: [],
    productIds: [],
    pcaIds: [],
    acaIds: [],
    mandateStatuses: []
  });
  
  const apiService = ApiNeo4jService.getInstance(); // 🆕 NEW: Use API service instead of mock
  
  /**
   * Step 1: Load region data (happens on mount and when regions change)
   * This is your primary strategy - region drives everything
   */
  const loadRegionData = useCallback(async (regions: string[]) => {
    console.log(`🚀 Loading region data for: ${regions.join(', ')}`);
    setInitialLoading(true);
    setError(null);
    
    try {
      // 🆕 NEW: Test API connection first
      const isConnected = await apiService.testConnection();
      if (!isConnected) {
        throw new Error('Cannot connect to API backend. Make sure the FastAPI server is running on http://localhost:8000');
      }
      
      // Get data for selected regions
      const data = await apiService.getRegionData(regions);
      console.log(`📊 Raw region data loaded:`, {
        totalNodes: data.nodes.length,
        totalRelationships: data.relationships.length,
        nodesByType: {
          consultants: data.nodes.filter(n => n.labels.includes('CONSULTANT')).length,
          fieldConsultants: data.nodes.filter(n => n.labels.includes('FIELD_CONSULTANT')).length,
          companies: data.nodes.filter(n => n.labels.includes('COMPANY')).length,
          products: data.nodes.filter(n => n.labels.includes('PRODUCT')).length,
          incumbentProducts: data.nodes.filter(n => n.labels.includes('INCUMBENT_PRODUCT')).length
        }
      });
      
      // FIXED: Set region data FIRST before trying to apply filters
      setRegionData(data);
      setCurrentRegions(regions);
      
      // Extract filter options from this region data
      const options = await apiService.getFilterOptionsFromData(data);
      setFilterOptions(options);
      
      // ✅ FIXED: Apply inclusive default filters to the region data
      const defaultFilters: FilterCriteria = {
        regions,
        nodeTypes: ['CONSULTANT', 'FIELD_CONSULTANT', 'COMPANY', 'PRODUCT', 'INCUMBENT_PRODUCT'],
        showInactive: true,
        sales_regions: [],
        channels: [],
        ratings: [],              // ✅ Changed from rankgroups to ratings
        assetClasses: [],
        consultantIds: [],
        fieldConsultantIds: [],
        clientIds: [],
        productIds: [],
        pcaIds: [],
        acaIds: [],
        mandateStatuses: []
      };
      
      console.log(`🔧 Applying default filters:`, defaultFilters);
      
      const filteredData = await apiService.applyFiltersToData(data, defaultFilters);
      
      // FIXED: Add error handling for transformation steps
      try {
        // Transform and layout
        const reactFlowData = transformNeo4jToReactFlow(filteredData);
        const layoutedData = layoutWithDagre(reactFlowData.nodes, reactFlowData.edges);
        
        console.log('🎯 Setting graph data from loadRegionData:', {
          nodes: layoutedData.nodes.length,
          edges: layoutedData.edges.length,
          timestamp: Date.now()
        });
        
        // FIXED: Create completely new object with unique reference
        const newGraphData = {
          nodes: layoutedData.nodes.map(n => ({ ...n })), // Deep copy nodes
          edges: layoutedData.edges.map(e => ({ ...e }))  // Deep copy edges
        };
        
        console.log('📄 MAIN COMPONENT TRIGGER: Setting new graphData object from loadRegionData:', {
          objectId: Math.random().toString(36).substr(2, 9),
          nodes: newGraphData.nodes.length,
          edges: newGraphData.edges.length
        });
        
        setGraphData(newGraphData);
        
        // Update current filters to match what was applied
        setCurrentFilters(defaultFilters);
        
        console.log('✅ Region data loaded and processed successfully');
      } catch (transformError) {
        console.error('❌ Error in transformation/layout:', transformError);
        setError('Failed to process graph data');
        // FIXED: Set empty data on transformation failure
        setGraphData({ nodes: [], edges: [] });
      }
      
    } catch (err) {
      console.error('❌ Error loading region data:', err);
      setError(err instanceof Error ? err.message : 'Failed to load region data');
      // FIXED: Clear graph data on error
      setGraphData({ nodes: [], edges: [] });
    } finally {
      setInitialLoading(false);
    }
  }, [apiService]); // 🆕 UPDATED: Depend on apiService instead of mockService
  
  /**
   * Step 2: Handle region changes (triggers reload of everything)
   */
  const changeRegions = useCallback(async (newRegions: string[]) => {
    if (JSON.stringify(newRegions.sort()) === JSON.stringify(currentRegions.sort())) {
      return; // No change
    }
    
    console.log(`📄 Changing regions from ${currentRegions} to ${newRegions}`);
    
    // Clear existing graph data immediately to prevent showing wrong region data
    setGraphData({ nodes: [], edges: [] });
    
    // Load new region data (this will also update currentFilters internally)
    await loadRegionData(newRegions);
  }, [currentRegions, loadRegionData]);
  
  /**
   * Step 3: Apply filters to current region data (when user clicks "Apply Filter")
   * This works on the already-loaded region data
   */
  const applyFilters = useCallback(async (filters: Partial<FilterCriteria>) => {
    console.log('🔧 applyFilters() called with filters:', filters);
    console.log('📊 Current state:', {
      hasRegionData: !!regionData,
      isInitialLoading: initialLoading,
      isFilterLoading: filterLoading
    });
    
    // FIXED: Prevent applying filters during initial load or if already loading
    if (initialLoading || filterLoading) {
      console.warn('⚠️ Cannot apply filters while loading');
      return;
    }
    
    // FIXED: Better error handling and user feedback
    if (!regionData) {
      console.warn('⚠️ No region data available to filter');
      setError('No region data available. Please wait for data to load.');
      return;
    }
    
    setFilterLoading(true);
    setError(null);
    
    try {
      const newFilters: FilterCriteria = {
        regions: currentRegions, // Always use current regions
        nodeTypes: ['CONSULTANT', 'FIELD_CONSULTANT', 'COMPANY', 'PRODUCT', 'INCUMBENT_PRODUCT'],
        showInactive: true,
        sales_regions: [],
        channels: [],
        ratings: [],              // ✅ Changed from rankgroups to ratings
        assetClasses: [],
        consultantIds: [],
        fieldConsultantIds: [],
        clientIds: [],
        productIds: [],
        pcaIds: [],
        acaIds: [],
        mandateStatuses: [],
        ...filters // Apply user filters on top of defaults
      };
      
      console.log('📋 Final filters being applied:', newFilters);
      
      // Apply filters to current region data
      const filteredData = await apiService.applyFiltersToData(regionData, newFilters);
      console.log('📊 Filtered data result:', {
        nodes: filteredData.nodes.length,
        relationships: filteredData.relationships.length,
        nodesByType: {
          consultants: filteredData.nodes.filter(n => n.labels.includes('CONSULTANT')).length,
          fieldConsultants: filteredData.nodes.filter(n => n.labels.includes('FIELD_CONSULTANT')).length,
          companies: filteredData.nodes.filter(n => n.labels.includes('COMPANY')).length,
          products: filteredData.nodes.filter(n => n.labels.includes('PRODUCT')).length,
          incumbentProducts: filteredData.nodes.filter(n => n.labels.includes('INCUMBENT_PRODUCT')).length
        }
      });
      
      // FIXED: Add error handling for transformation steps
      try {
        // Transform and layout
        console.log('📄 Transforming Neo4j data to ReactFlow...');
        const reactFlowData = transformNeo4jToReactFlow(filteredData);
        console.log('✅ ReactFlow transformation complete:', {
          nodes: reactFlowData.nodes.length,
          edges: reactFlowData.edges.length,
          sampleNodes: reactFlowData.nodes.slice(0, 3).map(n => ({
            id: n.id,
            type: n.type,
            name: n.data?.name
          }))
        });
        
        console.log('🔍 Applying layout...');
        const layoutedData = layoutWithDagre(reactFlowData.nodes, reactFlowData.edges);
        console.log('✅ Layout complete:', {
          nodes: layoutedData.nodes.length,
          edges: layoutedData.edges.length,
          samplePositions: layoutedData.nodes.slice(0, 3).map(n => ({
            id: n.id,
            position: n.position
          }))
        });
        
        // FIXED: Update filters BEFORE setting graph data to prevent state conflicts
        setCurrentFilters(newFilters);
        
        // FIXED: Force new object reference to trigger React updates + add timestamp for debugging
        console.log('🎯 Setting graph data from applyFilters:', {
          nodes: layoutedData.nodes.length,
          edges: layoutedData.edges.length,
          timestamp: Date.now()
        });
        
        // FIXED: Create completely new object with unique reference
        const newGraphData = {
          nodes: layoutedData.nodes.map(n => ({ ...n })), // Deep copy nodes
          edges: layoutedData.edges.map(e => ({ ...e }))  // Deep copy edges
        };
        
        console.log('📄 MAIN COMPONENT TRIGGER: Setting new graphData object:', {
          objectId: Math.random().toString(36).substr(2, 9),
          nodes: newGraphData.nodes.length,
          edges: newGraphData.edges.length
        });
        
        setGraphData(newGraphData);
        
        console.log('✅ Filters applied successfully - graph should update now');
        
      } catch (transformError) {
        console.error('❌ Error in transformation/layout during filter application:', transformError);
        setError('Failed to process filtered data');
        // FIXED: Don't clear data on transformation error during filtering
        // Keep existing data visible while showing error
      }
      
    } catch (err) {
      console.error('❌ Error applying filters:', err);
      setError(err instanceof Error ? err.message : 'Failed to apply filters');
    } finally {
      setFilterLoading(false);
    }
  }, [regionData, currentRegions, initialLoading, filterLoading, apiService]); // 🆕 UPDATED: Changed from mockService to apiService
  
  /**
   * Reset filters to defaults (keeping current regions)
   */
  const resetFilters = useCallback(() => {
    const defaultFilters: Partial<FilterCriteria> = {
      nodeTypes: ['CONSULTANT', 'FIELD_CONSULTANT', 'COMPANY', 'PRODUCT', 'INCUMBENT_PRODUCT'],
      showInactive: true,
      // Clear all other filters
      sales_regions: [],
      channels: [],
      ratings: [],            // ✅ Changed from rankgroups to ratings
      assetClasses: [],
      consultantIds: [],
      fieldConsultantIds: [],
      clientIds: [],
      productIds: [],
      pcaIds: [],
      acaIds: [],
      mandateStatuses: []
    };
    
    applyFilters(defaultFilters);
  }, [applyFilters]);
  
  /**
   * Get available regions (for region selector)
   */
  const getAvailableRegions = useCallback(() => {
    return ['NAI', 'EMEA', 'APAC'];
  }, []);
  
  // Initial load on mount - ONLY ONCE, with a flag to prevent multiple calls
  const [hasInitialized, setHasInitialized] = useState(false);
  
  useEffect(() => {
    if (!hasInitialized) {
      console.log('🚀 Initial mount - loading NAI data once');
      setHasInitialized(true);
      loadRegionData(['NAI']);
    }
  }, [hasInitialized, loadRegionData]);
  
  return {
    // Data
    graphData,
    filterOptions,
    currentFilters,
    currentRegions,
    updateCounter, // Export update counter for debugging
    
    // Loading states
    initialLoading,
    filterLoading,
    error,
    
    // Actions following your strategy
    changeRegions,     // Step 1: Change regions (reloads everything)
    applyFilters,      // Step 3: Apply filters to current region data
    resetFilters,      // Reset to defaults
    getAvailableRegions,
    
    // Computed properties
    hasData: graphData.nodes.length > 0,
    nodeCount: graphData.nodes.length,
    edgeCount: graphData.edges.length
  };
};