// services/ApiNeo4jService.ts - COMPLETE FIXED VERSION
import type { FilterCriteria, FilterOptions } from './MockNeo4jService';

interface Neo4jNode {
  id: string;
  labels: string[];
  properties: Record<string, any>;
}

interface Neo4jRelationship {
  id: string;
  type: string;
  start_node_id: string;
  end_node_id: string;
  properties: Record<string, any>;
}

interface Neo4jResult {
  nodes: Neo4jNode[];
  relationships: Neo4jRelationship[];
  metadata?: Record<string, any>;
}

interface ApiResponse<T> {
  success?: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export default class ApiNeo4jService {
  private static instance: ApiNeo4jService;
  private baseUrl: string;
  private regionDataCache: Map<string, Neo4jResult> = new Map();
  private filterOptionsCache: Map<string, FilterOptions> = new Map();
  
  private constructor() {
    // Default to localhost:8000, but can be configured via environment
    this.baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
    console.log(`🔌 ApiNeo4jService initialized with base URL: ${this.baseUrl}`);
  }
  
  static getInstance(): ApiNeo4jService {
    if (!ApiNeo4jService.instance) {
      ApiNeo4jService.instance = new ApiNeo4jService();
    }
    return ApiNeo4jService.instance;
  }
  
  /**
   * Test API connection
   */
  async testConnection(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/health`);
      const data = await response.json();
      
      console.log('🔍 API Health Check:', data);
      return data.status === 'healthy' && data.database_connected;
    } catch (error) {
      console.error('❌ API connection test failed:', error);
      return false;
    }
  }
  
  /**
   * Get data for specific regions - matches MockNeo4jService interface
   */
  async getRegionData(regions: string[] = ['NAI']): Promise<Neo4jResult> {
    console.log(`🌐 Loading data for regions: ${regions.join(', ')}`);
    
    try {
      // For now, use the first region (API supports single region calls)
      const region = regions[0];
      
      // Check cache first
      const cacheKey = regions.sort().join(',');
      if (this.regionDataCache.has(cacheKey)) {
        console.log(`📋 Using cached data for ${cacheKey}`);
        return this.regionDataCache.get(cacheKey)!;
      }
      
      const response = await fetch(`${this.baseUrl}/api/v1/graph/region/${region}`);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data: Neo4jResult = await response.json();
      
      console.log(`✅ Retrieved ${data.nodes.length} nodes and ${data.relationships.length} relationships for ${region}`);
      
      // Transform API response to match expected format
      const transformedData = this.transformApiResponse(data);
      
      // Cache the result
      this.regionDataCache.set(cacheKey, transformedData);
      
      return transformedData;
      
    } catch (error) {
      console.error('❌ Failed to fetch region data:', error);
      throw new Error(`Failed to fetch region data: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  /**
   * Extract filter options from region data - matches MockNeo4jService interface
   */
  async getFilterOptionsFromData(data: Neo4jResult): Promise<FilterOptions> {
    console.log('📊 Extracting filter options from data...');
    
    try {
      // Try to get filter options from API if available
      const regions = this.extractRegionsFromData(data);
      const cacheKey = regions.sort().join(',');
      
      if (this.filterOptionsCache.has(cacheKey)) {
        return this.filterOptionsCache.get(cacheKey)!;
      }
      
      // For now, extract from data (could be enhanced with dedicated API endpoint)
      const options = this.extractFilterOptionsFromData(data);
      
      // Cache the result
      this.filterOptionsCache.set(cacheKey, options);
      
      return options;
      
    } catch (error) {
      console.error('❌ Failed to extract filter options:', error);
      // Return empty options as fallback
      return this.getEmptyFilterOptions();
    }
  }
  
  /**
   * Apply filters to data - this could call a filter endpoint or work locally
   */
  async applyFiltersToData(data: Neo4jResult, filters: FilterCriteria): Promise<Neo4jResult> {
    console.log('🔧 Applying filters:', filters);
    
    try {
      // Option 1: Use local filtering (faster, works with current API)
      return this.applyFiltersLocally(data, filters);
      
      // Option 2: Call backend filter endpoint (when available)
      // return await this.applyFiltersViaAPI(filters);
      
    } catch (error) {
      console.error('❌ Failed to apply filters:', error);
      throw error;
    }
  }
  
  /**
   * Get database statistics
   */
  async getDatabaseStats(): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}/api/v1/graph/stats`);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const stats = await response.json();
      console.log('📊 Database stats retrieved:', stats);
      
      return stats;
    } catch (error) {
      console.error('❌ Failed to get database stats:', error);
      throw error;
    }
  }
  
  /**
   * Transform API response to match frontend expectations
   */
  private transformApiResponse(apiData: Neo4jResult): Neo4jResult {
    return {
      nodes: apiData.nodes.map(node => ({
        id: node.properties.id || node.id, // Use property id if available, fallback to node id
        labels: node.labels,
        properties: {
          ...node.properties,
          // Ensure required properties exist
          id: node.properties.id || node.id,
          name: node.properties.name || node.id,
          label: node.properties.name || node.id
        }
      })),
      relationships: apiData.relationships.map(rel => ({
        id: rel.id,
        type: rel.type,
        start_node_id: rel.start_node_id,
        end_node_id: rel.end_node_id,
        properties: {
          ...rel.properties,
          // Transform property names to match frontend expectations
          relType: rel.type,
          sourceId: rel.properties.sourceId || rel.start_node_id,
          targetId: rel.properties.targetId || rel.end_node_id
        }
      })),
      metadata: apiData.metadata
    };
  }
  
  /**
   * Extract regions from data
   */
  private extractRegionsFromData(data: Neo4jResult): string[] {
    const regions = new Set<string>();
    
    data.nodes.forEach(node => {
      if (node.properties.region) {
        regions.add(node.properties.region);
      }
    });
    
    return Array.from(regions);
  }
  
  /**
   * Extract filter options from data locally
   */
  private extractFilterOptionsFromData(data: Neo4jResult): FilterOptions {
    const options: Record<string, Set<string>> = {
      regions: new Set(['NAI', 'EMEA', 'APAC']), // Always show all regions
      sales_regions: new Set(),
      channels: new Set(),
      assetClasses: new Set(),
      consultants: new Set(),
      fieldConsultants: new Set(),
      clients: new Set(),
      products: new Set(),
      incumbent_products: new Set(),  // ✅ Fixed: Added missing property
      pcas: new Set(),
      acas: new Set(),
      ratings: new Set(['Positive', 'Negative', 'Neutral', 'Introduced']), // ✅ Fixed: Changed from rankgroups
      mandate_statuses: new Set(['Active', 'At Risk', 'Conversion in Progress']),
      jpm_flags: new Set(['Y', 'N']), // ✅ Fixed: Changed from jmp_flags
      privacy_levels: new Set(['Public', 'Private', 'Confidential'])
    };
    
    // Extract unique values from nodes
    data.nodes.forEach(node => {
      const props = node.properties;
      
      // Geographic attributes
      if (props.sales_region) options.sales_regions.add(props.sales_region);
      if (props.channel) options.channels.add(props.channel);
      
      // Entity attributes
      if (props.asset_class) options.assetClasses.add(props.asset_class);
      if (props.pca) options.pcas.add(props.pca);
      if (props.aca) options.acas.add(props.aca);
      if (props.jpm_flag) options.jpm_flags.add(props.jpm_flag); // ✅ Fixed: jpm not jmp
      if (props.privacy) options.privacy_levels.add(props.privacy);
      
      // Entity names by type
      if (node.labels.includes('CONSULTANT') && props.name) {
        options.consultants.add(props.name);
      }
      if (node.labels.includes('FIELD_CONSULTANT') && props.name) {
        options.fieldConsultants.add(props.name);
      }
      if (node.labels.includes('COMPANY') && props.name) {
        options.clients.add(props.name);
      }
      if (node.labels.includes('PRODUCT') && props.name) {
        options.products.add(props.name);
      }
      if (node.labels.includes('INCUMBENT_PRODUCT') && props.name) {
        options.incumbent_products.add(props.name); // ✅ Fixed: Added missing logic
      }
    });
    
    // Extract from relationships
    data.relationships.forEach(rel => {
      if (rel.type === 'RATES' && rel.properties.rankgroup) {
        options.ratings.add(rel.properties.rankgroup); // ✅ Fixed: Changed from rankgroups to ratings
      }
      if (rel.type === 'OWNS' && rel.properties.mandate_status) {
        options.mandate_statuses.add(rel.properties.mandate_status);
      }
    });
    
    // Convert Sets to sorted Arrays
    const result: FilterOptions = {} as FilterOptions;
    Object.entries(options).forEach(([key, set]) => {
      result[key as keyof FilterOptions] = Array.from(set).sort() as any;
    });
    
    console.log('✅ Filter options extracted:', {
      regions: result.regions.length,
      sales_regions: result.sales_regions.length,
      channels: result.channels.length,
      consultants: result.consultants.length,
      products: result.products.length
    });
    
    return result;
  }
  
  /**
   * Apply filters locally (client-side filtering)
   */
  private applyFiltersLocally(data: Neo4jResult, filters: FilterCriteria): Neo4jResult {
    let filteredNodes = [...data.nodes];
    let filteredRelationships = [...data.relationships];
    
    console.log(`🔍 Starting with ${filteredNodes.length} nodes, ${filteredRelationships.length} relationships`);
    
    // Apply node type filters
    if (filters.nodeTypes && filters.nodeTypes.length > 0) {
      filteredNodes = filteredNodes.filter(node => 
        filters.nodeTypes!.some(type => node.labels.includes(type))
      );
      console.log(`🔍 After node type filter: ${filteredNodes.length} nodes`);
    }
    
    // Apply geographic filters
    if (filters.sales_regions && filters.sales_regions.length > 0) {
      filteredNodes = filteredNodes.filter(node => 
        !node.properties.sales_region || filters.sales_regions!.includes(node.properties.sales_region)
      );
      console.log(`🔍 After sales region filter: ${filteredNodes.length} nodes`);
    }
    
    if (filters.channels && filters.channels.length > 0) {
      filteredNodes = filteredNodes.filter(node => 
        !node.properties.channel || filters.channels!.includes(node.properties.channel)
      );
      console.log(`🔍 After channel filter: ${filteredNodes.length} nodes`);
    }
    
    // Apply entity-specific filters by NAME
    if (filters.consultantIds && filters.consultantIds.length > 0) {
      filteredNodes = filteredNodes.filter(node => 
        !node.labels.includes('CONSULTANT') || 
        filters.consultantIds!.includes(node.properties.name)
      );
      console.log(`🔍 After consultant filter: ${filteredNodes.length} nodes`);
    }
    
    if (filters.fieldConsultantIds && filters.fieldConsultantIds.length > 0) {
      filteredNodes = filteredNodes.filter(node => 
        !node.labels.includes('FIELD_CONSULTANT') || 
        filters.fieldConsultantIds!.includes(node.properties.name)
      );
      console.log(`🔍 After field consultant filter: ${filteredNodes.length} nodes`);
    }
    
    if (filters.clientIds && filters.clientIds.length > 0) {
      filteredNodes = filteredNodes.filter(node => 
        !node.labels.includes('COMPANY') || 
        filters.clientIds!.includes(node.properties.name)
      );
      console.log(`🔍 After client filter: ${filteredNodes.length} nodes`);
    }
    
    if (filters.productIds && filters.productIds.length > 0) {
      filteredNodes = filteredNodes.filter(node => 
        (!node.labels.includes('PRODUCT') && !node.labels.includes('INCUMBENT_PRODUCT')) || 
        filters.productIds!.includes(node.properties.name)
      );
      console.log(`🔍 After product filter: ${filteredNodes.length} nodes`);
    }
    
    // Filter relationships based on remaining nodes
    const nodeIds = new Set(filteredNodes.map(n => n.id));
    filteredRelationships = filteredRelationships.filter(rel => 
      nodeIds.has(rel.start_node_id) && nodeIds.has(rel.end_node_id)
    );
    console.log(`🔍 After node filtering, relationships: ${filteredRelationships.length}`);
    
    // Apply relationship-specific filters
    if (filters.mandateStatuses && filters.mandateStatuses.length > 0) {
      filteredRelationships = filteredRelationships.filter(rel => 
        rel.type !== 'OWNS' || 
        !rel.properties.mandate_status ||
        filters.mandateStatuses!.includes(rel.properties.mandate_status)
      );
      console.log(`🔍 After mandate status filter: ${filteredRelationships.length} relationships`);
    }
    
    // Handle orphaned nodes based on showInactive setting
    if (!filters.showInactive) {
      const connectedNodeIds = new Set([
        ...filteredRelationships.map(r => r.start_node_id),
        ...filteredRelationships.map(r => r.end_node_id)
      ]);
      
      const beforeCount = filteredNodes.length;
      filteredNodes = filteredNodes.filter(node => 
        connectedNodeIds.has(node.id)
      );
      console.log(`🔍 Removed ${beforeCount - filteredNodes.length} orphaned nodes (showInactive=false)`);
    }
    
    const result = { 
      nodes: filteredNodes, 
      relationships: filteredRelationships,
      metadata: {
        originalNodeCount: data.nodes.length,
        originalRelationshipCount: data.relationships.length,
        filteredNodeCount: filteredNodes.length,
        filteredRelationshipCount: filteredRelationships.length,
        filtersApplied: filters
      }
    };
    
    console.log(`✅ Final result: ${result.nodes.length} nodes, ${result.relationships.length} relationships`);
    
    return result;
  }
  
  /**
   * Get empty filter options as fallback
   */
  private getEmptyFilterOptions(): FilterOptions {
    return {
      regions: ['NAI', 'EMEA', 'APAC'],
      sales_regions: [],
      channels: [],
      assetClasses: [],
      consultants: [],
      fieldConsultants: [],
      clients: [],
      products: [],
      incumbent_products: [], // ✅ Fixed: Added missing property
      pcas: [],
      acas: [],
      ratings: ['Positive', 'Negative', 'Neutral', 'Introduced'], // ✅ Fixed: Changed from rankgroups
      mandateStatuses: ['Active', 'At Risk', 'Conversion in Progress'],
      jpm_flags: ['Y', 'N'], // ✅ Fixed: Changed from jmp_flags
      privacy_levels: ['Public', 'Private', 'Confidential'],
      influenceLevels: ['1', '2', '3', '4', 'UNK', 'High', 'medium', 'low'],
    };
  }
  
  /**
   * Clear all caches
   */
  clearCache(): void {
    this.regionDataCache.clear();
    this.filterOptionsCache.clear();
    console.log('🧹 API service cache cleared');
  }
}