export interface FilterCriteria {
  regions?: string[];
  nodeTypes?: string[];
  sales_regions?: string[];
  channels?: string[];
  ratings?: string[];           // ✅ Use consistent naming
  influenceLevels?: string[];   // ✅ Add missing property
  assetClasses?: string[];
  consultantIds?: string[];
  fieldConsultantIds?: string[];
  clientIds?: string[];
  productIds?: string[];
  pcaIds?: string[];
  acaIds?: string[];
  mandateStatuses?: string[];   // ✅ Use camelCase consistently
  showInactive?: boolean;
}

export interface FilterOptions {
  regions: string[];
  sales_regions: string[];
  channels: string[];
  assetClasses: string[];
  consultants: string[];
  fieldConsultants: string[];   // ✅ camelCase (not field_consultants)
  clients: string[];
  products: string[];
  incumbent_products: string[];
  pcas: string[];
  acas: string[];
  ratings: string[];           // ✅ Use consistent naming
  influenceLevels: string[];   // ✅ Add missing property
  mandateStatuses: string[];   // ✅ Use camelCase consistently (not mandate_statuses)
  jpm_flags: string[];
  privacy_levels: string[];
}