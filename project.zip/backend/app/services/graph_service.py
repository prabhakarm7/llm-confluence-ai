"""
Graph service for handling Neo4j database operations.
Provides high-level interface for CRUD operations on the smart network graph.
"""
import time
from typing import Dict, List, Any, Optional, Tuple
from neo4j import GraphDatabase, Session
from neo4j.exceptions import Neo4jError

from app.config import (
    NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD, NEO4J_DATABASE,
    REGIONS, SALES_REGIONS, CHANNELS, ASSET_CLASSES, PRIVACY_LEVELS,
    MANDATE_STATUSES, RANKGROUP_VALUES, JPM_FLAG_VALUES
)


class GraphService:
    """Service class for graph database operations."""
    
    def __init__(self):
        """Initialize the graph service with Neo4j connection."""
        self.driver = GraphDatabase.driver(
            NEO4J_URI,
            auth=(NEO4J_USERNAME, NEO4J_PASSWORD),
            database=NEO4J_DATABASE
        )
        
    def close(self):
        """Close the database connection."""
        if self.driver:
            self.driver.close()
    
    def health_check(self) -> bool:
        """Check if database connection is healthy."""
        try:
            with self.driver.session() as session:
                result = session.run("RETURN 1 as test")
                return result.single()["test"] == 1
        except Exception:
            return False
    
    # ===== GRAPH DATA RETRIEVAL =====
    
    def get_region_graph(self, region: str) -> Dict[str, Any]:
        """Get complete graph data for a specific region."""
        region = region.upper()
        
        with self.driver.session() as session:
            # Get all nodes in the region
            nodes_query = """
            MATCH (n {region: $region})
            RETURN n, labels(n) as labels, id(n) as neo4j_id
            ORDER BY labels(n)[0], n.name
            """
            
            nodes_result = session.run(nodes_query, {"region": region})
            nodes = []
            
            for record in nodes_result:
                node_data = dict(record["n"])
                nodes.append({
                    "id": str(record["neo4j_id"]),
                    "labels": record["labels"],
                    "properties": node_data
                })
            
            # Get all relationships between nodes in this region
            relationships_query = """
            MATCH (source {region: $region})-[r]->(target {region: $region})
            RETURN r, type(r) as rel_type, id(r) as neo4j_id,
                   id(source) as source_id, id(target) as target_id
            ORDER BY type(r)
            """
            
            rels_result = session.run(relationships_query, {"region": region})
            relationships = []
            
            for record in rels_result:
                rel_data = dict(record["r"])
                relationships.append({
                    "id": str(record["neo4j_id"]),
                    "type": record["rel_type"],
                    "start_node_id": str(record["source_id"]),
                    "end_node_id": str(record["target_id"]),
                    "properties": rel_data
                })
            
            return {
                "nodes": nodes,
                "relationships": relationships,
                "metadata": {
                    "region": region,
                    "node_count": len(nodes),
                    "relationship_count": len(relationships)
                }
            }
    
    def get_filtered_graph(self, filters: Dict[str, Any]) -> Dict[str, Any]:
        """Get graph data based on filter criteria."""
        with self.driver.session() as session:
            # Build dynamic WHERE clause
            where_clauses = []
            params = {}
            
            # Region filter
            if filters.get("regions"):
                where_clauses.append("n.region IN $regions")
                params["regions"] = filters["regions"]
            
            # Node type filter
            if filters.get("node_types"):
                node_labels = " OR ".join([f"n:{label}" for label in filters["node_types"]])
                where_clauses.append(f"({node_labels})")
            
            # Sales region filter
            if filters.get("sales_regions"):
                where_clauses.append("n.sales_region IN $sales_regions")
                params["sales_regions"] = filters["sales_regions"]
            
            # Channel filter
            if filters.get("channels"):
                where_clauses.append("n.channel IN $channels")
                params["channels"] = filters["channels"]
            
            # Asset class filter
            if filters.get("asset_classes"):
                where_clauses.append("n.asset_class IN $asset_classes")
                params["asset_classes"] = filters["asset_classes"]
            
            # Privacy filter
            if filters.get("privacy_levels"):
                where_clauses.append("n.privacy IN $privacy_levels")
                params["privacy_levels"] = filters["privacy_levels"]
            
            # JPM flag filter
            if filters.get("jpm_flag"):
                where_clauses.append("n.jpm_flag IN $jpm_flag")
                params["jpm_flag"] = filters["jpm_flag"]
            
            # Build query
            where_clause = " AND ".join(where_clauses) if where_clauses else "TRUE"
            
            nodes_query = f"""
            MATCH (n)
            WHERE {where_clause}
            RETURN n, labels(n) as labels, id(n) as neo4j_id
            ORDER BY labels(n)[0], n.name
            """
            
            nodes_result = session.run(nodes_query, params)
            nodes = []
            node_ids = set()
            
            for record in nodes_result:
                node_id = str(record["neo4j_id"])
                node_ids.add(node_id)
                node_data = dict(record["n"])
                nodes.append({
                    "id": node_id,
                    "labels": record["labels"],
                    "properties": node_data
                })
            
            # Get relationships between filtered nodes
            if node_ids:
                relationships_query = """
                MATCH (source)-[r]->(target)
                WHERE id(source) IN $node_ids AND id(target) IN $node_ids
                RETURN r, type(r) as rel_type, id(r) as neo4j_id,
                       id(source) as source_id, id(target) as target_id
                ORDER BY type(r)
                """
                
                rels_result = session.run(relationships_query, {"node_ids": list(map(int, node_ids))})
                relationships = []
                
                for record in rels_result:
                    rel_data = dict(record["r"])
                    relationships.append({
                        "id": str(record["neo4j_id"]),
                        "type": record["rel_type"],
                        "start_node_id": str(record["source_id"]),
                        "end_node_id": str(record["target_id"]),
                        "properties": rel_data
                    })
            else:
                relationships = []
            
            return {
                "nodes": nodes,
                "relationships": relationships,
                "metadata": {
                    "filters_applied": filters,
                    "node_count": len(nodes),
                    "relationship_count": len(relationships)
                }
            }
    
    # ===== STATISTICS AND METADATA =====
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get comprehensive database statistics."""
        with self.driver.session() as session:
            # Total counts
            total_nodes = session.run("MATCH (n) RETURN count(n) as count").single()["count"]
            total_rels = session.run("MATCH ()-[r]->() RETURN count(r) as count").single()["count"]
            
            # Node counts by type
            node_types_result = session.run("""
                MATCH (n) 
                RETURN labels(n)[0] as label, count(n) as count 
                ORDER BY count DESC
            """)
            node_counts = {record["label"]: record["count"] for record in node_types_result}
            
            # Relationship counts by type
            rel_types_result = session.run("""
                MATCH ()-[r]->() 
                RETURN type(r) as type, count(r) as count 
                ORDER BY count DESC
            """)
            relationship_counts = {record["type"]: record["count"] for record in rel_types_result}
            
            # Region counts
            regions_result = session.run("""
                MATCH (n) 
                WHERE n.region IS NOT NULL 
                RETURN n.region as region, count(n) as count 
                ORDER BY count DESC
            """)
            region_counts = {record["region"]: record["count"] for record in regions_result}
            
            return {
                "total_nodes": total_nodes,
                "total_relationships": total_rels,
                "node_counts": node_counts,
                "relationship_counts": relationship_counts,
                "region_counts": region_counts
            }
    
    def get_region_stats(self, region: str) -> Dict[str, Any]:
        """Get statistics for a specific region."""
        region = region.upper()
        
        with self.driver.session() as session:
            # Node counts by type in region
            node_counts_result = session.run("""
                MATCH (n {region: $region})
                RETURN labels(n)[0] as label, count(n) as count
                ORDER BY count DESC
            """, {"region": region})
            
            node_counts = {record["label"]: record["count"] for record in node_counts_result}
            
            # Relationship counts in region
            rel_counts_result = session.run("""
                MATCH (source {region: $region})-[r]->(target {region: $region})
                RETURN type(r) as type, count(r) as count
                ORDER BY count DESC
            """, {"region": region})
            
            relationship_counts = {record["type"]: record["count"] for record in rel_counts_result}
            
            return {
                "region": region,
                "node_counts": node_counts,
                "relationship_counts": relationship_counts,
                "total_nodes": sum(node_counts.values()),
                "total_relationships": sum(relationship_counts.values())
            }
    
    def get_filter_options(self) -> Dict[str, List[str]]:
        """Get available filter options from the database."""
        with self.driver.session() as session:
            filter_options = {}
            
            # Get unique regions
            regions_result = session.run("MATCH (n) WHERE n.region IS NOT NULL RETURN DISTINCT n.region as value ORDER BY value")
            filter_options["regions"] = [record["value"] for record in regions_result]
            
            # Get unique sales regions
            sales_regions_result = session.run("MATCH (n) WHERE n.sales_region IS NOT NULL RETURN DISTINCT n.sales_region as value ORDER BY value")
            filter_options["sales_regions"] = [record["value"] for record in sales_regions_result]
            
            # Get unique channels
            channels_result = session.run("MATCH (n) WHERE n.channel IS NOT NULL RETURN DISTINCT n.channel as value ORDER BY value")
            filter_options["channels"] = [record["value"] for record in channels_result]
            
            # Get unique asset classes
            asset_classes_result = session.run("MATCH (n) WHERE n.asset_class IS NOT NULL RETURN DISTINCT n.asset_class as value ORDER BY value")
            filter_options["asset_classes"] = [record["value"] for record in asset_classes_result]
            
            # Get unique PCAs
            pcas_result = session.run("MATCH (n) WHERE n.pca IS NOT NULL RETURN DISTINCT n.pca as value ORDER BY value")
            filter_options["pcas"] = [record["value"] for record in pcas_result]
            
            # Get unique ACAs
            acas_result = session.run("MATCH (n) WHERE n.aca IS NOT NULL RETURN DISTINCT n.aca as value ORDER BY value")
            filter_options["acas"] = [record["value"] for record in acas_result]
            
            # Get unique privacy levels
            privacy_result = session.run("MATCH (n) WHERE n.privacy IS NOT NULL RETURN DISTINCT n.privacy as value ORDER BY value")
            filter_options["privacy_levels"] = [record["value"] for record in privacy_result]
            
            # Get unique JPM flags
            jpm_flags_result = session.run("MATCH (n) WHERE n.jpm_flag IS NOT NULL RETURN DISTINCT n.jpm_flag as value ORDER BY value")
            filter_options["jpm_flags"] = [record["value"] for record in jpm_flags_result]
            
            # Get unique mandate statuses from relationships
            mandate_statuses_result = session.run("MATCH ()-[r:OWNS]->() WHERE r.mandate_status IS NOT NULL RETURN DISTINCT r.mandate_status as value ORDER BY value")
            filter_options["mandate_statuses"] = [record["value"] for record in mandate_statuses_result]
            
            # Get unique rank groups from relationships
            rankgroups_result = session.run("MATCH ()-[r:RATES]->() WHERE r.rankgroup IS NOT NULL RETURN DISTINCT r.rankgroup as value ORDER BY value")
            filter_options["rankgroups"] = [record["value"] for record in rankgroups_result]
            
            return filter_options
    
    # ===== NODE OPERATIONS =====
    
    def create_consultant(self, consultant_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new consultant node."""
        with self.driver.session() as session:
            query = """
            CREATE (c:CONSULTANT)
            SET c = $props
            RETURN c, id(c) as neo4j_id
            """
            
            result = session.run(query, {"props": consultant_data})
            record = result.single()
            
            return {
                "id": str(record["neo4j_id"]),
                "labels": ["CONSULTANT"],
                "properties": dict(record["c"])
            }
    
    def create_company(self, company_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new company node."""
        with self.driver.session() as session:
            query = """
            CREATE (c:COMPANY)
            SET c = $props
            RETURN c, id(c) as neo4j_id
            """
            
            result = session.run(query, {"props": company_data})
            record = result.single()
            
            return {
                "id": str(record["neo4j_id"]),
                "labels": ["COMPANY"],
                "properties": dict(record["c"])
            }
    
    def create_product(self, product_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new product node."""
        with self.driver.session() as session:
            query = """
            CREATE (p:PRODUCT)
            SET p = $props
            RETURN p, id(p) as neo4j_id
            """
            
            result = session.run(query, {"props": product_data})
            record = result.single()
            
            return {
                "id": str(record["neo4j_id"]),
                "labels": ["PRODUCT"],
                "properties": dict(record["p"])
            }
    
    def update_node(self, node_id: str, node_data: Dict[str, Any]) -> Dict[str, Any]:
        """Update an existing node."""
        with self.driver.session() as session:
            query = """
            MATCH (n)
            WHERE id(n) = $node_id
            SET n += $props
            RETURN n, labels(n) as labels, id(n) as neo4j_id
            """
            
            result = session.run(query, {"node_id": int(node_id), "props": node_data})
            record = result.single()
            
            if not record:
                raise ValueError(f"Node with ID {node_id} not found")
            
            return {
                "id": str(record["neo4j_id"]),
                "labels": record["labels"],
                "properties": dict(record["n"])
            }
    
    def delete_node(self, node_id: str) -> bool:
        """Delete a node and all its relationships."""
        with self.driver.session() as session:
            query = """
            MATCH (n)
            WHERE id(n) = $node_id
            DETACH DELETE n
            RETURN count(n) as deleted_count
            """
            
            result = session.run(query, {"node_id": int(node_id)})
            return result.single()["deleted_count"] > 0
    
    # ===== RELATIONSHIP OPERATIONS =====
    
    def create_relationship(self, rel_type: str, source_id: str, target_id: str, properties: Dict[str, Any] = None) -> Dict[str, Any]:
        """Create a relationship between two nodes."""
        with self.driver.session() as session:
            query = f"""
            MATCH (source), (target)
            WHERE id(source) = $source_id AND id(target) = $target_id
            CREATE (source)-[r:{rel_type}]->(target)
            SET r = $props
            RETURN r, type(r) as rel_type, id(r) as neo4j_id,
                   id(source) as source_id, id(target) as target_id
            """
            
            result = session.run(query, {
                "source_id": int(source_id),
                "target_id": int(target_id),
                "props": properties or {}
            })
            record = result.single()
            
            if not record:
                raise ValueError(f"Could not create relationship between nodes {source_id} and {target_id}")
            
            return {
                "id": str(record["neo4j_id"]),
                "type": record["rel_type"],
                "start_node_id": str(record["source_id"]),
                "end_node_id": str(record["target_id"]),
                "properties": dict(record["r"])
            }
    
    def update_relationship(self, rel_id: str, properties: Dict[str, Any]) -> Dict[str, Any]:
        """Update relationship properties."""
        with self.driver.session() as session:
            query = """
            MATCH ()-[r]->()
            WHERE id(r) = $rel_id
            SET r += $props
            RETURN r, type(r) as rel_type, id(r) as neo4j_id,
                   startNode(r) as source, endNode(r) as target
            """
            
            result = session.run(query, {"rel_id": int(rel_id), "props": properties})
            record = result.single()
            
            if not record:
                raise ValueError(f"Relationship with ID {rel_id} not found")
            
            return {
                "id": str(record["neo4j_id"]),
                "type": record["rel_type"],
                "start_node_id": str(record["source"].id),
                "end_node_id": str(record["target"].id),
                "properties": dict(record["r"])
            }
    
    def delete_relationship(self, rel_id: str) -> bool:
        """Delete a relationship."""
        with self.driver.session() as session:
            query = """
            MATCH ()-[r]->()
            WHERE id(r) = $rel_id
            DELETE r
            RETURN count(r) as deleted_count
            """
            
            result = session.run(query, {"rel_id": int(rel_id)})
            return result.single()["deleted_count"] > 0
    
    # ===== SEARCH AND QUERY =====
    
    def search_nodes(self, search_term: str, node_types: List[str] = None, region: str = None) -> List[Dict[str, Any]]:
        """Search for nodes by name or other properties."""
        with self.driver.session() as session:
            where_clauses = ["toLower(n.name) CONTAINS toLower($search_term)"]
            params = {"search_term": search_term}
            
            if node_types:
                node_labels = " OR ".join([f"n:{label}" for label in node_types])
                where_clauses.append(f"({node_labels})")
            
            if region:
                where_clauses.append("n.region = $region")
                params["region"] = region.upper()
            
            where_clause = " AND ".join(where_clauses)
            
            query = f"""
            MATCH (n)
            WHERE {where_clause}
            RETURN n, labels(n) as labels, id(n) as neo4j_id
            ORDER BY n.name
            LIMIT 50
            """
            
            result = session.run(query, params)
            nodes = []
            
            for record in result:
                nodes.append({
                    "id": str(record["neo4j_id"]),
                    "labels": record["labels"],
                    "properties": dict(record["n"])
                })
            
            return nodes
    
    def execute_cypher(self, query: str, parameters: Dict[str, Any] = None, read_only: bool = True) -> Dict[str, Any]:
        """Execute a custom Cypher query."""
        start_time = time.time()
        
        # Basic safety check for read-only queries
        if read_only:
            dangerous_keywords = ['CREATE', 'DELETE', 'SET', 'REMOVE', 'MERGE', 'DROP']
            query_upper = query.upper()
            for keyword in dangerous_keywords:
                if keyword in query_upper:
                    raise ValueError(f'Query contains potentially dangerous keyword: {keyword}')
        
        with self.driver.session() as session:
            try:
                result = session.run(query, parameters or {})
                data = [record.data() for record in result]
                execution_time = time.time() - start_time
                
                return {
                    "success": True,
                    "data": data,
                    "execution_time": execution_time,
                    "query": query,
                    "row_count": len(data)
                }
            except Exception as e:
                execution_time = time.time() - start_time
                return {
                    "success": False,
                    "data": [],
                    "execution_time": execution_time,
                    "query": query,
                    "row_count": 0,
                    "error": str(e)
                }
    
    # ===== BULK OPERATIONS =====
    
    def bulk_create_nodes(self, node_type: str, nodes_data: List[Dict[str, Any]]) -> int:
        """Bulk create nodes of a specific type."""
        if not nodes_data:
            return 0
        
        with self.driver.session() as session:
            query = f"""
            UNWIND $nodes AS node
            CREATE (n:{node_type})
            SET n = node
            """
            
            result = session.run(query, {"nodes": nodes_data})
            summary = result.consume()
            return summary.counters.nodes_created
    
    def bulk_create_relationships(self, rel_type: str, relationships_data: List[Dict[str, Any]]) -> int:
        """Bulk create relationships of a specific type."""
        if not relationships_data:
            return 0
        
        with self.driver.session() as session:
            # Assuming relationships_data contains source_id, target_id, and properties
            query = f"""
            UNWIND $rels AS rel
            MATCH (source {{id: rel.source_id}})
            MATCH (target {{id: rel.target_id}})
            CREATE (source)-[r:{rel_type}]->(target)
            SET r = rel.properties
            """
            
            result = session.run(query, {"rels": relationships_data})
            summary = result.consume()
            return summary.counters.relationships_created
    
    def clear_database(self) -> Dict[str, int]:
        """Clear all data from the database."""
        with self.driver.session() as session:
            result = session.run("MATCH (n) DETACH DELETE n")
            summary = result.consume()
            
            return {
                "nodes_deleted": summary.counters.nodes_deleted,
                "relationships_deleted": summary.counters.relationships_deleted
            }


# Global service instance
graph_service = GraphService()