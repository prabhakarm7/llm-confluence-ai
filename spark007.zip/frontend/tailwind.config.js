/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'mi6-blue': '#00d4ff',
        'mi6-dark': '#0a0a0a',
        'mi6-gray': '#1a1a1a'
      }
    },
  },
  plugins: [],
}
