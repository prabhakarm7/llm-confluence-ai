import React, { useState, useEffect } from 'react';

// API Service
class MI6Intelligence {
  constructor() {
    this.baseURL = 'http://localhost:8000';
    this.token = 'demo-agent-token'; // In production, implement proper auth
  }

  async launchMission(briefing) {
    const response = await fetch(`${this.baseURL}/missions/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`
      },
      body: JSON.stringify(briefing)
    });
    return response.json();
  }

  async getMissionStatus(missionId) {
    const response = await fetch(`${this.baseURL}/missions/${missionId}/status`, {
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });
    return response.json();
  }

  async getIntelligenceReport(missionId) {
    const response = await fetch(`${this.baseURL}/intelligence/${missionId}`, {
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });
    return response.json();
  }

  async getActiveMissions() {
    const response = await fetch(`${this.baseURL}/missions/active`, {
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });
    return response.json();
  }
}

// Loading Spinner Component
const LoadingSpinner = ({ size = 'md' }) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-8 h-8',
    lg: 'w-12 h-12'
  };

  return (
    <div className={`animate-spin rounded-full border-2 border-cyan-500 border-t-transparent ${sizeClasses[size]}`}></div>
  );
};

// Mission Status Badge
const StatusBadge = ({ status }) => {
  const getStatusStyle = (status) => {
    switch (status) {
      case 'MISSION_COMPLETE':
        return 'bg-green-500 text-white';
      case 'MISSION_FAILED':
        return 'bg-red-500 text-white';
      case 'AGENTS_DEPLOYED':
      case 'ACTIVE':
        return 'bg-yellow-500 text-black';
      case 'INFILTRATING':
      case 'ANALYZING':
      case 'INTERROGATING':
      case 'CONFIGURING':
        return 'bg-blue-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  return (
    <span className={`px-2 py-1 rounded-full text-xs font-bold ${getStatusStyle(status)}`}>
      {status}
    </span>
  );
};

// Mission Launcher Component
const MissionLauncher = ({ onMissionLaunched }) => {
  const [briefing, setBriefing] = useState({
    repo_url: '',
    classification_level: 'CONFIDENTIAL',
    optimization_priority: 'HIGH',
    workload_type: '',
    target_platform: 'AWS'
  });
  const [launching, setLaunching] = useState(false);

  const handleLaunch = async () => {
    setLaunching(true);
    try {
      const intelligence = new MI6Intelligence();
      const result = await intelligence.launchMission(briefing);
      onMissionLaunched(result);
      
      // Reset form
      setBriefing({
        repo_url: '',
        classification_level: 'CONFIDENTIAL',
        optimization_priority: 'HIGH',
        workload_type: '',
        target_platform: 'AWS'
      });
    } catch (error) {
      console.error('Mission launch failed:', error);
    } finally {
      setLaunching(false);
    }
  };

  return (
    <div className="bg-gray-900 border border-gray-700 rounded-lg p-6 shadow-xl">
      <div className="flex items-center mb-6">
        <div className="bg-cyan-500 rounded-full p-2 mr-3">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
          </svg>
        </div>
        <h2 className="text-xl font-bold text-cyan-400 tracking-wider">🎯 MISSION DEPLOYMENT</h2>
      </div>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Target Repository URL</label>
          <input
            type="text"
            className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
            value={briefing.repo_url}
            onChange={(e) => setBriefing({ ...briefing, repo_url: e.target.value })}
            placeholder="https://github.com/your-org/spark-project"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Classification Level</label>
            <select
              className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white focus:ring-2 focus:ring-cyan-500"
              value={briefing.classification_level}
              onChange={(e) => setBriefing({ ...briefing, classification_level: e.target.value })}
            >
              <option value="UNCLASSIFIED">UNCLASSIFIED</option>
              <option value="CONFIDENTIAL">CONFIDENTIAL</option>
              <option value="SECRET">SECRET</option>
              <option value="TOP_SECRET">TOP SECRET</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Priority Level</label>
            <select
              className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white focus:ring-2 focus:ring-cyan-500"
              value={briefing.optimization_priority}
              onChange={(e) => setBriefing({ ...briefing, optimization_priority: e.target.value })}
            >
              <option value="LOW">LOW</option>
              <option value="MEDIUM">MEDIUM</option>
              <option value="HIGH">HIGH</option>
              <option value="CRITICAL">CRITICAL</option>
            </select>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Workload Type</label>
            <select
              className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white focus:ring-2 focus:ring-cyan-500"
              value={briefing.workload_type}
              onChange={(e) => setBriefing({ ...briefing, workload_type: e.target.value })}
            >
              <option value="">Auto-Detect</option>
              <option value="ETL_HEAVY">ETL Heavy</option>
              <option value="ML_TRAINING">ML Training</option>
              <option value="STREAMING">Streaming</option>
              <option value="ANALYTICS">Analytics</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Target Platform</label>
            <select
              className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white focus:ring-2 focus:ring-cyan-500"
              value={briefing.target_platform}
              onChange={(e) => setBriefing({ ...briefing, target_platform: e.target.value })}
            >
              <option value="AWS">AWS</option>
              <option value="AZURE">Azure</option>
              <option value="GCP">Google Cloud</option>
              <option value="DATABRICKS">Databricks</option>
            </select>
          </div>
        </div>
        
        <button
          onClick={handleLaunch}
          disabled={!briefing.repo_url || launching}
          className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold py-3 px-6 rounded-md hover:from-cyan-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center space-x-2"
        >
          {launching ? (
            <>
              <LoadingSpinner size="sm" />
              <span>DEPLOYING AGENTS...</span>
            </>
          ) : (
            <>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
              <span>DEPLOY AGENTS</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

// Agent Status Card
const AgentCard = ({ agent, status }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'MISSION_COMPLETE': return 'text-green-400 border-green-400';
      case 'ACTIVE': return 'text-yellow-400 border-yellow-400';
      case 'INFILTRATING':
      case 'ANALYZING':
      case 'INTERROGATING':
      case 'CONFIGURING': return 'text-blue-400 border-blue-400';
      default: return 'text-gray-400 border-gray-400';
    }
  };

  return (
    <div className={`bg-gray-900 border rounded-lg p-4 text-center transition-all duration-300 hover:scale-105 ${getStatusColor(status)}`}>
      <div className="text-3xl mb-2">{agent.icon}</div>
      <h3 className="font-bold text-white mb-1">{agent.name}</h3>
      <p className="text-sm text-gray-400 mb-2">{agent.codename}</p>
      <StatusBadge status={status} />
    </div>
  );
};

// Agent Status Dashboard
const AgentStatusDashboard = ({ missions }) => {
  const agents = [
    { id: 'golden_eye', name: 'Golden Eye', codename: 'AST Scanner', icon: '👁️' },
    { id: 'skyfall', name: 'Skyfall', codename: 'Profiler', icon: '⚡' },
    { id: 'quantum', name: 'Quantum', codename: 'Rules Engine', icon: '🔒' },
    { id: 'agent_007', name: 'Agent 007', codename: 'Cluster Config', icon: '☁️' }
  ];

  const getAgentStatus = (agentId) => {
    if (!missions.length) return 'STANDBY';
    const latestMission = missions[missions.length - 1];
    return latestMission.agent_status?.[agentId] || 'STANDBY';
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {agents.map((agent) => (
        <AgentCard
          key={agent.id}
          agent={agent}
          status={getAgentStatus(agent.id)}
        />
      ))}
    </div>
  );
};

// Intelligence Report Viewer
const IntelligenceReportViewer = ({ report }) => {
  if (!report) {
    return (
      <div className="bg-gray-900 border border-gray-700 rounded-lg p-8 text-center">
        <div className="text-6xl text-gray-600 mb-4">📊</div>
        <h3 className="text-xl text-gray-400">No intelligence report available</h3>
        <p className="text-gray-500 mt-2">Complete a mission to view detailed analysis</p>
      </div>
    );
  }

  const getThreatColor = (level) => {
    switch (level) {
      case 'CRITICAL': return 'text-red-400';
      case 'HIGH': return 'text-orange-400';
      case 'MEDIUM': return 'text-yellow-400';
      default: return 'text-green-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Executive Summary */}
      <div className="bg-gray-900 border border-gray-700 rounded-lg p-6">
        <div className="flex items-center mb-4">
          <div className="bg-cyan-500 rounded-full p-2 mr-3">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-cyan-400">📊 EXECUTIVE SUMMARY</h2>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className={`text-2xl font-bold ${getThreatColor(report.executive_summary.threat_level)}`}>
              {report.executive_summary.threat_level}
            </div>
            <div className="text-sm text-gray-400">Threat Level</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-cyan-400">
              {report.executive_summary.compliance_score}%
            </div>
            <div className="text-sm text-gray-400">Compliance Score</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-400">
              {report.executive_summary.critical_findings}
            </div>
            <div className="text-sm text-gray-400">Critical Issues</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-400">
              {report.executive_summary.optimization_potential}
            </div>
            <div className="text-sm text-gray-400">Optimization Potential</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Performance Metrics */}
        <div className="bg-gray-900 border border-gray-700 rounded-lg p-6">
          <div className="flex items-center mb-4">
            <div className="bg-orange-500 rounded-full p-2 mr-3">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h3 className="text-lg font-bold text-orange-400">⚡ PERFORMANCE METRICS</h3>
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Files Analyzed</span>
              <span className="text-white font-bold">{report.performance_metrics.files_analyzed}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Anti-patterns Found</span>
              <span className="text-white font-bold">{report.performance_metrics.anti_patterns_found}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Compliance Score</span>
              <span className="text-white font-bold">{report.performance_metrics.compliance_score}%</span>
            </div>
          </div>
        </div>

        {/* Cost Analysis */}
        <div className="bg-gray-900 border border-gray-700 rounded-lg p-6">
          <div className="flex items-center mb-4">
            <div className="bg-green-500 rounded-full p-2 mr-3">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
              </svg>
            </div>
            <h3 className="text-lg font-bold text-green-400">💰 COST ANALYSIS</h3>
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Estimated Hourly Cost</span>
              <span className="text-white font-bold">${report.cost_analysis.hourly_cost || 'N/A'}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Daily Cost</span>
              <span className="text-white font-bold">${report.cost_analysis.daily_cost || 'N/A'}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Potential Savings</span>
              <span className="text-white font-bold">${(report.executive_summary.estimated_cost_savings || 0).toFixed(2)}/day</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recommended Actions */}
      <div className="bg-gray-900 border border-gray-700 rounded-lg p-6">
        <div className="flex items-center mb-4">
          <div className="bg-green-500 rounded-full p-2 mr-3">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h3 className="text-lg font-bold text-green-400">🎯 RECOMMENDED ACTIONS</h3>
        </div>
        
        {report.recommended_actions.length > 0 ? (
          <div className="space-y-2">
            {report.recommended_actions.map((action, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className="text-green-400 mt-1">✓</div>
                <span className="text-gray-300">{action}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-400">
            No specific recommendations at this time. Your code appears to follow best practices.
          </p>
        )}
      </div>
    </div>
  );
};

// Mission History Component
const MissionHistory = ({ missions, onSelectMission }) => {
  return (
    <div className="bg-gray-900 border border-gray-700 rounded-lg p-6">
      <div className="flex items-center mb-4">
        <div className="bg-cyan-500 rounded-full p-2 mr-3">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
        </div>
        <h2 className="text-xl font-bold text-cyan-400">📋 MISSION HISTORY</h2>
      </div>
      
      {missions.length > 0 ? (
        <div className="space-y-3">
          {missions.map((mission) => (
            <div
              key={mission.mission_id}
              onClick={() => onSelectMission(mission)}
              className="border border-gray-600 rounded-lg p-4 cursor-pointer hover:border-cyan-500 transition-all duration-200"
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h4 className="font-bold text-white mb-1">{mission.mission_id}</h4>
                  <p className="text-sm text-gray-400">
                    Started: {new Date(mission.start_time).toLocaleString()}
                  </p>
                </div>
                <StatusBadge status={mission.status} />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <div className="text-4xl text-gray-600 mb-2">📋</div>
          <p className="text-gray-400">No missions deployed yet. Launch your first analysis mission above.</p>
        </div>
      )}
    </div>
  );
};

// Tab Navigation Component
const TabNavigation = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'mission', label: '🎯 MISSION CONTROL', icon: '🎯' },
    { id: 'intelligence', label: '📊 INTELLIGENCE', icon: '📊' },
    { id: 'agents', label: '🤖 AGENTS', icon: '🤖' },
    { id: 'config', label: '⚙️ CONFIGURATION', icon: '⚙️' }
  ];

  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg mb-6">
      <div className="flex flex-wrap">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 min-w-0 px-4 py-3 text-sm font-medium transition-all duration-200 ${
              activeTab === tab.id
                ? 'bg-cyan-500 text-white border-b-2 border-cyan-300'
                : 'text-gray-400 hover:text-white hover:bg-gray-700'
            }`}
          >
            <span className="block truncate">{tab.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

// Main Dashboard Component
const SPARK007Dashboard = () => {
  const [activeTab, setActiveTab] = useState('mission');
  const [missions, setMissions] = useState([]);
  const [selectedMission, setSelectedMission] = useState(null);
  const [intelligenceReport, setIntelligenceReport] = useState(null);
  const [loading, setLoading] = useState(false);

  const intelligence = new MI6Intelligence();

  // Handle mission launch
  const handleMissionLaunched = async (result) => {
    const newMission = {
      mission_id: result.mission_id,
      status: result.status,
      start_time: new Date().toISOString(),
      agent_status: {
        golden_eye: 'INFILTRATING',
        skyfall: 'ANALYZING',
        quantum: 'INTERROGATING',
        agent_007: 'CONFIGURING'
      }
    };
    
    setMissions(prev => [...prev, newMission]);
    setSelectedMission(newMission);
    
    // Start polling for mission status
    pollMissionStatus(result.mission_id);
  };

  // Poll mission status
  const pollMissionStatus = async (missionId) => {
    const pollInterval = setInterval(async () => {
      try {
        const status = await intelligence.getMissionStatus(missionId);
        
        setMissions(prev => prev.map(m => 
          m.mission_id === missionId ? { ...m, ...status } : m
        ));
        
        if (selectedMission?.mission_id === missionId) {
          setSelectedMission(prev => ({ ...prev, ...status }));
        }
        
        // If mission complete, get intelligence report
        if (status.status === 'MISSION_COMPLETE') {
          clearInterval(pollInterval);
          const report = await intelligence.getIntelligenceReport(missionId);
          setIntelligenceReport(report);
        }
        
        if (status.status === 'MISSION_FAILED') {
          clearInterval(pollInterval);
        }
      } catch (error) {
        console.error('Error polling mission status:', error);
        clearInterval(pollInterval);
      }
    }, 3000);
  };

  // Handle mission selection
  const handleSelectMission = async (mission) => {
    setSelectedMission(mission);
    setLoading(true);
    
    try {
      if (mission.status === 'MISSION_COMPLETE') {
        const report = await intelligence.getIntelligenceReport(mission.mission_id);
        setIntelligenceReport(report);
      } else {
        setIntelligenceReport(null);
      }
    } catch (error) {
      console.error('Error fetching intelligence report:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="bg-gradient-to-r from-black via-gray-900 to-black border-b-2 border-cyan-500">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full flex items-center justify-center text-xl">
                🕴️
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold tracking-wider">SPARK007</h1>
                <p className="text-sm text-cyan-400">MI6 INTELLIGENCE</p>
              </div>
            </div>
            <div className="hidden md:block">
              <p className="text-sm italic text-gray-400">"Licensed to Optimize"</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <TabNavigation activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Mission Control Tab */}
        {activeTab === 'mission' && (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <MissionLauncher onMissionLaunched={handleMissionLaunched} />
            <MissionHistory missions={missions} onSelectMission={handleSelectMission} />
          </div>
        )}

        {/* Intelligence Tab */}
        {activeTab === 'intelligence' && (
          <div>
            {loading ? (
              <div className="bg-gray-900 border border-gray-700 rounded-lg p-8 text-center">
                <LoadingSpinner size="lg" />
                <p className="mt-4 text-lg">Decrypting intelligence report...</p>
              </div>
            ) : (
              <IntelligenceReportViewer report={intelligenceReport} />
            )}
          </div>
        )}

        {/* Agents Tab */}
        {activeTab === 'agents' && (
          <div>
            <h2 className="text-2xl font-bold mb-6 text-cyan-400">🕴️ AGENT STATUS NETWORK</h2>
            <AgentStatusDashboard missions={missions} />
            
            {selectedMission && (
              <div className="mt-8 bg-gray-900 border border-gray-700 rounded-lg p-6">
                <h3 className="text-xl font-bold mb-4">Mission: {selectedMission.mission_id}</h3>
                <p className="text-gray-400 mb-4">Status: {selectedMission.status}</p>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {Object.entries(selectedMission.agent_status || {}).map(([agentId, status]) => (
                    <div key={agentId} className="text-center">
                      <div className="text-sm text-gray-300 mb-1">{agentId.replace('_', ' ').toUpperCase()}</div>
                      <StatusBadge status={status} />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Configuration Tab */}
        {activeTab === 'config' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-gray-900 border border-gray-700 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <div className="bg-cyan-500 rounded-full p-2 mr-3">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-cyan-400">🔧 SYSTEM CONFIGURATION</h3>
              </div>
              <p className="text-gray-400 mb-4">
                Advanced configuration options for MI6 Intelligence System.
                Access restricted to authorized personnel only.
              </p>
              <button className="bg-gray-700 text-gray-400 px-4 py-2 rounded cursor-not-allowed">
                Q Branch Access Required
              </button>
            </div>
            
            <div className="bg-gray-900 border border-gray-700 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <div className="bg-green-500 rounded-full p-2 mr-3">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-green-400">📡 SYSTEM STATUS</h3>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">MI6 Backend</span>
                  <span className="text-green-400 font-bold">Operational</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Agent Network</span>
                  <span className="text-green-400 font-bold">All agents ready</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Intelligence Database</span>
                  <span className="text-green-400 font-bold">Connected</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-800 bg-black mt-12">
        <div className="container mx-auto px-4 py-4">
          <p className="text-center text-gray-400 text-sm">
            🕴️ SPARK007 MI6 Intelligence System - Version 1.0.0 - Licensed to Optimize
          </p>
        </div>
      </footer>
    </div>
  );
};

export default SPARK007Dashboard;