# SPARK007 LLM-Powered AI Agents
# llm_agents.py

import asyncio
import json
import re
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import openai
from pydantic import BaseModel, Field
import ast
from dataclasses import dataclass

# Configuration
class LLMConfig:
    OPENAI_API_KEY = "your-openai-api-key-here"  # Set via environment variable
    MODEL_NAME = "gpt-4-turbo"
    MAX_TOKENS = 4000
    TEMPERATURE = 0.1
    
    # Cost tracking
    INPUT_TOKEN_COST = 0.01 / 1000  # $0.01 per 1K input tokens
    OUTPUT_TOKEN_COST = 0.03 / 1000  # $0.03 per 1K output tokens

# LLM Response Models
@dataclass
class OptimizationSuggestion:
    rule_id: str
    severity: str
    description: str
    original_code: str
    optimized_code: str
    explanation: str
    estimated_improvement: str
    confidence_score: float

@dataclass
class CodeAnalysisResult:
    issues_found: List[OptimizationSuggestion]
    overall_assessment: str
    complexity_score: int
    maintainability_score: int
    performance_score: int
    recommendations: List[str]

@dataclass
class NaturalLanguageQuery:
    user_query: str
    generated_code: str
    explanation: str
    performance_notes: str
    test_cases: List[str]

# Base LLM Agent Class
class BaseLLMAgent:
    def __init__(self, config: LLMConfig):
        self.config = config
        self.client = openai.AsyncOpenAI(api_key=config.OPENAI_API_KEY)
        self.usage_stats = {
            "total_requests": 0,
            "total_input_tokens": 0,
            "total_output_tokens": 0,
            "total_cost": 0.0
        }
    
    async def _make_llm_request(self, messages: List[Dict], max_tokens: int = None) -> Dict[str, Any]:
        """Make a request to the LLM and track usage"""
        try:
            response = await self.client.chat.completions.create(
                model=self.config.MODEL_NAME,
                messages=messages,
                max_tokens=max_tokens or self.config.MAX_TOKENS,
                temperature=self.config.TEMPERATURE
            )
            
            # Track usage
            usage = response.usage
            input_cost = usage.prompt_tokens * self.config.INPUT_TOKEN_COST
            output_cost = usage.completion_tokens * self.config.OUTPUT_TOKEN_COST
            total_cost = input_cost + output_cost
            
            self.usage_stats["total_requests"] += 1
            self.usage_stats["total_input_tokens"] += usage.prompt_tokens
            self.usage_stats["total_output_tokens"] += usage.completion_tokens
            self.usage_stats["total_cost"] += total_cost
            
            return {
                "content": response.choices[0].message.content,
                "usage": usage,
                "cost": total_cost
            }
            
        except Exception as e:
            print(f"LLM request failed: {e}")
            return {"content": "", "usage": None, "cost": 0, "error": str(e)}

    def get_usage_statistics(self) -> Dict[str, Any]:
        """Get usage statistics for cost tracking"""
        return self.usage_stats.copy()

# Oracle Agent - Advanced Code Analysis
class OracleAgent(BaseLLMAgent):
    """Advanced LLM-powered code analysis and optimization agent"""
    
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self.agent_name = "Oracle"
        
    async def analyze_spark_code(self, code_snippet: str, context: Dict[str, Any]) -> CodeAnalysisResult:
        """Analyze Spark code and provide optimization suggestions"""
        
        system_prompt = """You are an expert Spark optimization specialist with deep knowledge of PySpark, Scala Spark, and performance tuning. 
        
        Analyze the provided code and identify:
        1. Performance bottlenecks and anti-patterns
        2. Memory usage issues
        3. Shuffle operation inefficiencies
        4. Join optimization opportunities
        5. Caching strategy improvements
        6. Partitioning optimizations
        
        Provide specific, actionable recommendations with code examples."""
        
        user_prompt = f"""
        Analyze this Spark code for optimization opportunities:
        
        ```
        {code_snippet}
        ```
        
        Context: {json.dumps(context, indent=2)}
        
        Please provide:
        1. Specific issues found (with severity: CRITICAL, HIGH, MEDIUM, LOW)
        2. Optimized code examples
        3. Expected performance improvement percentages
        4. Explanation of why each optimization helps
        5. Overall assessment scores (1-100) for complexity, maintainability, and performance
        
        Format your response as JSON with the following structure:
        {{
            "issues": [
                {{
                    "rule_id": "PERF_001",
                    "severity": "HIGH",
                    "description": "Issue description",
                    "original_code": "problematic code",
                    "optimized_code": "improved code",
                    "explanation": "why this optimization helps",
                    "estimated_improvement": "20-30% faster execution",
                    "confidence_score": 0.85
                }}
            ],
            "overall_assessment": "Summary of code quality",
            "scores": {{
                "complexity": 75,
                "maintainability": 80,
                "performance": 60
            }},
            "recommendations": ["recommendation 1", "recommendation 2"]
        }}
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response = await self._make_llm_request(messages, max_tokens=3000)
        
        try:
            # Parse JSON response
            result_data = json.loads(response["content"])
            
            # Convert to structured result
            issues = [
                OptimizationSuggestion(
                    rule_id=issue.get("rule_id", "UNKNOWN"),
                    severity=issue.get("severity", "MEDIUM"),
                    description=issue.get("description", ""),
                    original_code=issue.get("original_code", ""),
                    optimized_code=issue.get("optimized_code", ""),
                    explanation=issue.get("explanation", ""),
                    estimated_improvement=issue.get("estimated_improvement", "Unknown"),
                    confidence_score=issue.get("confidence_score", 0.5)
                )
                for issue in result_data.get("issues", [])
            ]
            
            scores = result_data.get("scores", {})
            
            return CodeAnalysisResult(
                issues_found=issues,
                overall_assessment=result_data.get("overall_assessment", "Analysis completed"),
                complexity_score=scores.get("complexity", 50),
                maintainability_score=scores.get("maintainability", 50),
                performance_score=scores.get("performance", 50),
                recommendations=result_data.get("recommendations", [])
            )
            
        except json.JSONDecodeError:
            # Fallback if JSON parsing fails
            return CodeAnalysisResult(
                issues_found=[],
                overall_assessment="Analysis completed but response format was invalid",
                complexity_score=50,
                maintainability_score=50,
                performance_score=50,
                recommendations=["Unable to parse detailed recommendations"]
            )

# JARVIS Agent - Natural Language Interface
class JarvisAgent(BaseLLMAgent):
    """Natural language to Spark code conversion agent"""
    
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self.agent_name = "JARVIS"
    
    async def process_natural_query(self, user_query: str, codebase_context: Dict[str, Any]) -> NaturalLanguageQuery:
        """Convert natural language to optimized Spark code"""
        
        system_prompt = """You are JARVIS, MI6's AI assistant for Spark optimization and code generation.
        
        Convert user requests into optimized PySpark code. Always consider:
        - Performance implications
        - Memory efficiency
        - Proper join strategies (broadcast when appropriate)
        - Efficient data types and operations
        - Best practices for large-scale data processing
        
        Provide working, production-ready code with explanations."""
        
        examples = [
            {
                "user": "Join customer data with orders and filter for high-value customers",
                "assistant": """Here's an optimized solution using broadcast join:

```python
from pyspark.sql.functions import broadcast, col, sum as spark_sum

# Assuming customer_df is smaller - use broadcast join
high_value_threshold = 10000

# Calculate customer lifetime value
customer_lifetime_value = orders_df.groupBy("customer_id") \
    .agg(spark_sum("order_amount").alias("lifetime_value"))

# Filter high-value customers
high_value_customers = customer_lifetime_value.filter(
    col("lifetime_value") > high_value_threshold
)

# Broadcast join (assuming customer_df is smaller)
result = high_value_customers.join(
    broadcast(customer_df), 
    "customer_id"
).select(
    customer_df["*"],
    high_value_customers["lifetime_value"]
)
```

**Performance Notes:**
- Uses broadcast join to avoid shuffle operations
- Filters data early to reduce processing
- Groups efficiently before joining"""
            }
        ]
        
        user_prompt = f"""
        Context: {json.dumps(codebase_context, indent=2)}
        
        User Request: {user_query}
        
        Generate optimized PySpark code with:
        1. Working, production-ready code
        2. Performance optimizations applied
        3. Clear explanations of optimization choices
        4. Potential test cases
        
        Format as JSON:
        {{
            "generated_code": "optimized PySpark code",
            "explanation": "detailed explanation",
            "performance_notes": "optimization notes",
            "test_cases": ["test case 1", "test case 2"]
        }}
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
        ]
        
        # Add examples
        for example in examples:
            messages.extend([
                {"role": "user", "content": example["user"]},
                {"role": "assistant", "content": example["assistant"]}
            ])
        
        messages.append({"role": "user", "content": user_prompt})
        
        response = await self._make_llm_request(messages, max_tokens=2500)
        
        try:
            result_data = json.loads(response["content"])
            
            return NaturalLanguageQuery(
                user_query=user_query,
                generated_code=result_data.get("generated_code", "# Code generation failed"),
                explanation=result_data.get("explanation", "No explanation available"),
                performance_notes=result_data.get("performance_notes", "No performance notes"),
                test_cases=result_data.get("test_cases", [])
            )
            
        except json.JSONDecodeError:
            return NaturalLanguageQuery(
                user_query=user_query,
                generated_code="# Failed to generate code - invalid response format",
                explanation="Code generation failed due to response parsing error",
                performance_notes="Unable to provide performance notes",
                test_cases=[]
            )

# Error Detective Agent - Intelligent Debugging
class ErrorDetectiveAgent(BaseLLMAgent):
    """Intelligent Spark error analysis and resolution agent"""
    
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self.agent_name = "ErrorDetective"
    
    async def diagnose_spark_error(self, error_log: str, code_context: str) -> Dict[str, Any]:
        """Diagnose Spark errors and provide solutions"""
        
        system_prompt = """You are an expert Spark debugger. Analyze error logs and provide:
        
        1. Root cause analysis
        2. Step-by-step fix instructions
        3. Prevention strategies
        4. Alternative approaches
        5. Code corrections
        
        Focus on common Spark issues like OOM, shuffle errors, serialization problems, etc."""
        
        user_prompt = f"""
        Analyze this Spark error:
        
        Error Log:
        ```
        {error_log}
        ```
        
        Code Context:
        ```
        {code_context}
        ```
        
        Provide analysis in JSON format:
        {{
            "root_cause": "detailed cause analysis",
            "error_type": "OOM|SHUFFLE|SERIALIZATION|JOIN|OTHER",
            "severity": "CRITICAL|HIGH|MEDIUM|LOW",
            "fix_steps": ["step 1", "step 2"],
            "code_fix": "corrected code if applicable",
            "prevention": ["prevention tip 1", "prevention tip 2"],
            "alternatives": ["alternative approach 1"]
        }}
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response = await self._make_llm_request(messages, max_tokens=2000)
        
        try:
            return json.loads(response["content"])
        except json.JSONDecodeError:
            return {
                "root_cause": "Failed to analyze error",
                "error_type": "OTHER",
                "severity": "MEDIUM",
                "fix_steps": ["Check logs manually", "Consult Spark documentation"],
                "code_fix": "# Unable to generate fix",
                "prevention": ["Monitor application closely"],
                "alternatives": ["Seek manual debugging"]
            }

# Performance Prophet - Predictive Analysis
class PerformanceProphetAgent(BaseLLMAgent):
    """Predictive performance modeling and capacity planning agent"""
    
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self.agent_name = "PerformanceProphet"
    
    async def predict_job_performance(self, code_ast: Dict[str, Any], dataset_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Predict Spark job performance based on code and data characteristics"""
        
        system_prompt = """You are a performance prediction expert. Based on code analysis and dataset metadata, predict:
        
        1. Estimated runtime
        2. Memory requirements
        3. CPU utilization
        4. Optimal cluster configuration
        5. Cost estimates
        6. Potential bottlenecks
        
        Use your knowledge of Spark internals and performance characteristics."""
        
        user_prompt = f"""
        Predict performance for this Spark job:
        
        Code Analysis: {json.dumps(code_ast, indent=2)}
        Dataset Metadata: {json.dumps(dataset_metadata, indent=2)}
        
        Provide predictions in JSON:
        {{
            "estimated_runtime_minutes": 45,
            "memory_gb_required": 32,
            "cpu_cores_optimal": 16,
            "cluster_recommendation": {{
                "driver": "r5.xlarge",
                "workers": 4,
                "worker_type": "r5.2xlarge"
            }},
            "cost_estimate": {{
                "hourly": 3.20,
                "job_total": 2.40
            }},
            "bottlenecks": ["shuffle operations", "large joins"],
            "confidence": 0.75
        }}
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response = await self._make_llm_request(messages, max_tokens=1500)
        
        try:
            return json.loads(response["content"])
        except json.JSONDecodeError:
            return {
                "estimated_runtime_minutes": 30,
                "memory_gb_required": 16,
                "cpu_cores_optimal": 8,
                "cluster_recommendation": {
                    "driver": "r5.large",
                    "workers": 2,
                    "worker_type": "r5.xlarge"
                },
                "cost_estimate": {
                    "hourly": 2.0,
                    "job_total": 1.0
                },
                "bottlenecks": ["Unable to predict"],
                "confidence": 0.3
            }

# Documentation Agent - Intelligent Documentation Generator
class DocumentationAgent(BaseLLMAgent):
    """Automated documentation generation for optimizations"""
    
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self.agent_name = "DocumentationAgent"
    
    async def generate_optimization_guide(self, analysis_results: Dict[str, Any]) -> Dict[str, str]:
        """Generate comprehensive optimization documentation"""
        
        system_prompt = """Create comprehensive optimization documentation in MI6 mission briefing format.
        
        Include:
        1. Executive summary for stakeholders
        2. Technical deep dive for developers
        3. Implementation roadmap
        4. ROI analysis
        5. Risk assessment
        
        Use professional, clear language with MI6 terminology."""
        
        user_prompt = f"""
        Generate optimization guide based on analysis:
        
        {json.dumps(analysis_results, indent=2)}
        
        Create sections:
        1. Executive Summary
        2. Technical Analysis
        3. Implementation Plan
        4. ROI Projection
        5. Risk Assessment
        
        Format as JSON with each section as a string value.
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response = await self._make_llm_request(messages, max_tokens=3000)
        
        try:
            return json.loads(response["content"])
        except json.JSONDecodeError:
            return {
                "executive_summary": "Optimization analysis completed with recommendations available.",
                "technical_analysis": "Technical details available in source analysis.",
                "implementation_plan": "Follow standard optimization procedures.",
                "roi_projection": "Performance improvements expected.",
                "risk_assessment": "Low risk optimization changes recommended."
            }

# Test Generator Agent - Automated Testing
class TestGeneratorAgent(BaseLLMAgent):
    """Automated test case generation for Spark code"""
    
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self.agent_name = "TestGenerator"
    
    async def generate_performance_tests(self, spark_code: str) -> Dict[str, List[str]]:
        """Generate comprehensive test cases for Spark code"""
        
        system_prompt = """Generate comprehensive test cases for Spark code including:
        
        1. Unit tests for transformations
        2. Performance benchmarks
        3. Data quality validations
        4. Edge case scenarios
        5. Integration tests
        
        Use pytest and PySpark testing best practices."""
        
        user_prompt = f"""
        Generate test cases for this Spark code:
        
        ```python
        {spark_code}
        ```
        
        Provide tests in JSON format:
        {{
            "unit_tests": ["test code 1", "test code 2"],
            "performance_tests": ["perf test 1"],
            "data_quality_tests": ["quality test 1"],
            "edge_case_tests": ["edge test 1"],
            "integration_tests": ["integration test 1"]
        }}
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response = await self._make_llm_request(messages, max_tokens=2500)
        
        try:
            return json.loads(response["content"])
        except json.JSONDecodeError:
            return {
                "unit_tests": ["# Failed to generate unit tests"],
                "performance_tests": ["# Failed to generate performance tests"],
                "data_quality_tests": ["# Failed to generate data quality tests"],
                "edge_case_tests": ["# Failed to generate edge case tests"],
                "integration_tests": ["# Failed to generate integration tests"]
            }

# LLM Agent Coordinator
class LLMAgentCoordinator:
    """Coordinates multiple LLM agents for comprehensive analysis"""
    
    def __init__(self, config: LLMConfig):
        self.config = config
        self.agents = {
            "oracle": OracleAgent(config),
            "jarvis": JarvisAgent(config),
            "detective": ErrorDetectiveAgent(config),
            "prophet": PerformanceProphetAgent(config),
            "documenter": DocumentationAgent(config),
            "tester": TestGeneratorAgent(config)
        }
    
    async def comprehensive_analysis(self, code: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Run comprehensive analysis using multiple LLM agents"""
        
        results = {}
        
        # Run Oracle analysis
        try:
            oracle_result = await self.agents["oracle"].analyze_spark_code(code, context)
            results["code_analysis"] = oracle_result
        except Exception as e:
            results["code_analysis"] = {"error": str(e)}
        
        # Generate performance prediction
        try:
            prophet_result = await self.agents["prophet"].predict_job_performance(
                context.get("ast_data", {}), 
                context.get("dataset_metadata", {})
            )
            results["performance_prediction"] = prophet_result
        except Exception as e:
            results["performance_prediction"] = {"error": str(e)}
        
        # Generate tests
        try:
            test_result = await self.agents["tester"].generate_performance_tests(code)
            results["generated_tests"] = test_result
        except Exception as e:
            results["generated_tests"] = {"error": str(e)}
        
        # Generate documentation
        try:
            doc_result = await self.agents["documenter"].generate_optimization_guide(results)
            results["documentation"] = doc_result
        except Exception as e:
            results["documentation"] = {"error": str(e)}
        
        # Collect usage statistics
        total_cost = sum(agent.get_usage_statistics()["total_cost"] for agent in self.agents.values())
        total_requests = sum(agent.get_usage_statistics()["total_requests"] for agent in self.agents.values())
        
        results["llm_usage"] = {
            "total_cost": total_cost,
            "total_requests": total_requests,
            "cost_per_analysis": total_cost
        }
        
        return results
    
    async def natural_language_interface(self, user_query: str, context: Dict[str, Any]) -> NaturalLanguageQuery:
        """Handle natural language queries via JARVIS"""
        return await self.agents["jarvis"].process_natural_query(user_query, context)
    
    async def debug_error(self, error_log: str, code_context: str) -> Dict[str, Any]:
        """Debug errors via Detective agent"""
        return await self.agents["detective"].diagnose_spark_error(error_log, code_context)
    
    def get_total_usage_stats(self) -> Dict[str, Any]:
        """Get aggregated usage statistics across all agents"""
        total_stats = {
            "total_requests": 0,
            "total_input_tokens": 0,
            "total_output_tokens": 0,
            "total_cost": 0.0,
            "agent_breakdown": {}
        }
        
        for agent_name, agent in self.agents.items():
            stats = agent.get_usage_statistics()
            total_stats["total_requests"] += stats["total_requests"]
            total_stats["total_input_tokens"] += stats["total_input_tokens"]
            total_stats["total_output_tokens"] += stats["total_output_tokens"]
            total_stats["total_cost"] += stats["total_cost"]
            total_stats["agent_breakdown"][agent_name] = stats
        
        return total_stats

# Usage Example and Testing
async def test_llm_agents():
    """Test LLM agents with sample Spark code"""
    
    config = LLMConfig()
    coordinator = LLMAgentCoordinator(config)
    
    # Sample problematic Spark code
    sample_code = """
from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder.appName("TestApp").getOrCreate()

# Load large datasets
large_df = spark.read.parquet("s3://data/large_dataset")
small_df = spark.read.parquet("s3://data/small_dataset")

# Problematic join without broadcast
result = large_df.join(small_df, "key")

# Dangerous collect operation
data = result.collect()
for row in data:
    print(row)

# Inefficient caching
result.cache()
result.cache()

# Write result
result.write.mode("overwrite").parquet("s3://output/result")
"""
    
    context = {
        "ast_data": {"files_analyzed": 5, "anti_patterns": ["collect", "join"]},
        "dataset_metadata": {"large_df_size": "100GB", "small_df_size": "1GB"}
    }
    
    # Run comprehensive analysis
    analysis_results = await coordinator.comprehensive_analysis(sample_code, context)
    
    print("🕴️ MI6 LLM Analysis Complete!")
    print(f"💰 Total Cost: ${analysis_results['llm_usage']['total_cost']:.4f}")
    print(f"📊 Analysis Quality: {len(analysis_results)} components analyzed")
    
    return analysis_results

if __name__ == "__main__":
    # Test the LLM agents
    import asyncio
    results = asyncio.run(test_llm_agents())
    print(json.dumps(results, indent=2, default=str))