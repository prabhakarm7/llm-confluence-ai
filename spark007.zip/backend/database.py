# SPARK007 Database Models and Configuration
# database.py

from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, DateTime, JSON, Text, Float, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.sql import func
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from datetime import datetime
import os
import redis
import json

# Database Configuration
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://spark007:mi6secret@localhost:5432/spark007_db")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")

# SQLAlchemy setup
engine = create_engine(DATABASE_URL, echo=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Redis setup for real-time agent communication
redis_client = redis.from_url(REDIS_URL, decode_responses=True)

# Database Models
class Mission(Base):
    __tablename__ = "missions"
    
    id = Column(Integer, primary_key=True, index=True)
    mission_id = Column(String, unique=True, index=True)
    repo_url = Column(String)
    classification_level = Column(String)
    optimization_priority = Column(String)
    workload_type = Column(String, nullable=True)
    target_platform = Column(String)
    status = Column(String, default="AGENTS_DEPLOYED")
    start_time = Column(DateTime, default=func.now())
    completion_time = Column(DateTime, nullable=True)
    agent_status = Column(JSON, default={})
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

class IntelligenceReport(Base):
    __tablename__ = "intelligence_reports"
    
    id = Column(Integer, primary_key=True, index=True)
    mission_id = Column(String, index=True)
    classification = Column(String)
    executive_summary = Column(JSON)
    agent_reports = Column(JSON)
    recommended_actions = Column(JSON)
    performance_metrics = Column(JSON)
    cost_analysis = Column(JSON)
    ast_analysis = Column(JSON, nullable=True)
    performance_analysis = Column(JSON, nullable=True)
    rules_analysis = Column(JSON, nullable=True)
    cluster_analysis = Column(JSON, nullable=True)
    threat_level = Column(String)
    compliance_score = Column(Float)
    created_at = Column(DateTime, default=func.now())

class OptimizationRule(Base):
    __tablename__ = "optimization_rules"
    
    id = Column(Integer, primary_key=True, index=True)
    rule_id = Column(String, unique=True, index=True)
    rule_name = Column(String)
    category = Column(String)  # performance, memory, shuffle, caching, partitioning
    severity = Column(String)  # CRITICAL, HIGH, MEDIUM, LOW
    description = Column(Text)
    pattern_regex = Column(String, nullable=True)
    recommendation = Column(Text)
    enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())

class AgentPerformance(Base):
    __tablename__ = "agent_performance"
    
    id = Column(Integer, primary_key=True, index=True)
    mission_id = Column(String, index=True)
    agent_name = Column(String)
    start_time = Column(DateTime)
    end_time = Column(DateTime, nullable=True)
    status = Column(String)
    execution_time_seconds = Column(Float, nullable=True)
    memory_usage_mb = Column(Float, nullable=True)
    error_message = Column(Text, nullable=True)
    results_data = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=func.now())

class CodeRepository(Base):
    __tablename__ = "code_repositories"
    
    id = Column(Integer, primary_key=True, index=True)
    repo_url = Column(String, unique=True, index=True)
    repo_name = Column(String)
    last_analyzed = Column(DateTime, nullable=True)
    total_missions = Column(Integer, default=0)
    average_compliance_score = Column(Float, nullable=True)
    primary_language = Column(String, nullable=True)
    total_files = Column(Integer, default=0)
    lines_of_code = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

# Create tables
Base.metadata.create_all(bind=engine)

# Database dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Database Operations Class
class DatabaseOperations:
    def __init__(self, db: Session):
        self.db = db
    
    def create_mission(self, mission_data: Dict[str, Any]) -> Mission:
        """Create a new mission record"""
        db_mission = Mission(**mission_data)
        self.db.add(db_mission)
        self.db.commit()
        self.db.refresh(db_mission)
        return db_mission
    
    def update_mission_status(self, mission_id: str, status: str, agent_status: Dict[str, str] = None):
        """Update mission status and agent statuses"""
        mission = self.db.query(Mission).filter(Mission.mission_id == mission_id).first()
        if mission:
            mission.status = status
            if agent_status:
                mission.agent_status = agent_status
            if status == "MISSION_COMPLETE":
                mission.completion_time = func.now()
            self.db.commit()
    
    def save_intelligence_report(self, report_data: Dict[str, Any]) -> IntelligenceReport:
        """Save intelligence report to database"""
        db_report = IntelligenceReport(**report_data)
        self.db.add(db_report)
        self.db.commit()
        self.db.refresh(db_report)
        return db_report
    
    def get_mission_by_id(self, mission_id: str) -> Optional[Mission]:
        """Get mission by ID"""
        return self.db.query(Mission).filter(Mission.mission_id == mission_id).first()
    
    def get_intelligence_report(self, mission_id: str) -> Optional[IntelligenceReport]:
        """Get intelligence report by mission ID"""
        return self.db.query(IntelligenceReport).filter(IntelligenceReport.mission_id == mission_id).first()
    
    def get_active_missions(self) -> List[Mission]:
        """Get all active missions"""
        return self.db.query(Mission).filter(
            Mission.status.in_(["AGENTS_DEPLOYED", "IN_PROGRESS"])
        ).order_by(Mission.start_time.desc()).all()
    
    def record_agent_performance(self, performance_data: Dict[str, Any]):
        """Record agent performance metrics"""
        db_performance = AgentPerformance(**performance_data)
        self.db.add(db_performance)
        self.db.commit()
    
    def update_repository_stats(self, repo_url: str, stats: Dict[str, Any]):
        """Update repository statistics"""
        repo = self.db.query(CodeRepository).filter(CodeRepository.repo_url == repo_url).first()
        if not repo:
            repo = CodeRepository(repo_url=repo_url, **stats)
            self.db.add(repo)
        else:
            for key, value in stats.items():
                setattr(repo, key, value)
        self.db.commit()

# Redis Operations for Real-time Communication
class RedisOperations:
    def __init__(self):
        self.client = redis_client
    
    def publish_agent_status(self, mission_id: str, agent_name: str, status: str, data: Dict = None):
        """Publish agent status update"""
        message = {
            "mission_id": mission_id,
            "agent_name": agent_name,
            "status": status,
            "timestamp": datetime.now().isoformat(),
            "data": data or {}
        }
        self.client.publish(f"agent_status:{mission_id}", json.dumps(message))
    
    def subscribe_to_mission(self, mission_id: str):
        """Subscribe to mission updates"""
        pubsub = self.client.pubsub()
        pubsub.subscribe(f"agent_status:{mission_id}")
        return pubsub
    
    def cache_mission_data(self, mission_id: str, data: Dict, ttl: int = 3600):
        """Cache mission data with TTL"""
        self.client.setex(f"mission_cache:{mission_id}", ttl, json.dumps(data))
    
    def get_cached_mission_data(self, mission_id: str) -> Optional[Dict]:
        """Get cached mission data"""
        data = self.client.get(f"mission_cache:{mission_id}")
        return json.loads(data) if data else None
    
    def store_agent_heartbeat(self, agent_name: str, mission_id: str):
        """Store agent heartbeat"""
        self.client.setex(f"heartbeat:{agent_name}:{mission_id}", 60, datetime.now().isoformat())
    
    def check_agent_health(self, agent_name: str, mission_id: str) -> bool:
        """Check if agent is healthy (heartbeat within last minute)"""
        return bool(self.client.get(f"heartbeat:{agent_name}:{mission_id}"))

# Initialize default optimization rules
def initialize_default_rules(db: Session):
    """Initialize default optimization rules"""
    default_rules = [
        {
            "rule_id": "PERF_001",
            "rule_name": "Broadcast Join Optimization",
            "category": "performance",
            "severity": "HIGH",
            "description": "Detect missing broadcast joins for dimension tables",
            "pattern_regex": r"\.join\((?!broadcast)",
            "recommendation": "Use broadcast joins for dimension tables to avoid shuffle operations"
        },
        {
            "rule_id": "PERF_002",
            "rule_name": "Avoid Collect Operations",
            "category": "performance", 
            "severity": "CRITICAL",
            "description": "Detect dangerous collect() operations that can cause driver OOM",
            "pattern_regex": r"\.collect\(\)",
            "recommendation": "Replace collect() with write operations or use take() with limits"
        },
        {
            "rule_id": "PERF_003",
            "rule_name": "Cartesian Join Detection",
            "category": "performance",
            "severity": "CRITICAL", 
            "description": "Detect cartesian joins that can cause exponential data growth",
            "pattern_regex": r"\.crossJoin\(",
            "recommendation": "Add proper join conditions or use broadcast joins if intentional"
        },
        {
            "rule_id": "MEM_001",
            "rule_name": "Inefficient Caching",
            "category": "memory",
            "severity": "MEDIUM",
            "description": "Detect unnecessary or inefficient caching patterns",
            "pattern_regex": r"\.cache\(\).*\.cache\(\)",
            "recommendation": "Avoid double caching and cache only frequently accessed DataFrames"
        },
        {
            "rule_id": "MEM_002", 
            "rule_name": "Memory Leak in Loops",
            "category": "memory",
            "severity": "HIGH",
            "description": "Detect potential memory leaks in iterative operations",
            "pattern_regex": r"for.*in.*\.collect\(\)",
            "recommendation": "Use DataFrame operations instead of collecting and iterating"
        },
        {
            "rule_id": "PART_001",
            "rule_name": "Excessive Small Files",
            "category": "partitioning",
            "severity": "MEDIUM",
            "description": "Detect operations that might create too many small files",
            "pattern_regex": r"\.repartition\(1\)",
            "recommendation": "Use coalesce() instead of repartition(1) to reduce shuffle"
        },
        {
            "rule_id": "SQL_001",
            "rule_name": "Inefficient SQL Queries",
            "category": "performance",
            "severity": "MEDIUM",
            "description": "Detect inefficient SQL query patterns",
            "pattern_regex": r"SELECT \* FROM",
            "recommendation": "Avoid SELECT * and specify only required columns"
        },
        {
            "rule_id": "CACHE_001",
            "rule_name": "Missing Cache for Reused DataFrames", 
            "category": "caching",
            "severity": "MEDIUM",
            "description": "Detect DataFrames that are used multiple times without caching",
            "recommendation": "Cache DataFrames that are accessed multiple times"
        }
    ]
    
    for rule_data in default_rules:
        existing_rule = db.query(OptimizationRule).filter(
            OptimizationRule.rule_id == rule_data["rule_id"]
        ).first()
        
        if not existing_rule:
            db_rule = OptimizationRule(**rule_data)
            db.add(db_rule)
    
    db.commit()

# Enhanced Mission Analytics
class MissionAnalytics:
    def __init__(self, db: Session):
        self.db = db
    
    def get_mission_statistics(self) -> Dict[str, Any]:
        """Get comprehensive mission statistics"""
        total_missions = self.db.query(Mission).count()
        completed_missions = self.db.query(Mission).filter(Mission.status == "MISSION_COMPLETE").count()
        failed_missions = self.db.query(Mission).filter(Mission.status == "MISSION_FAILED").count()
        
        # Average completion time
        completed = self.db.query(Mission).filter(
            Mission.status == "MISSION_COMPLETE",
            Mission.completion_time.isnot(None)
        ).all()
        
        avg_completion_time = 0
        if completed:
            total_time = sum(
                (mission.completion_time - mission.start_time).total_seconds() 
                for mission in completed
            )
            avg_completion_time = total_time / len(completed) / 60  # in minutes
        
        # Top repositories by mission count
        top_repos = self.db.query(CodeRepository).order_by(
            CodeRepository.total_missions.desc()
        ).limit(5).all()
        
        return {
            "total_missions": total_missions,
            "completed_missions": completed_missions,
            "failed_missions": failed_missions,
            "success_rate": (completed_missions / total_missions * 100) if total_missions > 0 else 0,
            "average_completion_time_minutes": round(avg_completion_time, 2),
            "top_repositories": [
                {
                    "repo_name": repo.repo_name,
                    "mission_count": repo.total_missions,
                    "avg_compliance_score": repo.average_compliance_score
                }
                for repo in top_repos
            ]
        }
    
    def get_optimization_trends(self) -> Dict[str, Any]:
        """Get optimization trends and patterns"""
        reports = self.db.query(IntelligenceReport).order_by(
            IntelligenceReport.created_at.desc()
        ).limit(50).all()
        
        if not reports:
            return {"message": "No data available"}
        
        # Calculate trends
        avg_compliance = sum(r.compliance_score for r in reports if r.compliance_score) / len(reports)
        
        threat_levels = {}
        for report in reports:
            level = report.threat_level
            threat_levels[level] = threat_levels.get(level, 0) + 1
        
        # Most common optimization recommendations
        all_recommendations = []
        for report in reports:
            if report.recommended_actions:
                all_recommendations.extend(report.recommended_actions)
        
        recommendation_counts = {}
        for rec in all_recommendations:
            rec_key = rec[:50]  # First 50 chars as key
            recommendation_counts[rec_key] = recommendation_counts.get(rec_key, 0) + 1
        
        top_recommendations = sorted(
            recommendation_counts.items(), 
            key=lambda x: x[1], 
            reverse=True
        )[:5]
        
        return {
            "average_compliance_score": round(avg_compliance, 2),
            "threat_level_distribution": threat_levels,
            "top_recommendations": [
                {"recommendation": rec, "frequency": count}
                for rec, count in top_recommendations
            ],
            "total_reports_analyzed": len(reports)
        }

# Database Migration Helper
def create_sample_data(db: Session):
    """Create sample data for testing"""
    # Initialize default rules
    initialize_default_rules(db)
    
    # Create sample repository
    sample_repo = CodeRepository(
        repo_url="https://github.com/sample/spark-project",
        repo_name="sample-spark-project",
        total_files=25,
        lines_of_code=5000,
        primary_language="Python",
        average_compliance_score=75.5
    )
    db.add(sample_repo)
    db.commit()

if __name__ == "__main__":
    # Create tables and initialize data
    db = SessionLocal()
    try:
        create_sample_data(db)
        print("✅ Database initialized successfully!")
        print("🕴️ MI6 Intelligence Database ready for operations")
    finally:
        db.close()