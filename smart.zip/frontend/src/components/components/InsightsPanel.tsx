// components/InsightsPanel.tsx - REDESIGNED with Full Width Header + Comprehensive Metadata Table

import React from 'react';
import { 
  Box, 
  Typography, 
  Chip, 
  LinearProgress, 
  Avatar,
  Table,
  TableBody,
  TableRow,
  TableCell,
  Divider,
  Stack
} from '@mui/material';
import { 
  Person, 
  Business, 
  AccountBalance, 
  TrendingUp,
  Timeline,
  Star,
  Speed,
  Assessment,
  BusinessCenter,
  CorporateFare,
  ShowChart,
  Analytics,
  Psychology,
  Recommend,
  AutoAwesome,
  Circle
} from '@mui/icons-material';
import { Node, Edge } from 'reactflow';
import { AppNodeData, EdgeData } from '../types/GraphTypes';

interface InsightsPanelProps {
  selectedNode?: Node<AppNodeData> | null;
  selectedEdge?: Edge<EdgeData> | null;
  isHovered?: boolean;
  isDarkTheme?: boolean;
}

export const InsightsPanel: React.FC<InsightsPanelProps> = ({ 
  selectedNode, 
  selectedEdge,
  isHovered = false,
  isDarkTheme = true
}) => {
  const getNodeIcon = (type?: string) => {
    switch (type) {
      case 'CONSULTANT': return <BusinessCenter sx={{ color: '#6366f1', fontSize: '1.5rem' }} />;
      case 'FIELD_CONSULTANT': return <Person sx={{ color: '#6366f1', fontSize: '1.5rem' }} />;
      case 'COMPANY': return <CorporateFare sx={{ color: '#10b981', fontSize: '1.5rem' }} />;
      case 'PRODUCT': return <AccountBalance sx={{ color: '#3b82f6', fontSize: '1.5rem' }} />;
      case 'INCUMBENT_PRODUCT': return <Psychology sx={{ color: '#f59e0b', fontSize: '1.5rem' }} />;
      default: return <Assessment sx={{ color: '#6b7280', fontSize: '1.5rem' }} />;
    }
  };

  const getNodeTypeColor = (type?: string) => {
    switch (type) {
      case 'CONSULTANT': 
      case 'FIELD_CONSULTANT': 
        return '#6366f1';
      case 'COMPANY': 
        return '#10b981';
      case 'PRODUCT': 
        return '#3b82f6';
      case 'INCUMBENT_PRODUCT':
        return '#f59e0b';
      default: 
        return '#6b7280';
    }
  };

  const formatNodeType = (type?: string) => {
    return type?.replace('_', ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase()) || 'Unknown';
  };

  const getRelationshipIcon = (relType?: string) => {
    switch (relType) {
      case 'EMPLOYS': return <Person sx={{ color: '#6366f1', fontSize: '1.5rem' }} />;
      case 'COVERS': return <Business sx={{ color: '#10b981', fontSize: '1.5rem' }} />;
      case 'RATES': return <Star sx={{ color: '#8b5cf6', fontSize: '1.5rem' }} />;
      case 'OWNS': return <TrendingUp sx={{ color: '#3b82f6', fontSize: '1.5rem' }} />;
      case 'BI_RECOMMENDS': return <AutoAwesome sx={{ color: '#f59e0b', fontSize: '1.5rem' }} />;
      default: return <Timeline sx={{ color: '#6b7280', fontSize: '1.5rem' }} />;
    }
  };

  const getRelationshipColor = (relType?: string) => {
    switch (relType) {
      case 'EMPLOYS': return '#6366f1';
      case 'COVERS': return '#10b981';
      case 'RATES': return '#8b5cf6';
      case 'OWNS': return '#3b82f6';
      case 'BI_RECOMMENDS': return '#f59e0b';
      default: return '#6b7280';
    }
  };

  const parseInfluenceLevel = (influence: any): { value: number; displayText: string; isUnknown: boolean } => {
    if (!influence) {
      return { value: 0, displayText: 'Unknown', isUnknown: true };
    }

    if (typeof influence === 'string') {
      const normalized = influence.toLowerCase().trim();
      
      switch (normalized) {
        case 'high':
          return { value: 4, displayText: 'High', isUnknown: false };
        case 'medium':
          return { value: 3, displayText: 'Medium', isUnknown: false };
        case 'low':
          return { value: 2, displayText: 'Low', isUnknown: false };
        case 'unk':
        case 'unknown':
          return { value: 0, displayText: 'Unknown', isUnknown: true };
        default:
          const numValue = parseInt(normalized, 10);
          if (!isNaN(numValue) && numValue >= 1 && numValue <= 4) {
            return { value: numValue, displayText: `${numValue}/4`, isUnknown: false };
          }
          return { value: 0, displayText: influence, isUnknown: true };
      }
    }

    if (typeof influence === 'number') {
      if (influence >= 1 && influence <= 4) {
        return { value: influence, displayText: `${influence}/4`, isUnknown: false };
      }
      return { value: 0, displayText: influence.toString(), isUnknown: true };
    }

    return { value: 0, displayText: 'Unknown', isUnknown: true };
  };

  // Helper component for ultra-compact metadata table rows (Name + Value/Visual Combined)
  const MetadataRow = ({ 
    label, 
    value, 
    valueColor = isDarkTheme ? 'white' : 'rgba(0, 0, 0, 0.87)' 
  }: { 
    label: string; 
    value: React.ReactNode; 
    valueColor?: string;
  }) => (
    <TableRow sx={{ 
      '&:last-child td': { border: 0 },
      backgroundColor: isDarkTheme ? 'rgba(255, 255, 255, 0.02)' : 'rgba(0, 0, 0, 0.02)',
      '&:hover': { 
        backgroundColor: isDarkTheme ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.08)' 
      }
    }}>
      <TableCell 
        component="th" 
        scope="row" 
        sx={{ 
          color: isDarkTheme ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.6)', 
          fontSize: '0.75rem',
          fontWeight: 'medium',
          py: 0.75,
          px: 1.5,
          borderColor: isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.12)',
          width: '45%',
          verticalAlign: 'middle'
        }}
      >
        {label}
      </TableCell>
      <TableCell sx={{ 
        color: valueColor,
        fontSize: '0.8rem',
        fontWeight: 'medium',
        py: 0.75,
        px: 1.5,
        borderColor: isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.12)',
        width: '55%',
        verticalAlign: 'middle'
      }}>
        {value}
      </TableCell>
    </TableRow>
  );

  if (!selectedNode && !selectedEdge) {
    return (
      <Box sx={{ 
        width: '100%', 
        height: '100%', 
        display: 'flex', 
        alignItems: 'center',
        justifyContent: 'center',
        px: 3,
        bgcolor: isDarkTheme ? 'rgba(15, 23, 42, 0.98)' : 'rgba(255, 255, 255, 0.98)'
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Assessment sx={{ color: isDarkTheme ? 'rgba(255, 255, 255, 0.6)' : 'rgba(0, 0, 0, 0.6)', fontSize: '2rem' }} />
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h6" sx={{ color: isDarkTheme ? 'white' : 'rgba(0, 0, 0, 0.87)', fontWeight: 'bold', mb: 0.5 }}>
              Network Insights
            </Typography>
            <Typography variant="body2" sx={{ color: isDarkTheme ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.6)' }}>
              {isHovered ? 'Hover over any node or connection to preview details' : 'Select any node or connection to view detailed insights and analytics'}
            </Typography>
          </Box>
        </Box>
      </Box>
    );
  }

  if (selectedNode) {
    const { data, type } = selectedNode;
    
    return (
      <Box sx={{ 
        width: '100%', 
        height: '100%', 
        display: 'flex',
        flexDirection: 'column',
        bgcolor: isDarkTheme ? 'rgba(15, 23, 42, 0.98)' : 'rgba(255, 255, 255, 0.98)',
        background: isHovered ? `linear-gradient(90deg, ${getNodeTypeColor(type)}20 0%, transparent 100%)` : 'transparent',
        transition: 'background 0.3s ease',
        borderLeft: isHovered ? `3px solid ${getNodeTypeColor(type)}` : '3px solid transparent'
      }}>
        
        {/* FULL WIDTH HEADER */}
        <Box sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: 2, 
          p: 2,
          borderBottom: `1px solid ${isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.12)'}`,
          bgcolor: isDarkTheme ? 'rgba(255, 255, 255, 0.02)' : 'rgba(0, 0, 0, 0.02)',
          flexShrink: 0
        }}>
          <Avatar sx={{ 
            bgcolor: isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)', 
            width: 48, 
            height: 48,
            border: `2px solid ${getNodeTypeColor(type)}`,
            boxShadow: isHovered ? `0 0 20px ${getNodeTypeColor(type)}40` : 'none',
            transition: 'box-shadow 0.3s ease'
          }}>
            {getNodeIcon(type)}
          </Avatar>
          
          <Box sx={{ flexGrow: 1, minWidth: 0 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5, flexWrap: 'wrap' }}>
              <Typography variant="h6" sx={{ 
                color: isDarkTheme ? 'white' : 'rgba(0, 0, 0, 0.87)', 
                fontWeight: 'bold',
                fontSize: '1.1rem',
                minWidth: 0,
                overflow: 'hidden',
                textOverflow: 'ellipsis'
              }}>
                {data.name}
              </Typography>
              {isHovered && (
                <Chip 
                  label="HOVER" 
                  size="small" 
                  sx={{ 
                    bgcolor: `${getNodeTypeColor(type)}20`,
                    color: getNodeTypeColor(type),
                    fontWeight: 'bold',
                    fontSize: '0.65rem',
                    height: 20
                  }}
                />
              )}
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
              <Chip 
                label={formatNodeType(type)} 
                size="small" 
                sx={{ 
                  bgcolor: `${getNodeTypeColor(type)}20`,
                  color: getNodeTypeColor(type),
                  fontWeight: 'bold',
                  fontSize: '0.7rem',
                  height: 22
                }}
              />
              <Chip 
                label={`ID: ${data.id}`}
                size="small" 
                sx={{ 
                  bgcolor: isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)',
                  color: isDarkTheme ? 'rgba(255, 255, 255, 0.8)' : 'rgba(0, 0, 0, 0.6)',
                  fontSize: '0.65rem',
                  height: 22
                }}
              />
            </Box>
          </Box>
        </Box>

        {/* COMPACT METADATA TABLE */}
        <Box sx={{ 
          flexGrow: 1, 
          overflowY: 'auto',
          p: 1,
          bgcolor: isDarkTheme ? 'rgba(0, 0, 0, 0.1)' : 'rgba(255, 255, 255, 0.1)',
          minHeight: 0 // Important: allows flex child to shrink
        }}>
          <Table 
            size="small" 
            sx={{ 
              width: '100%',
              '& .MuiTableCell-root': {
                border: `1px solid ${isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.12)'}`,
                padding: '6px 12px'
              },
              '& .MuiTableBody-root': {
                '& .MuiTableRow-root': {
                  '&:hover': {
                    backgroundColor: isDarkTheme ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.05)'
                  }
                }
              }
            }}
          >
            <TableBody>
              
              {/* Basic Properties */}
              {data.region && (
                <MetadataRow 
                  label="Region" 
                  value={data.region}
                />
              )}
              
              {data.pca && (
                <MetadataRow 
                  label="PCA" 
                  value={data.pca}
                  valueColor="#6366f1"
                />
              )}
              
              {data.aca && (
                <MetadataRow 
                  label="ACA" 
                  value={data.aca}
                  valueColor="#8b5cf6"
                />
              )}
              
              {data.sales_region && (
                <MetadataRow 
                  label="Sales Region" 
                  value={data.sales_region}
                />
              )}
              
              {data.channel && (
                <MetadataRow 
                  label="Channel" 
                  value={data.channel}
                />
              )}
              
              {data.asset_class && (
                <MetadataRow 
                  label="Asset Class" 
                  value={data.asset_class}
                  valueColor="#3b82f6"
                />
              )}

              {/* Performance Metrics */}
              {data.performance && (
                <MetadataRow 
                  label="Performance Score" 
                  value={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <LinearProgress 
                        variant="determinate" 
                        value={data.performance} 
                        sx={{ 
                          flexGrow: 1,
                          height: 6, 
                          borderRadius: 3,
                          bgcolor: isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
                          '& .MuiLinearProgress-bar': {
                            bgcolor: data.performance >= 80 ? '#10b981' : 
                                     data.performance >= 60 ? '#f59e0b' : '#ef4444',
                            borderRadius: 3
                          }
                        }}
                      />
                      <Typography variant="caption" sx={{ 
                        color: data.performance >= 80 ? '#10b981' : 
                               data.performance >= 60 ? '#f59e0b' : '#ef4444',
                        fontWeight: 'bold',
                        fontSize: '0.75rem',
                        minWidth: 'fit-content'
                      }}>
                        {data.performance}%
                      </Typography>
                    </Box>
                  }
                />
              )}

              {/* Product-Specific Properties */}
              {type === 'PRODUCT' && data.universe_name && (
                <MetadataRow 
                  label="Universe Name" 
                  value={
                    <Chip 
                      label={data.universe_name}
                      size="small"
                      sx={{
                        bgcolor: '#3b82f620',
                        color: '#3b82f6',
                        fontSize: '0.7rem',
                        height: 20,
                        fontWeight: 'medium'
                      }}
                    />
                  }
                />
              )}

              {type === 'PRODUCT' && data.universe_score && (
                <MetadataRow 
                  label="Universe Score" 
                  value={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <LinearProgress 
                        variant="determinate" 
                        value={(data.universe_score / 10) * 100} 
                        sx={{ 
                          flexGrow: 1,
                          height: 6, 
                          borderRadius: 3,
                          bgcolor: isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
                          '& .MuiLinearProgress-bar': {
                            bgcolor: data.universe_score >= 8 ? '#10b981' : 
                                     data.universe_score >= 6 ? '#f59e0b' : '#ef4444',
                            borderRadius: 3
                          }
                        }}
                      />
                      <Typography variant="caption" sx={{ 
                        color: data.universe_score >= 8 ? '#10b981' : 
                               data.universe_score >= 6 ? '#f59e0b' : '#ef4444',
                        fontWeight: 'bold',
                        fontSize: '0.75rem',
                        minWidth: 'fit-content'
                      }}>
                        {data.universe_score}/10
                      </Typography>
                    </Box>
                  }
                />
              )}

              {/* Incumbent Product Properties */}
              {type === 'INCUMBENT_PRODUCT' && data.evestment_product_guid && (
                <MetadataRow 
                  label="Evestment GUID" 
                  value={
                    <Chip 
                      label={data.evestment_product_guid.length > 15 ? 
                        `${data.evestment_product_guid.slice(0, 15)}...` : 
                        data.evestment_product_guid
                      }
                      size="small"
                      sx={{
                        bgcolor: '#f59e0b20',
                        color: '#f59e0b',
                        fontSize: '0.65rem',
                        height: 20,
                        fontFamily: 'monospace',
                        fontWeight: 'medium'
                      }}
                    />
                  }
                />
              )}

              {/* Privacy and Additional Details */}
              {data.privacy && (
                <MetadataRow 
                  label="Privacy Level" 
                  value={
                    <Chip 
                      label={data.privacy}
                      size="small"
                      sx={{
                        bgcolor: data.privacy === 'Public' ? '#10b98120' : 
                                 data.privacy === 'Private' ? '#f59e0b20' : '#ef444420',
                        color: data.privacy === 'Public' ? '#10b981' : 
                               data.privacy === 'Private' ? '#f59e0b' : '#ef4444',
                        fontSize: '0.7rem',
                        height: 20,
                        fontWeight: 'bold'
                      }}
                    />
                  }
                />
              )}

              {/* Field Consultant Parent */}
              {type === 'FIELD_CONSULTANT' && data.parentConsultantId && (
                <MetadataRow 
                  label="Parent Consultant" 
                  value={data.parentConsultantId}
                  valueColor="#6366f1"
                />
              )}

              {/* Product Ratings - Show all consultant ratings */}
              {(type === 'PRODUCT' || type === 'INCUMBENT_PRODUCT') && data.ratings && data.ratings.length > 0 && (
                <MetadataRow 
                  label={`Consultant Ratings (${data.ratings.length})`}
                  value={
                    <Stack direction="column" spacing={0.5} sx={{ width: '100%' }}>
                      {data.ratings.map((rating: any, index: number) => (
                        <Box 
                          key={index}
                          sx={{ 
                            display: 'flex', 
                            justifyContent: 'space-between', 
                            alignItems: 'center',
                            p: 0.5,
                            borderRadius: 1,
                            bgcolor: isDarkTheme ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.05)',
                            border: `1px solid ${isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'}`
                          }}
                        >
                          <Typography variant="caption" sx={{ 
                            fontSize: '0.7rem',
                            color: isDarkTheme ? 'rgba(255, 255, 255, 0.9)' : 'rgba(0, 0, 0, 0.8)',
                            fontWeight: 'medium',
                            flexGrow: 1,
                            minWidth: 0,
                            overflow: 'hidden',
                            textOverflow: 'ellipsis'
                          }}>
                            {rating.consultant}
                          </Typography>
                          <Chip
                            label={rating.rankgroup || rating.rating || 'N/A'}
                            size="small"
                            sx={{
                              bgcolor: rating.rankgroup === 'Positive' ? '#16a34a' : 
                                       rating.rankgroup === 'Negative' ? '#dc2626' : 
                                       rating.rankgroup === 'Introduced' ? '#0891b2' : 
                                       rating.rankgroup === 'Neutral' ? '#6b7280' : '#6b7280',
                              color: 'white',
                              fontSize: '0.65rem',
                              height: 18,
                              fontWeight: 'bold',
                              ml: 1
                            }}
                          />
                        </Box>
                      ))}
                    </Stack>
                  }
                />
              )}

            </TableBody>
          </Table>
        </Box>
      </Box>
    );
  }

  if (selectedEdge) {
    const edgeData = selectedEdge.data || {};
    const relType = edgeData.relType;
    const mandateStatus = edgeData.mandateStatus || edgeData.mandate_status || edgeData.status;
    const levelOfInfluence = edgeData.levelOfInfluence || edgeData.level_of_influence || edgeData.influence;
    const rating = edgeData.rating || edgeData.rankgroup || edgeData.rank;
    
    return (
      <Box sx={{ 
        width: '100%', 
        height: '100%', 
        display: 'flex',
        flexDirection: 'column',
        bgcolor: isDarkTheme ? 'rgba(15, 23, 42, 0.98)' : 'rgba(255, 255, 255, 0.98)',
        background: isHovered ? (() => {
          const color = getRelationshipColor(relType);
          if (color && color.startsWith('#')) {
            const r = parseInt(color.slice(1, 3), 16);
            const g = parseInt(color.slice(3, 5), 16);  
            const b = parseInt(color.slice(5, 7), 16);
            return `linear-gradient(90deg, rgba(${r}, ${g}, ${b}, 0.1) 0%, transparent 100%)`;
          }
          return 'linear-gradient(90deg, rgba(107, 114, 128, 0.1) 0%, transparent 100%)';
        })() : 'transparent',
        transition: 'background 0.3s ease',
        borderLeft: isHovered ? `3px solid ${getRelationshipColor(relType)}` : '3px solid transparent'
      }}>
        
        {/* FULL WIDTH HEADER */}
        <Box sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: 2, 
          p: 2,
          borderBottom: `1px solid ${isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.12)'}`,
          bgcolor: isDarkTheme ? 'rgba(255, 255, 255, 0.02)' : 'rgba(0, 0, 0, 0.02)',
          flexShrink: 0
        }}>
          <Avatar sx={{ 
            bgcolor: isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)', 
            width: 48, 
            height: 48,
            border: `2px solid ${getRelationshipColor(relType)}`,
            boxShadow: isHovered ? `0 0 20px ${getRelationshipColor(relType)}40` : 'none',
            transition: 'box-shadow 0.3s ease'
          }}>
            {getRelationshipIcon(relType)}
          </Avatar>
          
          <Box sx={{ flexGrow: 1, minWidth: 0 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5, flexWrap: 'wrap' }}>
              <Typography variant="h6" sx={{ 
                color: isDarkTheme ? 'white' : 'rgba(0, 0, 0, 0.87)', 
                fontWeight: 'bold',
                fontSize: '1.1rem'
              }}>
                {relType === 'BI_RECOMMENDS' ? 'AI Recommendation' : relType || 'Connection'}
              </Typography>
              {isHovered && (
                <Chip 
                  label="HOVER" 
                  size="small" 
                  sx={{ 
                    bgcolor: `${getRelationshipColor(relType)}20`,
                    color: getRelationshipColor(relType),
                    fontWeight: 'bold',
                    fontSize: '0.65rem',
                    height: 20
                  }}
                />
              )}
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
              <Chip 
                label="Relationship" 
                size="small" 
                sx={{ 
                  bgcolor: `${getRelationshipColor(relType)}20`,
                  color: getRelationshipColor(relType),
                  fontWeight: 'bold',
                  fontSize: '0.7rem',
                  height: 22
                }}
              />
              <Chip 
                label={`ID: ${selectedEdge.id}`}
                size="small" 
                sx={{ 
                  bgcolor: isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)',
                  color: isDarkTheme ? 'rgba(255, 255, 255, 0.8)' : 'rgba(0, 0, 0, 0.6)',
                  fontSize: '0.65rem',
                  height: 22
                }}
              />
            </Box>
          </Box>
        </Box>

        {/* COMPREHENSIVE METADATA TABLE */}
        <Box sx={{ 
          flexGrow: 1, 
          overflowY: 'auto',
          p: 1
        }}>
          <Table size="small" sx={{ width: '100%' }}>
            <TableBody>
              
              {/* Relationship Type */}
              <MetadataRow 
                label="Relationship Type" 
                value={relType || 'Unknown'}
                valueColor={getRelationshipColor(relType)}
              />

              {/* Level of Influence for COVERS */}
              {relType === 'COVERS' && levelOfInfluence && (
                (() => {
                  const parsedInfluence = parseInfluenceLevel(levelOfInfluence);
                  
                  return (
                    <MetadataRow 
                      label="Level of Influence" 
                      value={
                        parsedInfluence.isUnknown ? (
                          <Chip
                            label={`Unknown (${levelOfInfluence})`}
                            size="small"
                            sx={{
                              bgcolor: 'rgba(156, 163, 175, 0.2)',
                              color: '#9ca3af',
                              fontSize: '0.7rem',
                              height: 20
                            }}
                          />
                        ) : (
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <LinearProgress 
                              variant="determinate" 
                              value={(parsedInfluence.value / 4) * 100} 
                              sx={{ 
                                flexGrow: 1,
                                height: 6, 
                                borderRadius: 3,
                                bgcolor: isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
                                '& .MuiLinearProgress-bar': {
                                  bgcolor: parsedInfluence.value >= 4 ? '#059669' : 
                                          parsedInfluence.value >= 3 ? '#10b981' : 
                                          parsedInfluence.value >= 2 ? '#34d399' : '#6ee7b7',
                                  borderRadius: 3
                                }
                              }}
                            />
                            <Typography variant="caption" sx={{ 
                              color: parsedInfluence.value >= 4 ? '#059669' : 
                                     parsedInfluence.value >= 3 ? '#10b981' : 
                                     parsedInfluence.value >= 2 ? '#34d399' : '#6ee7b7',
                              fontWeight: 'bold',
                              fontSize: '0.75rem',
                              minWidth: 'fit-content'
                            }}>
                              {parsedInfluence.displayText}
                            </Typography>
                          </Box>
                        )
                      }
                    />
                  );
                })()
              )}

              {/* Mandate Status for OWNS */}
              {relType === 'OWNS' && mandateStatus && (
                <MetadataRow 
                  label="Mandate Status" 
                  value={
                    <Chip
                      label={mandateStatus}
                      size="small"
                      sx={{
                        bgcolor: mandateStatus === 'Active' ? '#10b981' : 
                                 mandateStatus === 'At Risk' ? '#ef4444' : 
                                 mandateStatus === 'Conversion in Progress' ? '#f59e0b' : '#6b7280',
                        color: 'white',
                        fontSize: '0.7rem',
                        height: 20,
                        fontWeight: 'bold'
                      }}
                    />
                  }
                />
              )}

              {/* Rating for RATES */}
              {relType === 'RATES' && rating && (
                <MetadataRow 
                  label="Rating" 
                  value={
                    <Chip
                      label={rating}
                      size="small"
                      sx={{
                        bgcolor: rating === 'Positive' ? '#16a34a' : 
                                 rating === 'Negative' ? '#dc2626' : 
                                 rating === 'Introduced' ? '#0891b2' : '#6b7280',
                        color: 'white',
                        fontSize: '0.7rem',
                        height: 20,
                        fontWeight: 'bold'
                      }}
                    />
                  }
                />
              )}

              {/* BI_RECOMMENDS specific metrics */}
              {relType === 'BI_RECOMMENDS' && (
                <>
                  {edgeData.opportunity_type && (
                    <MetadataRow 
                      label="Opportunity Type" 
                      value={
                        <Chip 
                          label={edgeData.opportunity_type}
                          size="small"
                          sx={{
                            bgcolor: '#f59e0b20',
                            color: '#f59e0b',
                            fontSize: '0.7rem',
                            height: 20,
                            fontWeight: 'medium'
                          }}
                        />
                      }
                    />
                  )}

                  {edgeData.returns && (
                    <MetadataRow 
                      label="Returns" 
                      value={edgeData.returns}
                      valueColor="#f59e0b"
                    />
                  )}

                  {edgeData.annualised_alpha_summary && (
                    <MetadataRow 
                      label="Annualised Alpha" 
                      value={edgeData.annualised_alpha_summary}
                      valueColor="#f59e0b"
                    />
                  )}

                  {edgeData.information_ratio_summary && (
                    <MetadataRow 
                      label="Information Ratio" 
                      value={edgeData.information_ratio_summary}
                      valueColor="#f59e0b"
                    />
                  )}

                  {edgeData.batting_average_summary && (
                    <MetadataRow 
                      label="Batting Average" 
                      value={edgeData.batting_average_summary}
                      valueColor="#f59e0b"
                    />
                  )}
                </>
              )}

              {/* Connection Strength for other relationships */}
              {edgeData.strength && relType !== 'COVERS' && (
                <MetadataRow 
                  label="Connection Strength" 
                  value={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <LinearProgress 
                        variant="determinate" 
                        value={Number(edgeData.strength)} 
                        sx={{ 
                          flexGrow: 1,
                          height: 6, 
                          borderRadius: 3,
                          bgcolor: isDarkTheme ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
                          '& .MuiLinearProgress-bar': {
                            bgcolor: Number(edgeData.strength) >= 80 ? '#10b981' : 
                                     Number(edgeData.strength) >= 60 ? '#f59e0b' : '#ef4444',
                            borderRadius: 3
                          }
                        }}
                      />
                      <Typography variant="caption" sx={{ 
                        color: Number(edgeData.strength) >= 80 ? '#10b981' : 
                               Number(edgeData.strength) >= 60 ? '#f59e0b' : '#ef4444',
                        fontWeight: 'bold',
                        fontSize: '0.75rem',
                        minWidth: 'fit-content'
                      }}>
                        {edgeData.strength}%
                      </Typography>
                    </Box>
                  }
                />
              )}

              {/* Influenced Consultant */}
              {edgeData.influencedConsultant && (
                <MetadataRow 
                  label="Influenced Consultant" 
                  value={edgeData.influencedConsultant}
                  valueColor="#6366f1"
                />
              )}

            </TableBody>
          </Table>
        </Box>
      </Box>
    );
  }

  return null;
};