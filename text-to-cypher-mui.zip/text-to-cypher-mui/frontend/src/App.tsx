import React from 'react';
import TextToCypherDashboard from './components/TextToCypherDashboard';
import TextToCypherDashboardOld from './components/TextToCypherDashboardOld';
import ConsultingDashboard from './components/ConsultingDashboard';

function App() {
  return (
    <div className="App">
      <TextToCypherDashboard />
    </div>
  );
}

export default App;