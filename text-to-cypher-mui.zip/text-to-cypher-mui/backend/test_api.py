# test_consulting_api.py
"""
Comprehensive test script for the Consulting Business Graph API
Tests all endpoints based on the exact business schema
"""

import requests
import json
from datetime import datetime
import time
import sys

API_BASE_URL = "http://localhost:8000"

def print_header():
    """Print a comprehensive header for the test suite"""
    print("🏢" + "="*80)
    print("  CONSULTING BUSINESS GRAPH API - COMPREHENSIVE TESTING SUITE")
    print("  Schema: Companies, Consultants, Field_Consultants, Products + Relationships")
    print(f"  API Base URL: {API_BASE_URL}")
    print(f"  Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*82)

def print_separator(title):
    """Print a section separator"""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")

def test_endpoint(endpoint, description, params=None, expected_keys=None, show_details=True):
    """Test a single API endpoint with detailed output"""
    print(f"\n🔍 Testing: {description}")
    print(f"📍 Endpoint: {endpoint}")
    
    if params:
        print(f"🔧 Parameters: {params}")
    
    try:
        url = f"{API_BASE_URL}{endpoint}"
        start_time = time.time()
        response = requests.get(url, params=params, timeout=15)
        response_time = round((time.time() - start_time) * 1000, 2)
        
        print(f"⏱️  Response Time: {response_time}ms")
        print(f"📊 Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ SUCCESS!")
            
            # Handle different response types
            if isinstance(data, list):
                print(f"📝 Records returned: {len(data)}")
                
                if data and show_details:
                    print(f"🔑 Sample record keys: {list(data[0].keys())}")
                    
                    # Validate expected keys if provided
                    if expected_keys:
                        missing_keys = set(expected_keys) - set(data[0].keys())
                        if missing_keys:
                            print(f"⚠️  Missing expected keys: {missing_keys}")
                        else:
                            print(f"✅ All expected keys present")
                    
                    # Show first record details
                    print(f"📋 First record:")
                    for key, value in list(data[0].items())[:8]:
                        if isinstance(value, str) and len(value) > 50:
                            value = value[:50] + "..."
                        elif isinstance(value, list) and len(value) > 3:
                            value = str(value[:3]) + f"... (+{len(value)-3} more)"
                        print(f"    {key}: {value}")
                    
                    # Show summary of additional records
                    if len(data) > 1:
                        print(f"📊 Additional records:")
                        for i in range(1, min(len(data), 4)):
                            name_field = None
                            for field in ['name', 'industry', 'category', 'expertise', 'specialization']:
                                if field in data[i]:
                                    name_field = data[i][field]
                                    break
                            
                            if name_field:
                                if isinstance(name_field, list):
                                    name_field = ', '.join(str(x) for x in name_field[:2])
                                print(f"    {i+1}. {name_field}")
                        
                        if len(data) > 4:
                            print(f"    ... and {len(data) - 4} more records")
                
            elif isinstance(data, dict):
                print(f"🗂️  Response structure:")
                
                # Handle nested objects
                for key, value in data.items():
                    if isinstance(value, list):
                        if value:
                            print(f"📝 {key}: {len(value)} items")
                            if isinstance(value[0], dict) and show_details:
                                sample_keys = list(value[0].keys())[:5]
                                print(f"    Sample item keys: {sample_keys}")
                        else:
                            print(f"📝 {key}: empty list")
                    elif isinstance(value, dict):
                        print(f"📊 {key}: {list(value.keys())[:5]}")
                        if show_details and len(value) <= 5:
                            for k, v in list(value.items())[:3]:
                                print(f"    {k}: {v}")
                    else:
                        display_value = str(value)
                        if len(display_value) > 50:
                            display_value = display_value[:50] + "..."
                        print(f"📋 {key}: {display_value}")
            
            else:
                print(f"📄 Response: {data}")
                
        elif response.status_code == 404:
            print(f"❌ NOT FOUND (404) - This might be expected for some tests")
        elif response.status_code == 422:
            print(f"❌ VALIDATION ERROR (422)")
            try:
                error_data = response.json()
                print(f"💬 Error details: {error_data}")
            except:
                print(f"💬 Error text: {response.text}")
        else:
            print(f"❌ ERROR: {response.status_code}")
            print(f"💬 Response: {response.text[:200]}...")
            
    except requests.exceptions.ConnectionError:
        print("🚫 CONNECTION ERROR: FastAPI server not running")
        print("   🔧 Start server with: uvicorn main:app --reload")
        return False
    except requests.exceptions.Timeout:
        print("⏰ TIMEOUT ERROR: Request took too long")
        return False
    except Exception as e:
        print(f"💥 UNEXPECTED ERROR: {e}")
        return False
    
    return True

def test_basic_connectivity():
    """Test basic API connectivity"""
    print_separator("BASIC CONNECTIVITY TESTS")
    
    # Test root endpoint
    if not test_endpoint("/", "Root endpoint"):
        print("\n🚨 CRITICAL: Cannot connect to API server!")
        return False
    
    # Test health endpoint
    if not test_endpoint("/health", "Health check endpoint"):
        print("\n🚨 WARNING: Health check failed!")
        return False
    
    return True

def test_companies_api():
    """Test comprehensive companies API"""
    print_separator("COMPANIES API TESTS")
    
    # Basic companies tests
    test_endpoint("/api/companies", "All companies (limited)", 
                 params={"limit": 3})
    
    # Industry filters
    test_endpoint("/api/companies", "Technology companies",
                 params={"industry": "Technology"})
    
    test_endpoint("/api/companies", "Healthcare companies",
                 params={"industry": "Healthcare"})
    
    test_endpoint("/api/companies", "Finance companies",
                 params={"industry": "Finance"})
    
    # Size filters
    test_endpoint("/api/companies", "Enterprise companies",
                 params={"size": "Enterprise"})
    
    test_endpoint("/api/companies", "SME companies",
                 params={"size": "SME"})
    
    # Revenue filters
    test_endpoint("/api/companies", "High revenue companies (500M+)",
                 params={"min_revenue": 500})
    
    test_endpoint("/api/companies", "Mid-tier revenue companies (50-200M)",
                 params={"min_revenue": 50, "max_revenue": 200})
    
    # Location filters
    test_endpoint("/api/companies", "San Francisco companies",
                 params={"location": "San Francisco"})
    
    test_endpoint("/api/companies", "New York companies",
                 params={"location": "New York"})
    
    # Employee count filters
    test_endpoint("/api/companies", "Large companies (1000+ employees)",
                 params={"min_employees": 1000})
    
    # Founded year filters
    test_endpoint("/api/companies", "Companies founded after 2010",
                 params={"founded_after": 2010})
    
    # Status filters
    test_endpoint("/api/companies", "Active companies",
                 params={"status": "Active"})
    
    # Combined filters
    test_endpoint("/api/companies", "Large tech companies in California",
                 params={"industry": "Technology", "min_employees": 1000, "location": "San Francisco"})
    
    # Test specific company details
    test_endpoint("/api/companies/comp_001", "Company details: TechFlow Corp")
    test_endpoint("/api/companies/comp_002", "Company details: HealthFirst Solutions")
    # Test specific company details
    test_endpoint("/api/companies/comp_001", "Company details: TechFlow Corp")
    test_endpoint("/api/companies/comp_002", "Company details: HealthFirst Solutions")
    test_endpoint("/api/companies/comp_003", "Company details: FinanceMax Ltd")
    test_endpoint("/api/companies/nonexistent", "Non-existent company (should fail)")

def test_consultants_api():
    """Test comprehensive consultants API"""
    print_separator("CONSULTANTS API TESTS")
    
    # Basic consultants tests
    test_endpoint("/api/consultants", "All consultants",
                 params={"limit": 5})
    
    # Expertise filters
    test_endpoint("/api/consultants", "Strategy consultants",
                 params={"expertise": "Strategy"})
    
    test_endpoint("/api/consultants", "Technology consultants",
                 params={"expertise": "Technology"})
    
    test_endpoint("/api/consultants", "Operations consultants",
                 params={"expertise": "Operations"})
    
    test_endpoint("/api/consultants", "Finance consultants",
                 params={"expertise": "Finance"})
    
    # Seniority filters
    test_endpoint("/api/consultants", "Partner level consultants",
                 params={"seniority": "Partner"})
    
    test_endpoint("/api/consultants", "Principal level consultants",
                 params={"seniority": "Principal"})
    
    test_endpoint("/api/consultants", "Senior level consultants",
                 params={"seniority": "Senior"})
    
    # Availability filters
    test_endpoint("/api/consultants", "Available consultants",
                 params={"availability": "Available"})
    
    test_endpoint("/api/consultants", "Busy consultants",
                 params={"availability": "Busy"})
    
    # Rate filters
    test_endpoint("/api/consultants", "High-rate consultants (400+/hr)",
                 params={"min_rate": 400})
    
    test_endpoint("/api/consultants", "Mid-rate consultants (200-400/hr)",
                 params={"min_rate": 200, "max_rate": 400})
    
    # Experience filters
    test_endpoint("/api/consultants", "Very experienced consultants (10+ years)",
                 params={"min_experience": 10})
    
    test_endpoint("/api/consultants", "Junior consultants (0-5 years)",
                 params={"max_experience": 5})
    
    # Rating filters
    test_endpoint("/api/consultants", "Top-rated consultants (4.5+)",
                 params={"min_rating": 4.5})
    
    # Location filters
    test_endpoint("/api/consultants", "San Francisco consultants",
                 params={"location": "San Francisco"})
    
    test_endpoint("/api/consultants", "New York consultants",
                 params={"location": "New York"})
    
    # Education filters
    test_endpoint("/api/consultants", "MBA consultants",
                 params={"education": "MBA"})
    
    # Combined filters
    test_endpoint("/api/consultants", "Available senior strategy consultants",
                 params={"expertise": "Strategy", "seniority": "Partner", "availability": "Available"})
    
    # Test specific consultant details
    test_endpoint("/api/consultants/cons_001", "Consultant details: Sarah Chen")
    test_endpoint("/api/consultants/cons_002", "Consultant details: Michael Rodriguez")
    test_endpoint("/api/consultants/cons_003", "Consultant details: Emily Watson")
    test_endpoint("/api/consultants/cons_004", "Consultant details: David Kim")

def test_field_consultants_api():
    """Test comprehensive field consultants API"""
    print_separator("FIELD CONSULTANTS API TESTS")
    
    # Basic field consultants tests
    test_endpoint("/api/field-consultants", "All field consultants")
    
    # Specialization filters
    test_endpoint("/api/field-consultants", "Implementation specialists",
                 params={"specialization": "Implementation"})
    
    test_endpoint("/api/field-consultants", "Training specialists",
                 params={"specialization": "Training"})
    
    test_endpoint("/api/field-consultants", "Support specialists",
                 params={"specialization": "Support"})
    
    # Region filters
    test_endpoint("/api/field-consultants", "West Coast field consultants",
                 params={"region": "West Coast"})
    
    test_endpoint("/api/field-consultants", "East Coast field consultants",
                 params={"region": "East Coast"})
    
    test_endpoint("/api/field-consultants", "Midwest field consultants",
                 params={"region": "Midwest"})
    
    # Certification filters
    test_endpoint("/api/field-consultants", "Expert level consultants",
                 params={"certification_level": "Expert"})
    
    test_endpoint("/api/field-consultants", "Certified level consultants",
                 params={"certification_level": "Certified"})
    
    # Availability filters
    test_endpoint("/api/field-consultants", "Available field consultants",
                 params={"availability": "Available"})
    
    # Travel willingness filters
    test_endpoint("/api/field-consultants", "Travel-willing consultants",
                 params={"travel_willingness": True})
    
    test_endpoint("/api/field-consultants", "Non-travel consultants",
                 params={"travel_willingness": False})
    
    # Rate filters
    test_endpoint("/api/field-consultants", "High-rate field consultants (140+/hr)",
                 params={"min_rate": 140})
    
    # Experience filters
    test_endpoint("/api/field-consultants", "Experienced field consultants (5+ years)",
                 params={"min_experience": 5})
    
    # Language filters
    test_endpoint("/api/field-consultants", "Spanish-speaking consultants",
                 params={"language": "Spanish"})
    
    test_endpoint("/api/field-consultants", "French-speaking consultants",
                 params={"language": "French"})
    
    # Rating filters
    test_endpoint("/api/field-consultants", "Top-rated field consultants (4.4+)",
                 params={"min_rating": 4.4})
    
    # Combined filters
    test_endpoint("/api/field-consultants", "Available expert implementation consultants",
                 params={"specialization": "Implementation", "certification_level": "Expert", "availability": "Available"})
    
    # Test specific field consultant details
    test_endpoint("/api/field-consultants/fc_001", "Field consultant details: James Wilson")
    test_endpoint("/api/field-consultants/fc_002", "Field consultant details: Lisa Park")
    test_endpoint("/api/field-consultants/fc_003", "Field consultant details: Robert Taylor")

def test_products_api():
    """Test comprehensive products API"""
    print_separator("PRODUCTS API TESTS")
    
    # Basic products tests
    test_endpoint("/api/products", "All products")
    
    # Category filters
    test_endpoint("/api/products", "Software products",
                 params={"category": "Software"})
    
    test_endpoint("/api/products", "Hardware products",
                 params={"category": "Hardware"})
    
    # Vendor filters
    test_endpoint("/api/products", "CloudFlow products",
                 params={"vendor": "CloudFlow"})
    
    test_endpoint("/api/products", "Analytics Corp products",
                 params={"vendor": "Analytics Corp"})
    
    # Price range filters
    test_endpoint("/api/products", "Enterprise products (10K+)",
                 params={"price_range": "$10K+"})
    
    test_endpoint("/api/products", "Mid-tier products (1K-10K)",
                 params={"price_range": "$1K-$10K"})
    
    test_endpoint("/api/products", "Budget products (<1K)",
                 params={"price_range": "<$1K"})
    
    # Target market filters
    test_endpoint("/api/products", "Enterprise target products",
                 params={"target_market": "Enterprise"})
    
    test_endpoint("/api/products", "SME target products",
                 params={"target_market": "SME"})
    
    # Deployment filters
    test_endpoint("/api/products", "Cloud deployment products",
                 params={"deployment_type": "Cloud"})
    
    test_endpoint("/api/products", "On-premise deployment products",
                 params={"deployment_type": "On-Premise"})
    
    # Industry focus filters
    test_endpoint("/api/products", "Technology industry products",
                 params={"industry_focus": "Technology"})
    
    test_endpoint("/api/products", "Finance industry products",
                 params={"industry_focus": "Finance"})
    
    test_endpoint("/api/products", "Healthcare industry products",
                 params={"industry_focus": "Healthcare"})
    
    # Maturity filters
    test_endpoint("/api/products", "Stable products",
                 params={"maturity": "Stable"})
    
    # Rating filters
    test_endpoint("/api/products", "High-rated products (4.0+)",
                 params={"min_rating": 4.0})
    
    test_endpoint("/api/products", "Top-rated products (4.5+)",
                 params={"min_rating": 4.5})
    
    # Launch date filters
    test_endpoint("/api/products", "Recently launched products (2020+)",
                 params={"launched_after": "2020-01-01"})
    
    test_endpoint("/api/products", "Established products (pre-2020)",
                 params={"launched_before": "2020-01-01"})
    
    # Combined filters
    test_endpoint("/api/products", "Enterprise cloud software for technology companies",
                 params={
                     "category": "Software", 
                     "deployment_type": "Cloud", 
                     "target_market": "Enterprise",
                     "industry_focus": "Technology"
                 })
    
    # Test specific product details
    test_endpoint("/api/products/prod_001", "Product details: CloudFlow Platform")
    test_endpoint("/api/products/prod_002", "Product details: DataAnalytics Pro")
    test_endpoint("/api/products/prod_003", "Product details: SecureNet Gateway")
    test_endpoint("/api/products/prod_004", "Product details: WorkFlow Manager")

def test_analytics_api():
    """Test comprehensive analytics API"""
    print_separator("ANALYTICS & INSIGHTS API TESTS")
    
    # Dashboard analytics
    test_endpoint("/api/analytics/dashboard", "Dashboard analytics")
    
    # Relationship analytics
    test_endpoint("/api/analytics/relationships", "Relationship analytics")
    
    # Business insights
    test_endpoint("/api/analytics/business-insights", "Business insights")

def test_filter_options_api():
    """Test filter options API"""
    print_separator("FILTER OPTIONS API TESTS")
    
    test_endpoint("/api/filters/industries", "Available industries", show_details=False)
    test_endpoint("/api/filters/locations", "Available locations", show_details=False)
    test_endpoint("/api/filters/expertise", "Available expertise areas", show_details=False)
    test_endpoint("/api/filters/specializations", "Available specializations", show_details=False)
    test_endpoint("/api/filters/product-categories", "Available product categories", show_details=False)
    test_endpoint("/api/filters/company-sizes", "Available company sizes", show_details=False)
    test_endpoint("/api/filters/seniority-levels", "Available seniority levels", show_details=False)
    test_endpoint("/api/filters/regions", "Available regions", show_details=False)
    test_endpoint("/api/filters/languages", "Available languages", show_details=False)

def test_business_queries_api():
    """Test business-specific query endpoints"""
    print_separator("BUSINESS QUERIES API TESTS")
    
    # Top performers by different metrics
    test_endpoint("/api/business/top-performers", "Top performers by satisfaction",
                 params={"metric": "satisfaction", "limit": 5})
    
    test_endpoint("/api/business/top-performers", "Top performers by revenue",
                 params={"metric": "revenue", "limit": 5})
    
    test_endpoint("/api/business/top-performers", "Top performers by projects",
                 params={"metric": "projects", "limit": 5})
    
    # Business recommendations
    test_endpoint("/api/business/recommendations", "Recommendations for specific company",
                 params={"company_id": "comp_001"})
    
    test_endpoint("/api/business/recommendations", "Recommendations for technology industry",
                 params={"industry": "Technology"})
    
    test_endpoint("/api/business/recommendations", "Recommendations for healthcare industry",
                 params={"industry": "Healthcare"})

def test_edge_cases():
    """Test edge cases and error handling"""
    print_separator("EDGE CASES & ERROR HANDLING")
    
    # Large limits
    test_endpoint("/api/companies", "Very large limit test",
                 params={"limit": 1000})
    
    # Invalid filters
    test_endpoint("/api/companies", "Invalid industry filter",
                 params={"industry": "NonExistentIndustry"})
    
    test_endpoint("/api/consultants", "Invalid seniority filter",
                 params={"seniority": "InvalidLevel"})
    
    test_endpoint("/api/products", "Very high rating filter",
                 params={"min_rating": 6.0})
    
    # Invalid date formats
    test_endpoint("/api/products", "Invalid date format",
                 params={"launched_after": "invalid-date"})
    
    # Invalid business query metrics
    test_endpoint("/api/business/top-performers", "Invalid metric",
                 params={"metric": "invalid_metric"})
    
    # Missing required parameters
    test_endpoint("/api/business/recommendations", "Missing required parameters")
    
    # Non-existent endpoints
    test_endpoint("/nonexistent-endpoint", "Non-existent endpoint test")
    
    # Non-existent entity details
    test_endpoint("/api/companies/invalid_id", "Non-existent company")
    test_endpoint("/api/consultants/invalid_id", "Non-existent consultant")
    test_endpoint("/api/field-consultants/invalid_id", "Non-existent field consultant")
    test_endpoint("/api/products/invalid_id", "Non-existent product")

def run_performance_tests():
    """Run performance tests"""
    print_separator("PERFORMANCE TESTS")
    
    print("⏱️  Running performance tests...")
    
    performance_endpoints = [
        ("/api/companies", {"limit": 20}),
        ("/api/consultants", {"limit": 20}),
        ("/api/field-consultants", {"limit": 20}),
        ("/api/products", {"limit": 20}),
        ("/api/analytics/dashboard", {}),
        ("/api/analytics/relationships", {}),
        ("/api/analytics/business-insights", {}),
        ("/api/filters/industries", {}),
        ("/api/filters/expertise", {}),
        ("/api/companies/comp_001", {}),
        ("/api/consultants/cons_001", {}),
    ]
    
    total_time = 0
    successful_requests = 0
    failed_requests = 0
    
    for endpoint, params in performance_endpoints:
        start_time = time.time()
        try:
            response = requests.get(f"{API_BASE_URL}{endpoint}", params=params, timeout=10)
            response_time = round((time.time() - start_time) * 1000, 2)
            
            if response.status_code == 200:
                print(f"✅ {endpoint}: {response_time}ms")
                total_time += response_time
                successful_requests += 1
            else:
                print(f"❌ {endpoint}: {response.status_code} status")
                failed_requests += 1
                
        except Exception as e:
            print(f"💥 {endpoint}: Error - {e}")
            failed_requests += 1
    
    if successful_requests > 0:
        avg_time = round(total_time / successful_requests, 2)
        print(f"\n📊 Performance Summary:")
        print(f"   Successful requests: {successful_requests}/{len(performance_endpoints)}")
        print(f"   Failed requests: {failed_requests}")
        print(f"   Average response time: {avg_time}ms")
        print(f"   Total test time: {round(total_time, 2)}ms")
        
        if avg_time < 100:
            print(f"   🚀 Excellent performance!")
        elif avg_time < 500:
            print(f"   ✅ Good performance")
        else:
            print(f"   ⚠️  Consider performance optimization")

def run_data_validation_tests():
    """Test data integrity and business logic"""
    print_separator("DATA VALIDATION TESTS")
    
    print("🔍 Validating business data integrity...")
    
    # Test that we have the expected core data
    test_endpoint("/api/companies", "Validate companies exist", params={"limit": 1})
    test_endpoint("/api/consultants", "Validate consultants exist", params={"limit": 1})
    test_endpoint("/api/field-consultants", "Validate field consultants exist", params={"limit": 1})
    test_endpoint("/api/products", "Validate products exist", params={"limit": 1})
    
    # Test specific expected entities from schema
    expected_companies = ["comp_001", "comp_002", "comp_003", "comp_004", "comp_005"]
    for comp_id in expected_companies:
        test_endpoint(f"/api/companies/{comp_id}", f"Validate company {comp_id} exists")
    
    expected_consultants = ["cons_001", "cons_002", "cons_003", "cons_004"]
    for cons_id in expected_consultants:
        test_endpoint(f"/api/consultants/{cons_id}", f"Validate consultant {cons_id} exists")
    
    expected_field_consultants = ["fc_001", "fc_002", "fc_003"]
    for fc_id in expected_field_consultants:
        test_endpoint(f"/api/field-consultants/{fc_id}", f"Validate field consultant {fc_id} exists")
    
    expected_products = ["prod_001", "prod_002", "prod_003", "prod_004"]
    for prod_id in expected_products:
        test_endpoint(f"/api/products/{prod_id}", f"Validate product {prod_id} exists")

def main():
    """Main test execution function"""
    print_header()
    
    try:
        # Test basic connectivity first
        if not test_basic_connectivity():
            print("\n🚨 CRITICAL FAILURE: Cannot proceed with API tests!")
            print("\nTroubleshooting steps:")
            print("1. Check if Neo4j Desktop is running")
            print("2. Verify database exists and is active")
            print("3. Check .env file credentials")
            print("4. Start FastAPI: uvicorn main:app --reload")
            sys.exit(1)
        
        # Run comprehensive API tests
        test_companies_api()
        test_consultants_api()
        test_field_consultants_api()
        test_products_api()
        test_analytics_api()
        test_filter_options_api()
        test_business_queries_api()
        test_edge_cases()
        
        # Run validation tests
        run_data_validation_tests()
        
        # Run performance tests
        run_performance_tests()
        
        # Final summary
        print_separator("TEST COMPLETION SUMMARY")
        print("🎉 Comprehensive API testing completed!")
        print("\n📋 Next Steps:")
        print("✅ 1. All endpoints working? Ready for React integration!")
        print("⚠️  2. Some endpoints failing? Check data exists in Neo4j")
        print("🚀 3. Performance good? Build your consulting dashboard!")
        print("\n🔗 Useful Links:")
        print(f"   📖 API Documentation: {API_BASE_URL}/docs")
        print(f"   🔍 Interactive Explorer: {API_BASE_URL}/redoc")
        print(f"   ❤️  Health Check: {API_BASE_URL}/health")
        print(f"   🏢 Business Context: Consulting ecosystem with Companies, Consultants, Field Consultants, and Products")
        
    except KeyboardInterrupt:
        print("\n\n🛑 Testing interrupted by user (Ctrl+C)")
        print("Tests completed up to this point.")
    except Exception as e:
        print(f"\n💥 Unexpected error during testing: {e}")
        print("Please check your setup and try again.")

if __name__ == "__main__":
    main()