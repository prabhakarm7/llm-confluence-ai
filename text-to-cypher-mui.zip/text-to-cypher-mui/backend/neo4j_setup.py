# neo4j_setup.py
"""
Script to set up and validate Neo4j schema for JPMC banking data
Run this after connecting to your Neo4j database
"""

from neo4j import GraphDatabase
import os
from dotenv import load_dotenv
from datetime import datetime, timedelta
import random

load_dotenv()

class Neo4jSetup:
    def __init__(self):
        self.uri = os.getenv("NEO4J_URI", "bolt://localhost:7687")
        self.user = os.getenv("NEO4J_USER", "neo4j")
        self.password = os.getenv("NEO4J_PASSWORD", "password")
        self.driver = GraphDatabase.driver(self.uri, auth=(self.user, self.password))

    def close(self):
        self.driver.close()

    def create_constraints(self):
        """Create unique constraints for better performance"""
        constraints = [
            "CREATE CONSTRAINT customer_id_unique IF NOT EXISTS FOR (c:Customer) REQUIRE c.id IS UNIQUE",
            "CREATE CONSTRAINT account_id_unique IF NOT EXISTS FOR (a:Account) REQUIRE a.id IS UNIQUE",
            "CREATE CONSTRAINT transaction_id_unique IF NOT EXISTS FOR (t:Transaction) REQUIRE t.id IS UNIQUE",
        ]
        
        with self.driver.session() as session:
            for constraint in constraints:
                try:
                    session.run(constraint)
                    print(f"✓ Created constraint: {constraint.split()[2]}")
                except Exception as e:
                    print(f"⚠ Constraint might already exist: {e}")

    def create_indexes(self):
        """Create indexes for better query performance"""
        indexes = [
            "CREATE INDEX transaction_date_idx IF NOT EXISTS FOR (t:Transaction) ON (t.date)",
            "CREATE INDEX transaction_amount_idx IF NOT EXISTS FOR (t:Transaction) ON (t.amount)",
            "CREATE INDEX transaction_type_idx IF NOT EXISTS FOR (t:Transaction) ON (t.transaction_type)",
            "CREATE INDEX account_number_idx IF NOT EXISTS FOR (a:Account) ON (a.account_number)",
        ]
        
        with self.driver.session() as session:
            for index in indexes:
                try:
                    session.run(index)
                    print(f"✓ Created index: {index.split()[2]}")
                except Exception as e:
                    print(f"⚠ Index might already exist: {e}")

    def validate_schema(self):
        """Validate that the required nodes and relationships exist"""
        queries = [
            ("Customers", "MATCH (c:Customer) RETURN count(c) as count"),
            ("Accounts", "MATCH (a:Account) RETURN count(a) as count"),
            ("Transactions", "MATCH (t:Transaction) RETURN count(t) as count"),
            ("Account-Customer relationships", "MATCH (a:Account)-[:OWNED_BY]->(c:Customer) RETURN count(*) as count"),
            ("Transaction-Account relationships", "MATCH (t:Transaction)-[:BELONGS_TO]->(a:Account) RETURN count(*) as count"),
        ]
        
        print("\n=== Database Validation ===")
        with self.driver.session() as session:
            for name, query in queries:
                result = session.run(query).single()
                count = result["count"] if result else 0
                print(f"{name}: {count}")
        
        # Check for required properties
        print("\n=== Property Validation ===")
        property_checks = [
            ("Transaction properties", """
                MATCH (t:Transaction) 
                RETURN 
                    count(t) as total,
                    count(t.id) as has_id,
                    count(t.amount) as has_amount,
                    count(t.date) as has_date,
                    count(t.transaction_type) as has_type,
                    count(t.description) as has_description,
                    count(t.category) as has_category
                LIMIT 1
            """),
            ("Account properties", """
                MATCH (a:Account) 
                RETURN 
                    count(a) as total,
                    count(a.id) as has_id,
                    count(a.account_number) as has_number,
                    count(a.account_type) as has_type,
                    count(a.balance) as has_balance
                LIMIT 1
            """),
        ]
        
        for name, query in property_checks:
            result = session.run(query).single()
            if result:
                print(f"\n{name}:")
                for key, value in result.items():
                    print(f"  {key}: {value}")

    def create_sample_data(self, num_customers=5, num_accounts_per_customer=2, num_transactions_per_account=50):
        """Create sample data for testing (only if database is empty)"""
        
        # Check if data already exists
        with self.driver.session() as session:
            result = session.run("MATCH (c:Customer) RETURN count(c) as count").single()
            if result["count"] > 0:
                print("Data already exists. Skipping sample data creation.")
                return
        
        print(f"\n=== Creating Sample Data ===")
        print(f"Creating {num_customers} customers...")
        
        transaction_types = ["DEBIT", "CREDIT", "TRANSFER", "ATM_WITHDRAWAL", "DEPOSIT"]
        categories = ["Groceries", "Gas", "Restaurant", "Shopping", "Utilities", "Salary", "Entertainment", "Healthcare"]
        account_types = ["CHECKING", "SAVINGS", "CREDIT"]
        
        with self.driver.session() as session:
            for customer_id in range(1, num_customers + 1):
                # Create customer
                session.run("""
                    CREATE (c:Customer {
                        id: $customer_id,
                        name: $name,
                        email: $email,
                        phone: $phone,
                        created_date: $created_date
                    })
                """, {
                    "customer_id": f"CUST_{customer_id:04d}",
                    "name": f"Customer {customer_id}",
                    "email": f"customer{customer_id}@jpmc.com",
                    "phone": f"555-{customer_id:04d}",
                    "created_date": "2020-01-01"
                })
                
                # Create accounts for this customer
                for account_num in range(1, num_accounts_per_customer + 1):
                    account_id = f"ACC_{customer_id:04d}_{account_num}"
                    account_number = f"{customer_id:04d}{account_num:02d}{random.randint(1000, 9999)}"
                    
                    session.run("""
                        MATCH (c:Customer {id: $customer_id})
                        CREATE (a:Account {
                            id: $account_id,
                            account_number: $account_number,
                            account_type: $account_type,
                            balance: $balance,
                            created_date: $created_date
                        })
                        CREATE (a)-[:OWNED_BY]->(c)
                    """, {
                        "customer_id": f"CUST_{customer_id:04d}",
                        "account_id": account_id,
                        "account_number": account_number,
                        "account_type": random.choice(account_types),
                        "balance": round(random.uniform(100, 50000), 2),
                        "created_date": "2020-01-01"
                    })
                    
                    # Create transactions for this account
                    print(f"Creating transactions for account {account_id}...")
                    
                    for trans_num in range(1, num_transactions_per_account + 1):
                        transaction_id = f"TXN_{customer_id:04d}_{account_num}_{trans_num:04d}"
                        
                        # Generate random date within last year
                        days_ago = random.randint(1, 365)
                        transaction_date = (datetime.now() - timedelta(days=days_ago)).strftime("%Y-%m-%d")
                        
                        # Generate random amount (mix of positive and negative)
                        amount = round(random.uniform(-1000, 2000), 2)
                        transaction_type = random.choice(transaction_types)
                        category = random.choice(categories)
                        
                        descriptions = [
                            f"{category} Purchase",
                            f"Online {category}",
                            f"{category} - Store Location",
                            f"Recurring {category}",
                            f"{category} Payment"
                        ]
                        
                        session.run("""
                            MATCH (a:Account {id: $account_id})
                            CREATE (t:Transaction {
                                id: $transaction_id,
                                amount: $amount,
                                transaction_type: $transaction_type,
                                description: $description,
                                date: $date,
                                category: $category,
                                balance_after: $balance_after
                            })
                            CREATE (t)-[:BELONGS_TO]->(a)
                        """, {
                            "account_id": account_id,
                            "transaction_id": transaction_id,
                            "amount": amount,
                            "transaction_type": transaction_type,
                            "description": random.choice(descriptions),
                            "date": transaction_date,
                            "category": category,
                            "balance_after": round(random.uniform(100, 10000), 2)
                        })
        
        print(f"✓ Created {num_customers} customers with {num_customers * num_accounts_per_customer} accounts and {num_customers * num_accounts_per_customer * num_transactions_per_account} transactions")

def main():
    setup = Neo4jSetup()
    
    try:
        print("=== Neo4j Database Setup ===")
        
        # Test connection
        with setup.driver.session() as session:
            result = session.run("RETURN 'Connected' as status")
            print(f"✓ Database connection: {result.single()['status']}")
        
        # Create constraints and indexes
        setup.create_constraints()
        setup.create_indexes()
        
        # Validate existing schema
        setup.validate_schema()
        
        # Ask if user wants to create sample data
        create_sample = input("\nWould you like to create sample data? (y/N): ").lower().strip()
        if create_sample == 'y':
            setup.create_sample_data()
            print("\n=== Final Validation ===")
            setup.validate_schema()
        
        print("\n✓ Setup complete! Your FastAPI server should now work with the database.")
        print("✓ You can now start your FastAPI server with: uvicorn main:app --reload")
        
    except Exception as e:
        print(f"✗ Error during setup: {e}")
    finally:
        setup.close()

if __name__ == "__main__":
    main()