# database_diagnostic.py
"""
Comprehensive diagnostic script for the Consulting Business Graph database
Validates schema, data, and relationships based on the business context
"""

from neo4j import GraphDatabase
import os
from dotenv import load_dotenv
import json

load_dotenv()

class ConsultingDatabaseDiagnostic:
    def __init__(self):
        self.uri = os.getenv('NEO4J_URI', 'neo4j://localhost:7687')
        self.user = os.getenv('NEO4J_USER', 'neo4j')
        self.password = os.getenv('NEO4J_PASSWORD', 'test1234')
        self.database = os.getenv('NEO4J_DATABASE', 'neo4j_consulting')
        self.driver = None
        
        # Expected data from the business schema
        self.expected_companies = [
            {'id': 'comp_001', 'name': 'TechFlow Corp', 'industry': 'Technology'},
            {'id': 'comp_002', 'name': 'HealthFirst Solutions', 'industry': 'Healthcare'},
            {'id': 'comp_003', 'name': 'FinanceMax Ltd', 'industry': 'Finance'},
            {'id': 'comp_004', 'name': 'RetailHub Inc', 'industry': 'Retail'},
            {'id': 'comp_005', 'name': 'ManufacturingPro', 'industry': 'Manufacturing'}
        ]
        
        self.expected_consultants = [
            {'id': 'cons_001', 'name': 'Sarah Chen', 'seniority': 'Partner'},
            {'id': 'cons_002', 'name': 'Michael Rodriguez', 'seniority': 'Principal'},
            {'id': 'cons_003', 'name': 'Emily Watson', 'seniority': 'Senior'},
            {'id': 'cons_004', 'name': 'David Kim', 'seniority': 'Principal'}
        ]
        
        self.expected_field_consultants = [
            {'id': 'fc_001', 'name': 'James Wilson', 'region': 'West Coast'},
            {'id': 'fc_002', 'name': 'Lisa Park', 'region': 'East Coast'},
            {'id': 'fc_003', 'name': 'Robert Taylor', 'region': 'Midwest'}
        ]
        
        self.expected_products = [
            {'id': 'prod_001', 'name': 'CloudFlow Platform', 'category': 'Software'},
            {'id': 'prod_002', 'name': 'DataAnalytics Pro', 'category': 'Software'},
            {'id': 'prod_003', 'name': 'SecureNet Gateway', 'category': 'Hardware'},
            {'id': 'prod_004', 'name': 'WorkFlow Manager', 'category': 'Software'}
        ]
        
        self.expected_relationships = ['COVERS', 'EMPLOYS', 'OWNS', 'RATES', 'RECOMMENDS']

    def connect(self):
        """Connect to Neo4j database"""
        try:
            self.driver = GraphDatabase.driver(self.uri, auth=(self.user, self.password))
            return True
        except Exception as e:
            print(f"❌ Connection failed: {e}")
            return False

    def close(self):
        """Close database connection"""
        if self.driver:
            self.driver.close()

    def execute_query(self, query, parameters=None):
        """Execute a query and return results"""
        try:
            with self.driver.session(database=self.database) as session:
                result = session.run(query, parameters or {})
                return [record.data() for record in result]
        except Exception as e:
            print(f"⚠️ Query failed: {e}")
            return []

    def print_header(self):
        """Print diagnostic header"""
        print("🏢" + "="*80)
        print("  CONSULTING BUSINESS GRAPH DATABASE DIAGNOSTIC")
        print("  Schema: Companies → Consultants → Field_Consultants → Products")
        print("="*82)
        print(f"🔗 URI: {self.uri}")
        print(f"👤 User: {self.user}")
        print(f"🗃️  Database: {self.database}")
        print("="*82)

    def test_basic_connection(self):
        """Test basic database connectivity"""
        print("\n1️⃣ TESTING BASIC CONNECTION")
        print("-" * 40)
        
        try:
            # Test basic query
            result = self.execute_query("RETURN 1 as test")
            if result and result[0]['test'] == 1:
                print("✅ Basic connection successful")
                
                # Test database access
                result = self.execute_query("MATCH (n) RETURN count(n) as total_nodes")
                if result:
                    total = result[0]['total_nodes']
                    print(f"✅ Database accessible with {total} total nodes")
                    return True
                else:
                    print("⚠️ Database accessible but query failed")
                    return False
            else:
                print("❌ Basic query failed")
                return False
                
        except Exception as e:
            print(f"❌ Connection test failed: {e}")
            return False

    def check_available_databases(self):
        """Check what databases are available"""
        print("\n2️⃣ CHECKING AVAILABLE DATABASES")
        print("-" * 40)
        
        try:
            # Try to list databases (this works on Neo4j 4.0+)
            with self.driver.session() as session:
                result = session.run("SHOW DATABASES")
                databases = []
                print("📊 Available databases:")
                for record in result:
                    name = record['name']
                    status = record['currentStatus']
                    databases.append(name)
                    print(f"  • {name}: {status}")
                
                return databases
                
        except Exception as e:
            print(f"⚠️ Cannot list databases (might be older Neo4j version): {e}")
            print("🔍 Testing common database names...")
            
            # Test common database names
            common_dbs = ['neo4j', 'consulting-graph', 'jpmc-banking-graph']
            available_dbs = []
            
            for db_name in common_dbs:
                try:
                    with self.driver.session(database=db_name) as session:
                        session.run("RETURN 1")
                        available_dbs.append(db_name)
                        print(f"  ✅ {db_name}: accessible")
                except:
                    print(f"  ❌ {db_name}: not accessible")
            
            return available_dbs

    def validate_node_types(self):
        """Validate expected node types exist"""
        print("\n3️⃣ VALIDATING NODE TYPES")
        print("-" * 40)
        
        # Get all node labels
        result = self.execute_query("CALL db.labels()")
        if result:
            existing_labels = [record['label'] for record in result]
            print(f"📋 Found node labels: {existing_labels}")
        else:
            # Fallback method
            result = self.execute_query("MATCH (n) RETURN DISTINCT labels(n) as labels")
            existing_labels = []
            for record in result:
                existing_labels.extend(record['labels'])
            existing_labels = list(set(existing_labels))
            print(f"📋 Found node labels: {existing_labels}")
        
        expected_labels = ['Company', 'Consultant', 'Field_Consultant', 'Product']
        missing_labels = set(expected_labels) - set(existing_labels)
        
        if missing_labels:
            print(f"⚠️ Missing expected labels: {missing_labels}")
            return False
        else:
            print("✅ All expected node types present")
            
        # Count nodes by type
        print("\n📊 Node counts by type:")
        for label in expected_labels:
            result = self.execute_query(f"MATCH (n:{label}) RETURN count(n) as count")
            count = result[0]['count'] if result else 0
            print(f"  • {label}: {count} nodes")
        
        return True

    def validate_relationships(self):
        """Validate expected relationships exist"""
        print("\n4️⃣ VALIDATING RELATIONSHIPS")
        print("-" * 40)
        
        # Get all relationship types
        result = self.execute_query("CALL db.relationshipTypes()")
        if result:
            existing_rels = [record['relationshipType'] for record in result]
        else:
            # Fallback method
            result = self.execute_query("MATCH ()-[r]->() RETURN DISTINCT type(r) as rel_type")
            existing_rels = [record['rel_type'] for record in result]
        
        print(f"📋 Found relationship types: {existing_rels}")
        
        missing_rels = set(self.expected_relationships) - set(existing_rels)
        
        if missing_rels:
            print(f"⚠️ Missing expected relationships: {missing_rels}")
            return False
        else:
            print("✅ All expected relationship types present")
        
        # Count relationships by type
        print("\n📊 Relationship counts by type:")
        for rel_type in self.expected_relationships:
            result = self.execute_query(f"MATCH ()-[r:{rel_type}]->() RETURN count(r) as count")
            count = result[0]['count'] if result else 0
            print(f"  • {rel_type}: {count} relationships")
        
        return True

    def validate_expected_data(self):
        """Validate specific expected entities from the schema"""
        print("\n5️⃣ VALIDATING EXPECTED DATA")
        print("-" * 40)
        
    def validate_expected_data(self):
        """Validate specific expected entities from the schema"""
        print("\n5️⃣ VALIDATING EXPECTED DATA")
        print("-" * 40)
        
        data_valid = True
        
        # Validate companies
        print("🏢 Validating companies...")
        companies_found = 0
        for expected_company in self.expected_companies:
            result = self.execute_query(
                "MATCH (c:Company {id: $id}) RETURN c.name as name, c.industry as industry",
                {"id": expected_company['id']}
            )
            if result:
                actual = result[0]
                if actual['name'] == expected_company['name']:
                    print(f"  ✅ {expected_company['name']} (ID: {expected_company['id']})")
                    companies_found += 1
                else:
                    print(f"  ⚠️ {expected_company['id']} found but name mismatch: {actual['name']} != {expected_company['name']}")
            else:
                print(f"  ❌ {expected_company['name']} (ID: {expected_company['id']}) not found")
                data_valid = False
        
        print(f"📊 Companies validation: {companies_found}/{len(self.expected_companies)} found")
        
        # Validate consultants
        print("\n👨‍💼 Validating consultants...")
        consultants_found = 0
        for expected_consultant in self.expected_consultants:
            result = self.execute_query(
                "MATCH (cons:Consultant {id: $id}) RETURN cons.name as name, cons.seniority as seniority",
                {"id": expected_consultant['id']}
            )
            if result:
                actual = result[0]
                if actual['name'] == expected_consultant['name']:
                    print(f"  ✅ {expected_consultant['name']} ({expected_consultant['seniority']})")
                    consultants_found += 1
                else:
                    print(f"  ⚠️ {expected_consultant['id']} found but name mismatch")
            else:
                print(f"  ❌ {expected_consultant['name']} not found")
                data_valid = False
        
        print(f"📊 Consultants validation: {consultants_found}/{len(self.expected_consultants)} found")
        
        # Validate field consultants
        print("\n🔧 Validating field consultants...")
        field_consultants_found = 0
        for expected_fc in self.expected_field_consultants:
            result = self.execute_query(
                "MATCH (fc:Field_Consultant {id: $id}) RETURN fc.name as name, fc.region as region",
                {"id": expected_fc['id']}
            )
            if result:
                actual = result[0]
                if actual['name'] == expected_fc['name']:
                    print(f"  ✅ {expected_fc['name']} ({expected_fc['region']})")
                    field_consultants_found += 1
                else:
                    print(f"  ⚠️ {expected_fc['id']} found but name mismatch")
            else:
                print(f"  ❌ {expected_fc['name']} not found")
                data_valid = False
        
        print(f"📊 Field consultants validation: {field_consultants_found}/{len(self.expected_field_consultants)} found")
        
        # Validate products
        print("\n📦 Validating products...")
        products_found = 0
        for expected_product in self.expected_products:
            result = self.execute_query(
                "MATCH (p:Product {id: $id}) RETURN p.name as name, p.category as category",
                {"id": expected_product['id']}
            )
            if result:
                actual = result[0]
                if actual['name'] == expected_product['name']:
                    print(f"  ✅ {expected_product['name']} ({expected_product['category']})")
                    products_found += 1
                else:
                    print(f"  ⚠️ {expected_product['id']} found but name mismatch")
            else:
                print(f"  ❌ {expected_product['name']} not found")
                data_valid = False
        
        print(f"📊 Products validation: {products_found}/{len(self.expected_products)} found")
        
        return data_valid

    def validate_property_completeness(self):
        """Check if nodes have expected properties"""
        print("\n6️⃣ VALIDATING PROPERTY COMPLETENESS")
        print("-" * 40)
        
        # Check company properties
        print("🏢 Company property completeness:")
        company_properties = ['id', 'name', 'industry', 'size', 'revenue', 'location', 'founded_year', 'employee_count', 'status']
        result = self.execute_query("MATCH (c:Company) RETURN c LIMIT 1")
        if result:
            actual_props = list(result[0]['c'].keys())
            missing_props = set(company_properties) - set(actual_props)
            if missing_props:
                print(f"  ⚠️ Missing properties: {missing_props}")
            else:
                print(f"  ✅ All expected properties present")
            print(f"  📋 Actual properties: {actual_props}")
        
        # Check consultant properties
        print("\n👨‍💼 Consultant property completeness:")
        consultant_properties = ['id', 'name', 'expertise', 'seniority', 'years_experience', 'hourly_rate', 'location', 'education', 'rating', 'availability']
        result = self.execute_query("MATCH (cons:Consultant) RETURN cons LIMIT 1")
        if result:
            actual_props = list(result[0]['cons'].keys())
            missing_props = set(consultant_properties) - set(actual_props)
            if missing_props:
                print(f"  ⚠️ Missing properties: {missing_props}")
            else:
                print(f"  ✅ All expected properties present")
            print(f"  📋 Actual properties: {actual_props}")
        
        # Check field consultant properties
        print("\n🔧 Field consultant property completeness:")
        fc_properties = ['id', 'name', 'specialization', 'region', 'years_experience', 'certification_level', 'hourly_rate', 'languages', 'rating', 'availability', 'travel_willingness']
        result = self.execute_query("MATCH (fc:Field_Consultant) RETURN fc LIMIT 1")
        if result:
            actual_props = list(result[0]['fc'].keys())
            missing_props = set(fc_properties) - set(actual_props)
            if missing_props:
                print(f"  ⚠️ Missing properties: {missing_props}")
            else:
                print(f"  ✅ All expected properties present")
            print(f"  📋 Actual properties: {actual_props}")
        
        # Check product properties
        print("\n📦 Product property completeness:")
        product_properties = ['id', 'name', 'category', 'vendor', 'price_range', 'target_market', 'deployment_type', 'industry_focus', 'maturity', 'rating', 'launch_date']
        result = self.execute_query("MATCH (p:Product) RETURN p LIMIT 1")
        if result:
            actual_props = list(result[0]['p'].keys())
            missing_props = set(product_properties) - set(actual_props)
            if missing_props:
                print(f"  ⚠️ Missing properties: {missing_props}")
            else:
                print(f"  ✅ All expected properties present")
            print(f"  📋 Actual properties: {actual_props}")

    def validate_relationships_integrity(self):
        """Validate relationship integrity and properties"""
        print("\n7️⃣ VALIDATING RELATIONSHIP INTEGRITY")
        print("-" * 40)
        
        # Check COVERS relationships
        print("🔗 COVERS relationships:")
        result = self.execute_query("""
            MATCH (person)-[covers:COVERS]->(comp:Company)
            RETURN labels(person)[0] as person_type, count(*) as count
        """)
        for record in result:
            print(f"  • {record['person_type']} → Company: {record['count']} relationships")
        
        # Sample COVERS relationship properties
        result = self.execute_query("MATCH ()-[covers:COVERS]->() RETURN covers LIMIT 1")
        if result:
            covers_props = list(result[0]['covers'].keys())
            print(f"  📋 COVERS properties: {covers_props}")
        
        # Check EMPLOYS relationships
        print("\n🔗 EMPLOYS relationships:")
        result = self.execute_query("""
            MATCH (comp:Company)-[emp:EMPLOYS]->(person)
            RETURN labels(person)[0] as person_type, count(*) as count
        """)
        for record in result:
            print(f"  • Company → {record['person_type']}: {record['count']} relationships")
        
        # Check OWNS relationships
        print("\n🔗 OWNS relationships:")
        result = self.execute_query("MATCH (comp:Company)-[owns:OWNS]->(prod:Product) RETURN count(*) as count")
        if result:
            print(f"  • Company → Product: {result[0]['count']} relationships")
        
        # Check RATES relationships
        print("\n🔗 RATES relationships:")
        result = self.execute_query("""
            MATCH (person)-[rates:RATES]->(prod:Product)
            RETURN labels(person)[0] as person_type, count(*) as count
        """)
        for record in result:
            print(f"  • {record['person_type']} → Product: {record['count']} relationships")
        
        # Check RECOMMENDS relationships
        print("\n🔗 RECOMMENDS relationships:")
        result = self.execute_query("""
            MATCH (person)-[rec:RECOMMENDS]->(prod:Product)
            RETURN labels(person)[0] as person_type, count(*) as count
        """)
        for record in result:
            print(f"  • {record['person_type']} → Product: {record['count']} relationships")

    def analyze_business_metrics(self):
        """Analyze key business metrics"""
        print("\n8️⃣ BUSINESS METRICS ANALYSIS")
        print("-" * 40)
        
        # Industry distribution
        print("🏭 Industry distribution:")
        result = self.execute_query("""
            MATCH (c:Company)
            RETURN c.industry as industry, count(*) as count, sum(c.revenue) as total_revenue
            ORDER BY count DESC
        """)
        for record in result:
            revenue = record['total_revenue'] if record['total_revenue'] else 0
            print(f"  • {record['industry']}: {record['count']} companies, ${revenue}M revenue")
        
        # Consultant seniority distribution
        print("\n👨‍💼 Consultant seniority distribution:")
        result = self.execute_query("""
            MATCH (cons:Consultant)
            RETURN cons.seniority as seniority, count(*) as count, avg(cons.hourly_rate) as avg_rate
            ORDER BY avg_rate DESC
        """)
        for record in result:
            avg_rate = record['avg_rate'] if record['avg_rate'] else 0
            print(f"  • {record['seniority']}: {record['count']} consultants, ${avg_rate:.0f}/hr avg")
        
        # Product category distribution
        print("\n📦 Product category distribution:")
        result = self.execute_query("""
            MATCH (p:Product)
            RETURN p.category as category, count(*) as count, avg(p.rating) as avg_rating
            ORDER BY count DESC
        """)
        for record in result:
            avg_rating = record['avg_rating'] if record['avg_rating'] else 0
            print(f"  • {record['category']}: {record['count']} products, {avg_rating:.1f} avg rating")
        
        # Contract value analysis
        print("\n💰 Contract value analysis:")
        result = self.execute_query("""
            MATCH ()-[covers:COVERS]->()
            RETURN 
                sum(covers.contract_value) as total_value,
                avg(covers.contract_value) as avg_value,
                max(covers.contract_value) as max_value,
                avg(covers.satisfaction_score) as avg_satisfaction
        """)
        if result and result[0]['total_value']:
            record = result[0]
            print(f"  • Total contract value: ${record['total_value']:,}")
            print(f"  • Average contract value: ${record['avg_value']:,.0f}")
            print(f"  • Largest contract: ${record['max_value']:,}")
            print(f"  • Average satisfaction: {record['avg_satisfaction']:.1f}/5.0")

    def check_data_quality_issues(self):
        """Check for potential data quality issues"""
        print("\n9️⃣ DATA QUALITY CHECKS")
        print("-" * 40)
        
        issues_found = 0
        
        # Check for missing required properties
        print("🔍 Checking for missing required properties...")
        
        # Companies without required fields
        result = self.execute_query("""
            MATCH (c:Company)
            WHERE c.name IS NULL OR c.industry IS NULL OR c.revenue IS NULL
            RETURN count(c) as count
        """)
        if result and result[0]['count'] > 0:
            print(f"  ⚠️ {result[0]['count']} companies missing required properties")
            issues_found += 1
        
        # Consultants without required fields
        result = self.execute_query("""
            MATCH (cons:Consultant)
            WHERE cons.name IS NULL OR cons.expertise IS NULL OR cons.seniority IS NULL
            RETURN count(cons) as count
        """)
        if result and result[0]['count'] > 0:
            print(f"  ⚠️ {result[0]['count']} consultants missing required properties")
            issues_found += 1
        
        # Check for orphaned nodes (nodes without relationships)
        print("\n🔍 Checking for orphaned nodes...")
        
        orphaned_queries = [
            ("Companies", "MATCH (c:Company) WHERE NOT (c)-[]-() RETURN count(c) as count"),
            ("Consultants", "MATCH (cons:Consultant) WHERE NOT (cons)-[]-() RETURN count(cons) as count"),
            ("Field_Consultants", "MATCH (fc:Field_Consultant) WHERE NOT (fc)-[]-() RETURN count(fc) as count"),
            ("Products", "MATCH (p:Product) WHERE NOT (p)-[]-() RETURN count(p) as count")
        ]
        
        for node_type, query in orphaned_queries:
            result = self.execute_query(query)
            if result and result[0]['count'] > 0:
                print(f"  ⚠️ {result[0]['count']} orphaned {node_type}")
                issues_found += 1
        
        # Check for invalid ratings
        print("\n🔍 Checking for invalid ratings...")
        result = self.execute_query("""
            MATCH (n)
            WHERE n.rating IS NOT NULL AND (n.rating < 1.0 OR n.rating > 5.0)
            RETURN labels(n)[0] as node_type, count(n) as count
        """)
        for record in result:
            if record['count'] > 0:
                print(f"  ⚠️ {record['count']} {record['node_type']} with invalid ratings")
                issues_found += 1
        
        if issues_found == 0:
            print("✅ No data quality issues found")
        else:
            print(f"⚠️ Found {issues_found} potential data quality issues")

    def generate_recommendations(self):
        """Generate recommendations based on diagnostic results"""
        print("\n🔟 RECOMMENDATIONS")
        print("-" * 40)
        
        # Check if we have sufficient data
        total_nodes = self.execute_query("MATCH (n) RETURN count(n) as count")[0]['count']
        total_relationships = self.execute_query("MATCH ()-[r]->() RETURN count(r) as count")[0]['count']
        
        print(f"📊 Database summary: {total_nodes} nodes, {total_relationships} relationships")
        
        if total_nodes == 0:
            print("\n🚨 CRITICAL: Database is empty!")
            print("📋 Action needed:")
            print("  1. Load the schema data from your business context document")
            print("  2. Run the CREATE statements for Companies, Consultants, Field_Consultants, and Products")
            print("  3. Create the relationships (COVERS, EMPLOYS, OWNS, RATES, RECOMMENDS)")
            
        elif total_nodes < 20:
            print("\n⚠️ WARNING: Limited data detected")
            print("📋 Recommendations:")
            print("  1. Consider loading more sample data for testing")
            print("  2. Verify all expected entities are present")
            print("  3. Add more relationships for realistic business scenarios")
            
        else:
            print("\n✅ Good data volume detected")
            print("📋 Recommendations:")
            print("  1. API should work well with current data")
            print("  2. Consider adding more diverse test cases")
            print("  3. Monitor performance with larger datasets")
        
        # API readiness check
        companies = self.execute_query("MATCH (c:Company) RETURN count(c) as count")[0]['count']
        consultants = self.execute_query("MATCH (cons:Consultant) RETURN count(cons) as count")[0]['count']
        
        if companies > 0 and consultants > 0:
            print("\n🚀 API READINESS: Ready for FastAPI integration!")
            print("📋 Next steps:")
            print("  1. Update your .env file:")
            print(f"     NEO4J_DATABASE={self.database}")
            print("  2. Start FastAPI server: uvicorn main:app --reload")
            print("  3. Run API tests: python test_consulting_api.py")
            print("  4. Build your React frontend")
        else:
            print("\n❌ API READINESS: Not ready - missing core data")

def main():
    """Main diagnostic execution"""
    diagnostic = ConsultingDatabaseDiagnostic()
    diagnostic.print_header()
    
    if not diagnostic.connect():
        print("❌ Cannot connect to database. Exiting.")
        return
    
    try:
        # Run comprehensive diagnostics
        if not diagnostic.test_basic_connection():
            print("❌ Basic connection failed. Exiting.")
            return
        
        diagnostic.check_available_databases()
        diagnostic.validate_node_types()
        diagnostic.validate_relationships()
        diagnostic.validate_expected_data()
        diagnostic.validate_property_completeness()
        diagnostic.validate_relationships_integrity()
        diagnostic.analyze_business_metrics()
        diagnostic.check_data_quality_issues()
        diagnostic.generate_recommendations()
        
        print("\n" + "="*82)
        print("🎉 DIAGNOSTIC COMPLETE!")
        print("Check the recommendations above for next steps.")
        print("="*82)
        
    except Exception as e:
        print(f"\n💥 Diagnostic failed: {e}")
    finally:
        diagnostic.close()

if __name__ == "__main__":
    main()