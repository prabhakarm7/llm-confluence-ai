# Check jpmc-banking-graph database specifically
from neo4j import GraphDatabase
import os
from dotenv import load_dotenv

load_dotenv()

uri = os.getenv('NEO4J_URI', 'neo4j://localhost:7687')
user = os.getenv('NEO4J_USER', 'neo4j')
password = os.getenv('NEO4J_PASSWORD', 'test1234')
database = 'jpmc-banking-graph'

print(f'🔍 Checking database: {database}')

try:
    driver = GraphDatabase.driver(uri, auth=(user, password))
    
    with driver.session(database=database) as session:
        # Check all node types
        result = session.run('MATCH (n) RETURN labels(n) as labels, count(n) as count ORDER BY count DESC')
        total = 0
        print(f'\n📊 Node types in {database}:')
        for record in result:
            labels = record['labels']
            count = record['count']
            total += count
            print(f'  • {labels}: {count} nodes')
        
        print(f'\n📈 Total nodes: {total}')
        
        if total == 0:
            print(f'\n❌ Database {database} is empty!')
            print('🔧 Possible solutions:')
            print('1. Data might be in a different database')
            print('2. Data needs to be imported')
            print('3. Database name might be different')
        else:
            # Show sample data
            print(f'\n📋 Sample data:')
            sample = session.run('MATCH (n) RETURN n LIMIT 5')
            for i, record in enumerate(sample, 1):
                node = record['n']
                print(f'  {i}. {dict(node)}')
    
    driver.close()
    
except Exception as e:
    print(f'❌ Error: {e}')
    print('\n🔧 This might mean:')
    print('1. Database jpmc-banking-graph does not exist')
    print('2. Wrong database name')
    print('3. Data was loaded into a different database')
