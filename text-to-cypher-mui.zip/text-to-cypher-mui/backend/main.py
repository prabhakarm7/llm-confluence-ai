# main.py
"""
FastAPI backend for Consulting Business Graph database
Based on the exact schema with Companies, Consultants, Field_Consultants, and Products
Includes all properties and relationships from the business context
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional, List, Dict, Any
from datetime import datetime, date
import os
from dotenv import load_dotenv
from neo4j import GraphDatabase
import logging

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Consulting Business Graph API",
    description="API for consulting business ecosystem - Companies, Consultants, Field Consultants, Products, and their relationships",
    version="1.0.0"
)

# CORS middleware for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173", "http://localhost:3001"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Neo4j Database Connection
class Neo4jConnection:
    def __init__(self):
        self.uri = os.getenv("NEO4J_URI", "neo4j://localhost:7687")
        self.user = os.getenv("NEO4J_USER", "neo4j")
        self.password = os.getenv("NEO4J_PASSWORD", "test1234")
        self.database = os.getenv("NEO4J_DATABASE", "neo4j_consulting")
        self.driver = None
        
    def connect(self):
        try:
            self.driver = GraphDatabase.driver(self.uri, auth=(self.user, self.password))
            logger.info(f"Connected to Neo4j database: {self.database}")
        except Exception as e:
            logger.error(f"Failed to connect to Neo4j: {e}")
            raise

    def close(self):
        if self.driver:
            self.driver.close()
            logger.info("Neo4j connection closed")

    def execute_query(self, query: str, parameters: dict = None):
        try:
            with self.driver.session(database=self.database) as session:
                result = session.run(query, parameters or {})
                return [record.data() for record in result]
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise HTTPException(status_code=500, detail=f"Database query failed: {str(e)}")

# Global database connection
db = Neo4jConnection()

@app.on_event("startup")
async def startup_event():
    db.connect()

@app.on_event("shutdown")
async def shutdown_event():
    db.close()

# API Endpoints

@app.get("/")
async def root():
    return {
        "message": "Consulting Business Graph API", 
        "status": "running", 
        "database": db.database,
        "version": "1.0.0",
        "endpoints": {
            "companies": "/api/companies",
            "consultants": "/api/consultants", 
            "field_consultants": "/api/field-consultants",
            "products": "/api/products",
            "analytics": "/api/analytics",
            "health": "/health"
        }
    }

# ===== COMPANIES API =====

@app.get("/api/companies")
async def get_companies(
    industry: Optional[str] = Query(None, description="Filter by industry (Technology, Healthcare, Finance, Retail, Manufacturing)"),
    size: Optional[str] = Query(None, description="Filter by company size (Startup, SME, Enterprise)"),
    location: Optional[str] = Query(None, description="Filter by location"),
    min_revenue: Optional[int] = Query(None, description="Minimum revenue in millions"),
    max_revenue: Optional[int] = Query(None, description="Maximum revenue in millions"),
    status: Optional[str] = Query("Active", description="Company status (Active, Acquired, IPO)"),
    min_employees: Optional[int] = Query(None, description="Minimum employee count"),
    max_employees: Optional[int] = Query(None, description="Maximum employee count"),
    founded_after: Optional[int] = Query(None, description="Founded after year"),
    founded_before: Optional[int] = Query(None, description="Founded before year"),
    limit: int = Query(50, description="Maximum number of results")
):
    """Get companies with comprehensive filters based on business schema"""
    
    query = "MATCH (c:Company) WHERE 1=1"
    parameters = {"limit": limit}
    
    if status:
        query += " AND c.status = $status"
        parameters["status"] = status
    
    if industry:
        query += " AND c.industry = $industry"
        parameters["industry"] = industry
    
    if size:
        query += " AND c.size = $size"
        parameters["size"] = size
    
    if location:
        query += " AND c.location CONTAINS $location"
        parameters["location"] = location
    
    if min_revenue is not None:
        query += " AND c.revenue >= $min_revenue"
        parameters["min_revenue"] = min_revenue
    
    if max_revenue is not None:
        query += " AND c.revenue <= $max_revenue"
        parameters["max_revenue"] = max_revenue
    
    if min_employees is not None:
        query += " AND c.employee_count >= $min_employees"
        parameters["min_employees"] = min_employees
    
    if max_employees is not None:
        query += " AND c.employee_count <= $max_employees"
        parameters["max_employees"] = max_employees
    
    if founded_after is not None:
        query += " AND c.founded_year >= $founded_after"
        parameters["founded_after"] = founded_after
    
    if founded_before is not None:
        query += " AND c.founded_year <= $founded_before"
        parameters["founded_before"] = founded_before
    
    query += """
    RETURN c.id as id, c.name as name, c.industry as industry, 
           c.size as size, c.revenue as revenue, c.location as location,
           c.founded_year as founded_year, c.employee_count as employee_count,
           c.status as status, c.market_cap as market_cap
    ORDER BY c.revenue DESC
    LIMIT $limit
    """
    
    results = db.execute_query(query, parameters)
    return results

@app.get("/api/companies/{company_id}")
async def get_company_details(company_id: str):
    """Get comprehensive company details with all relationships"""
    
    # Get company details
    company_query = """
    MATCH (c:Company {id: $company_id})
    RETURN c.id as id, c.name as name, c.industry as industry, 
           c.size as size, c.revenue as revenue, c.location as location,
           c.founded_year as founded_year, c.employee_count as employee_count,
           c.status as status, c.market_cap as market_cap
    """
    
    company_result = db.execute_query(company_query, {"company_id": company_id})
    if not company_result:
        raise HTTPException(status_code=404, detail="Company not found")
    
    company = company_result[0]
    
    # Get consultants covering this company (COVERS relationship)
    consultants_coverage_query = """
    MATCH (cons:Consultant)-[covers:COVERS]->(c:Company {id: $company_id})
    RETURN cons.id as id, cons.name as name, cons.expertise as expertise,
           cons.seniority as seniority, cons.rating as rating,
           covers.coverage_type as coverage_type, covers.contract_value as contract_value, 
           covers.satisfaction_score as satisfaction_score, covers.status as status,
           covers.start_date as start_date, covers.end_date as end_date
    """
    
    consultants_coverage = db.execute_query(consultants_coverage_query, {"company_id": company_id})
    
    # Get field consultants covering this company
    field_consultants_coverage_query = """
    MATCH (fc:Field_Consultant)-[covers:COVERS]->(c:Company {id: $company_id})
    RETURN fc.id as id, fc.name as name, fc.specialization as specialization,
           fc.region as region, fc.rating as rating,
           covers.coverage_type as coverage_type, covers.contract_value as contract_value,
           covers.satisfaction_score as satisfaction_score, covers.status as status,
           covers.start_date as start_date, covers.end_date as end_date
    """
    
    field_consultants_coverage = db.execute_query(field_consultants_coverage_query, {"company_id": company_id})
    
    # Get employees (EMPLOYS relationship)
    employees_query = """
    MATCH (c:Company {id: $company_id})-[emp:EMPLOYS]->(person)
    RETURN person.id as id, person.name as name, labels(person) as type,
           emp.position as position, emp.department as department,
           emp.employment_type as employment_type, emp.salary_band as salary_band,
           emp.performance_rating as performance_rating,
           emp.start_date as start_date, emp.end_date as end_date
    """
    
    employees = db.execute_query(employees_query, {"company_id": company_id})
    
    # Get products owned (OWNS relationship)
    products_query = """
    MATCH (c:Company {id: $company_id})-[owns:OWNS]->(p:Product)
    RETURN p.id as id, p.name as name, p.category as category,
           p.vendor as vendor, p.price_range as price_range,
           owns.license_type as license_type, owns.license_count as license_count,
           owns.annual_cost as annual_cost, owns.usage_level as usage_level,
           owns.satisfaction_score as satisfaction_score,
           owns.acquisition_date as acquisition_date, owns.renewal_date as renewal_date
    """
    
    products = db.execute_query(products_query, {"company_id": company_id})
    
    return {
        "company": company,
        "consultants_coverage": consultants_coverage,
        "field_consultants_coverage": field_consultants_coverage,
        "employees": employees,
        "products_owned": products
    }

# ===== CONSULTANTS API =====

@app.get("/api/consultants")
async def get_consultants(
    expertise: Optional[str] = Query(None, description="Filter by expertise area (Strategy, Technology, Operations, Finance)"),
    seniority: Optional[str] = Query(None, description="Filter by seniority (Junior, Senior, Principal, Partner)"),
    location: Optional[str] = Query(None, description="Filter by location"),
    availability: Optional[str] = Query(None, description="Filter by availability (Available, Busy, Unavailable)"),
    min_rate: Optional[int] = Query(None, description="Minimum hourly rate"),
    max_rate: Optional[int] = Query(None, description="Maximum hourly rate"),
    min_experience: Optional[int] = Query(None, description="Minimum years of experience"),
    max_experience: Optional[int] = Query(None, description="Maximum years of experience"),
    min_rating: Optional[float] = Query(None, description="Minimum rating (1.0-5.0)"),
    education: Optional[str] = Query(None, description="Filter by education (MBA, PhD, etc.)"),
    limit: int = Query(50, description="Maximum number of results")
):
    """Get consultants with comprehensive filters"""
    
    query = "MATCH (cons:Consultant) WHERE 1=1"
    parameters = {"limit": limit}
    
    if expertise:
        query += " AND $expertise IN cons.expertise"
        parameters["expertise"] = expertise
    
    if seniority:
        query += " AND cons.seniority = $seniority"
        parameters["seniority"] = seniority
    
    if location:
        query += " AND cons.location CONTAINS $location"
        parameters["location"] = location
    
    if availability:
        query += " AND cons.availability = $availability"
        parameters["availability"] = availability
    
    if min_rate is not None:
        query += " AND cons.hourly_rate >= $min_rate"
        parameters["min_rate"] = min_rate
    
    if max_rate is not None:
        query += " AND cons.hourly_rate <= $max_rate"
        parameters["max_rate"] = max_rate
    
    if min_experience is not None:
        query += " AND cons.years_experience >= $min_experience"
        parameters["min_experience"] = min_experience
    
    if max_experience is not None:
        query += " AND cons.years_experience <= $max_experience"
        parameters["max_experience"] = max_experience
    
    if min_rating is not None:
        query += " AND cons.rating >= $min_rating"
        parameters["min_rating"] = min_rating
    
    if education:
        query += " AND cons.education CONTAINS $education"
        parameters["education"] = education
    
    query += """
    RETURN cons.id as id, cons.name as name, cons.expertise as expertise,
           cons.seniority as seniority, cons.years_experience as years_experience,
           cons.hourly_rate as hourly_rate, cons.location as location,
           cons.education as education, cons.rating as rating,
           cons.availability as availability, cons.specialization as specialization
    ORDER BY cons.rating DESC, cons.hourly_rate DESC
    LIMIT $limit
    """
    
    results = db.execute_query(query, parameters)
    return results

@app.get("/api/consultants/{consultant_id}")
async def get_consultant_details(consultant_id: str):
    """Get comprehensive consultant details with all relationships"""
    
    # Get consultant details
    consultant_query = """
    MATCH (cons:Consultant {id: $consultant_id})
    RETURN cons.id as id, cons.name as name, cons.expertise as expertise,
           cons.seniority as seniority, cons.years_experience as years_experience,
           cons.hourly_rate as hourly_rate, cons.location as location,
           cons.education as education, cons.rating as rating,
           cons.availability as availability, cons.specialization as specialization
    """
    
    consultant_result = db.execute_query(consultant_query, {"consultant_id": consultant_id})
    if not consultant_result:
        raise HTTPException(status_code=404, detail="Consultant not found")
    
    consultant = consultant_result[0]
    
    # Get companies they cover (COVERS relationship)
    companies_coverage_query = """
    MATCH (cons:Consultant {id: $consultant_id})-[covers:COVERS]->(c:Company)
    RETURN c.id as id, c.name as name, c.industry as industry, c.size as size,
           covers.coverage_type as coverage_type, covers.contract_value as contract_value,
           covers.satisfaction_score as satisfaction_score, covers.status as status,
           covers.start_date as start_date, covers.end_date as end_date
    """
    
    companies_coverage = db.execute_query(companies_coverage_query, {"consultant_id": consultant_id})
    
    # Get employment history (EMPLOYS relationship)
    employment_query = """
    MATCH (c:Company)-[emp:EMPLOYS]->(cons:Consultant {id: $consultant_id})
    RETURN c.id as company_id, c.name as company_name, c.industry as company_industry,
           emp.position as position, emp.department as department,
           emp.employment_type as employment_type, emp.salary_band as salary_band,
           emp.performance_rating as performance_rating,
           emp.start_date as start_date, emp.end_date as end_date
    """
    
    employment_history = db.execute_query(employment_query, {"consultant_id": consultant_id})
    
    # Get product ratings (RATES relationship)
    product_ratings_query = """
    MATCH (cons:Consultant {id: $consultant_id})-[rates:RATES]->(p:Product)
    RETURN p.id as product_id, p.name as product_name, p.category as category,
           rates.rating as rating, rates.review_date as review_date,
           rates.review_text as review_text, rates.recommendation_strength as recommendation_strength,
           rates.use_case as use_case, rates.experience_duration as experience_duration
    """
    
    product_ratings = db.execute_query(product_ratings_query, {"consultant_id": consultant_id})
    
    # Get product recommendations (RECOMMENDS relationship)
    product_recommendations_query = """
    MATCH (cons:Consultant {id: $consultant_id})-[rec:RECOMMENDS]->(p:Product)
    RETURN p.id as product_id, p.name as product_name, p.category as category,
           rec.recommendation_date as recommendation_date, rec.confidence_level as confidence_level,
           rec.use_case as use_case, rec.implementation_complexity as implementation_complexity,
           rec.expected_roi as expected_roi, rec.priority as priority, rec.status as status
    """
    
    product_recommendations = db.execute_query(product_recommendations_query, {"consultant_id": consultant_id})
    
    return {
        "consultant": consultant,
        "companies_coverage": companies_coverage,
        "employment_history": employment_history,
        "product_ratings": product_ratings,
        "product_recommendations": product_recommendations
    }

# ===== FIELD CONSULTANTS API =====

@app.get("/api/field-consultants")
async def get_field_consultants(
    specialization: Optional[str] = Query(None, description="Filter by specialization (Implementation, Training, Support)"),
    region: Optional[str] = Query(None, description="Filter by region (West Coast, East Coast, Midwest)"),
    certification_level: Optional[str] = Query(None, description="Filter by certification (Certified, Expert, Master)"),
    availability: Optional[str] = Query(None, description="Filter by availability (Available, Busy, Unavailable)"),
    travel_willingness: Optional[bool] = Query(None, description="Filter by travel willingness"),
    min_rate: Optional[int] = Query(None, description="Minimum hourly rate"),
    max_rate: Optional[int] = Query(None, description="Maximum hourly rate"),
    min_experience: Optional[int] = Query(None, description="Minimum years of experience"),
    language: Optional[str] = Query(None, description="Filter by language capability"),
    min_rating: Optional[float] = Query(None, description="Minimum rating (1.0-5.0)"),
    limit: int = Query(50, description="Maximum number of results")
):
    """Get field consultants with comprehensive filters"""
    
    query = "MATCH (fc:Field_Consultant) WHERE 1=1"
    parameters = {"limit": limit}
    
    if specialization:
        query += " AND $specialization IN fc.specialization"
        parameters["specialization"] = specialization
    
    if region:
        query += " AND fc.region = $region"
        parameters["region"] = region
    
    if certification_level:
        query += " AND fc.certification_level = $certification_level"
        parameters["certification_level"] = certification_level
    
    if availability:
        query += " AND fc.availability = $availability"
        parameters["availability"] = availability
    
    if travel_willingness is not None:
        query += " AND fc.travel_willingness = $travel_willingness"
        parameters["travel_willingness"] = travel_willingness
    
    if min_rate is not None:
        query += " AND fc.hourly_rate >= $min_rate"
        parameters["min_rate"] = min_rate
    
    if max_rate is not None:
        query += " AND fc.hourly_rate <= $max_rate"
        parameters["max_rate"] = max_rate
    
    if min_experience is not None:
        query += " AND fc.years_experience >= $min_experience"
        parameters["min_experience"] = min_experience
    
    if language:
        query += " AND $language IN fc.languages"
        parameters["language"] = language
    
    if min_rating is not None:
        query += " AND fc.rating >= $min_rating"
        parameters["min_rating"] = min_rating
    
    query += """
    RETURN fc.id as id, fc.name as name, fc.specialization as specialization,
           fc.region as region, fc.years_experience as years_experience,
           fc.certification_level as certification_level, fc.hourly_rate as hourly_rate,
           fc.languages as languages, fc.rating as rating,
           fc.availability as availability, fc.travel_willingness as travel_willingness
    ORDER BY fc.rating DESC, fc.hourly_rate DESC
    LIMIT $limit
    """
    
    results = db.execute_query(query, parameters)
    return results

@app.get("/api/field-consultants/{field_consultant_id}")
async def get_field_consultant_details(field_consultant_id: str):
    """Get comprehensive field consultant details with all relationships"""
    
    # Get field consultant details
    fc_query = """
    MATCH (fc:Field_Consultant {id: $field_consultant_id})
    RETURN fc.id as id, fc.name as name, fc.specialization as specialization,
           fc.region as region, fc.years_experience as years_experience,
           fc.certification_level as certification_level, fc.hourly_rate as hourly_rate,
           fc.languages as languages, fc.rating as rating,
           fc.availability as availability, fc.travel_willingness as travel_willingness
    """
    
    fc_result = db.execute_query(fc_query, {"field_consultant_id": field_consultant_id})
    if not fc_result:
        raise HTTPException(status_code=404, detail="Field consultant not found")
    
    field_consultant = fc_result[0]
    
    # Get companies they cover
    companies_coverage_query = """
    MATCH (fc:Field_Consultant {id: $field_consultant_id})-[covers:COVERS]->(c:Company)
    RETURN c.id as id, c.name as name, c.industry as industry, c.size as size,
           covers.coverage_type as coverage_type, covers.contract_value as contract_value,
           covers.satisfaction_score as satisfaction_score, covers.status as status,
           covers.start_date as start_date, covers.end_date as end_date
    """
    
    companies_coverage = db.execute_query(companies_coverage_query, {"field_consultant_id": field_consultant_id})
    
    # Get employment history
    employment_query = """
    MATCH (c:Company)-[emp:EMPLOYS]->(fc:Field_Consultant {id: $field_consultant_id})
    RETURN c.id as company_id, c.name as company_name, c.industry as company_industry,
           emp.position as position, emp.department as department,
           emp.employment_type as employment_type, emp.salary_band as salary_band,
           emp.performance_rating as performance_rating,
           emp.start_date as start_date, emp.end_date as end_date
    """
    
    employment_history = db.execute_query(employment_query, {"field_consultant_id": field_consultant_id})
    
    # Get product ratings
    product_ratings_query = """
    MATCH (fc:Field_Consultant {id: $field_consultant_id})-[rates:RATES]->(p:Product)
    RETURN p.id as product_id, p.name as product_name, p.category as category,
           rates.rating as rating, rates.review_date as review_date,
           rates.review_text as review_text, rates.recommendation_strength as recommendation_strength,
           rates.use_case as use_case, rates.experience_duration as experience_duration
    """
    
    product_ratings = db.execute_query(product_ratings_query, {"field_consultant_id": field_consultant_id})
    
    # Get product recommendations
    product_recommendations_query = """
    MATCH (fc:Field_Consultant {id: $field_consultant_id})-[rec:RECOMMENDS]->(p:Product)
    RETURN p.id as product_id, p.name as product_name, p.category as category,
           rec.recommendation_date as recommendation_date, rec.confidence_level as confidence_level,
           rec.use_case as use_case, rec.implementation_complexity as implementation_complexity,
           rec.expected_roi as expected_roi, rec.priority as priority, rec.status as status
    """
    
    product_recommendations = db.execute_query(product_recommendations_query, {"field_consultant_id": field_consultant_id})
    
    return {
        "field_consultant": field_consultant,
        "companies_coverage": companies_coverage,
        "employment_history": employment_history,
        "product_ratings": product_ratings,
        "product_recommendations": product_recommendations
    }

# ===== PRODUCTS API =====

@app.get("/api/products")
async def get_products(
    category: Optional[str] = Query(None, description="Filter by category (Software, Hardware, Service, Platform)"),
    vendor: Optional[str] = Query(None, description="Filter by vendor"),
    price_range: Optional[str] = Query(None, description="Filter by price range (Free, <$1K, $1K-$10K, $10K+)"),
    target_market: Optional[str] = Query(None, description="Filter by target market (Startup, SME, Enterprise)"),
    deployment_type: Optional[str] = Query(None, description="Filter by deployment (Cloud, On-Premise, Hybrid)"),
    industry_focus: Optional[str] = Query(None, description="Filter by industry focus"),
    maturity: Optional[str] = Query(None, description="Filter by maturity (Beta, Stable, Legacy)"),
    min_rating: Optional[float] = Query(None, description="Minimum rating (1.0-5.0)"),
    launched_after: Optional[str] = Query(None, description="Launched after date (YYYY-MM-DD)"),
    launched_before: Optional[str] = Query(None, description="Launched before date (YYYY-MM-DD)"),
    limit: int = Query(50, description="Maximum number of results")
):
    """Get products with comprehensive filters"""
    
    query = "MATCH (p:Product) WHERE 1=1"
    parameters = {"limit": limit}
    
    if category:
        query += " AND p.category = $category"
        parameters["category"] = category
    
    if vendor:
        query += " AND p.vendor CONTAINS $vendor"
        parameters["vendor"] = vendor
    
    if price_range:
        query += " AND p.price_range = $price_range"
        parameters["price_range"] = price_range
    
    if target_market:
        query += " AND p.target_market = $target_market"
        parameters["target_market"] = target_market
    
    if deployment_type:
        query += " AND p.deployment_type = $deployment_type"
        parameters["deployment_type"] = deployment_type
    
    if industry_focus:
        query += " AND $industry_focus IN p.industry_focus"
        parameters["industry_focus"] = industry_focus
    
    if maturity:
        query += " AND p.maturity = $maturity"
        parameters["maturity"] = maturity
    
    if min_rating is not None:
        query += " AND p.rating >= $min_rating"
        parameters["min_rating"] = min_rating
    
    if launched_after:
        query += " AND p.launch_date >= date($launched_after)"
        parameters["launched_after"] = launched_after
    
    if launched_before:
        query += " AND p.launch_date <= date($launched_before)"
        parameters["launched_before"] = launched_before
    
    query += """
    RETURN p.id as id, p.name as name, p.category as category,
           p.vendor as vendor, p.price_range as price_range,
           p.target_market as target_market, p.deployment_type as deployment_type,
           p.industry_focus as industry_focus, p.maturity as maturity,
           p.rating as rating, p.launch_date as launch_date
    ORDER BY p.rating DESC, p.launch_date DESC
    LIMIT $limit
    """
    
    results = db.execute_query(query, parameters)
    return results

@app.get("/api/products/{product_id}")
async def get_product_details(product_id: str):
    """Get comprehensive product details with all relationships"""
    
    # Get product details
    product_query = """
    MATCH (p:Product {id: $product_id})
    RETURN p.id as id, p.name as name, p.category as category,
           p.vendor as vendor, p.price_range as price_range,
           p.target_market as target_market, p.deployment_type as deployment_type,
           p.industry_focus as industry_focus, p.maturity as maturity,
           p.rating as rating, p.launch_date as launch_date
    """
    
    product_result = db.execute_query(product_query, {"product_id": product_id})
    if not product_result:
        raise HTTPException(status_code=404, detail="Product not found")
    
    product = product_result[0]
    
    # Get companies that own this product
    companies_owners_query = """
    MATCH (c:Company)-[owns:OWNS]->(p:Product {id: $product_id})
    RETURN c.id as company_id, c.name as company_name, c.industry as industry, c.size as size,
           owns.license_type as license_type, owns.license_count as license_count,
           owns.annual_cost as annual_cost, owns.usage_level as usage_level,
           owns.satisfaction_score as satisfaction_score,
           owns.acquisition_date as acquisition_date, owns.renewal_date as renewal_date
    """
    
    companies_owners = db.execute_query(companies_owners_query, {"product_id": product_id})
    
    # Get ratings from consultants and field consultants
    ratings_query = """
    MATCH (person)-[rates:RATES]->(p:Product {id: $product_id})
    RETURN person.id as rater_id, person.name as rater_name, labels(person) as rater_type,
           rates.rating as rating, rates.review_date as review_date,
           rates.review_text as review_text, rates.recommendation_strength as recommendation_strength,
           rates.use_case as use_case, rates.experience_duration as experience_duration
    ORDER BY rates.review_date DESC
    """
    
    ratings = db.execute_query(ratings_query, {"product_id": product_id})
    
    # Get recommendations
    recommendations_query = """
    MATCH (person)-[rec:RECOMMENDS]->(p:Product {id: $product_id})
    RETURN person.id as recommender_id, person.name as recommender_name, labels(person) as recommender_type,
           rec.recommendation_date as recommendation_date, rec.confidence_level as confidence_level,
           rec.use_case as use_case, rec.implementation_complexity as implementation_complexity,
           rec.expected_roi as expected_roi, rec.priority as priority, rec.status as status
    ORDER BY rec.recommendation_date DESC
    """
    
    recommendations = db.execute_query(recommendations_query, {"product_id": product_id})
    
    return {
        "product": product,
        "companies_owners": companies_owners,
        "ratings": ratings,
        "recommendations": recommendations
    }

# ===== ANALYTICS & INSIGHTS API =====

@app.get("/api/analytics/dashboard")
async def get_dashboard_analytics():
    """Get comprehensive dashboard analytics for the consulting business"""
    
    # Get node counts
    counts = {}
    
    # Count companies
    companies_result = db.execute_query("MATCH (c:Company) RETURN count(c) as count")
    counts['companies'] = companies_result[0]['count'] if companies_result else 0
    
    # Count consultants
    consultants_result = db.execute_query("MATCH (cons:Consultant) RETURN count(cons) as count")
    counts['consultants'] = consultants_result[0]['count'] if consultants_result else 0
    
    # Count field consultants
    field_consultants_result = db.execute_query("MATCH (fc:Field_Consultant) RETURN count(fc) as count")
    counts['field_consultants'] = field_consultants_result[0]['count'] if field_consultants_result else 0
    
    # Count products
    products_result = db.execute_query("MATCH (p:Product) RETURN count(p) as count")
    counts['products'] = products_result[0]['count'] if products_result else 0
    
    # Revenue analytics
    revenue_query = """
    MATCH (c:Company)
    RETURN 
      sum(c.revenue) as total_revenue,
      avg(c.revenue) as avg_revenue,
      max(c.revenue) as max_revenue,
      min(c.revenue) as min_revenue,
      count(c) as company_count
    """
    
    revenue_result = db.execute_query(revenue_query)
    revenue = revenue_result[0] if revenue_result else {}
    
    # Contract analytics
    contract_query = """
    MATCH ()-[covers:COVERS]->()
    RETURN 
      sum(covers.contract_value) as total_contract_value,
      avg(covers.contract_value) as avg_contract_value,
      max(covers.contract_value) as max_contract_value,
      count(covers) as active_contracts,
      avg(covers.satisfaction_score) as avg_satisfaction
    """
    
    contract_result = db.execute_query(contract_query)
    contracts = contract_result[0] if contract_result else {}
    
    # Industry breakdown
    industry_query = """
    MATCH (c:Company)
    RETURN c.industry as industry, count(c) as count, sum(c.revenue) as total_revenue
    ORDER BY count DESC
    """
    
    industries = db.execute_query(industry_query)
    
    # Top consultants by contract value
    top_consultants_query = """
    MATCH (cons:Consultant)-[covers:COVERS]->(c:Company)
    RETURN cons.name as name, cons.seniority as seniority,
           sum(covers.contract_value) as total_contracts,
           avg(covers.satisfaction_score) as avg_satisfaction,
           count(covers) as project_count
    ORDER BY total_contracts DESC
    LIMIT 10
    """
    
    top_consultants = db.execute_query(top_consultants_query)
    
    # Consultant utilization by seniority
    seniority_analytics_query = """
    MATCH (cons:Consultant)
    OPTIONAL MATCH (cons)-[covers:COVERS]->(c:Company)
    RETURN cons.seniority as seniority,
           count(DISTINCT cons) as consultant_count,
           count(covers) as total_projects,
           avg(cons.hourly_rate) as avg_hourly_rate,
           avg(cons.rating) as avg_rating
    ORDER BY avg_hourly_rate DESC
    """
    
    seniority_analytics = db.execute_query(seniority_analytics_query)
    
    # Product adoption analytics
    product_adoption_query = """
    MATCH (p:Product)
    OPTIONAL MATCH (c:Company)-[owns:OWNS]->(p)
    RETURN p.category as category,
           count(DISTINCT p) as product_count,
           count(owns) as total_adoptions,
           avg(p.rating) as avg_rating,
           sum(owns.annual_cost) as total_annual_revenue
    ORDER BY total_adoptions DESC
    """
    
    product_adoption = db.execute_query(product_adoption_query)
    
    return {
        "counts": counts,
        "revenue": revenue,
        "contracts": contracts,
        "industries": industries,
        "top_consultants": top_consultants,
        "seniority_analytics": seniority_analytics,
        "product_adoption": product_adoption
    }

@app.get("/api/analytics/relationships")
async def get_relationship_analytics():
    """Get detailed analytics about business relationships"""
    
    # Coverage relationship analytics
    coverage_analytics_query = """
    MATCH (person)-[covers:COVERS]->(comp:Company)
    RETURN 
      labels(person)[0] as consultant_type,
      covers.coverage_type as coverage_type,
      comp.industry as industry,
      count(*) as relationship_count,
      avg(covers.contract_value) as avg_contract_value,
      avg(covers.satisfaction_score) as avg_satisfaction,
      sum(covers.contract_value) as total_contract_value
    ORDER BY total_contract_value DESC
    """
    
    coverage_analytics = db.execute_query(coverage_analytics_query)
    
    # Employment relationship analytics
    employment_analytics_query = """
    MATCH (c:Company)-[emp:EMPLOYS]->(person)
    RETURN 
      c.industry as industry,
      emp.employment_type as employment_type,
      emp.salary_band as salary_band,
      labels(person)[0] as employee_type,
      count(*) as employment_count,
      avg(emp.performance_rating) as avg_performance
    ORDER BY employment_count DESC
    """
    
    employment_analytics = db.execute_query(employment_analytics_query)
    
    # Product ownership analytics
    ownership_analytics_query = """
    MATCH (c:Company)-[owns:OWNS]->(p:Product)
    RETURN 
      p.category as product_category,
      p.target_market as target_market,
      c.industry as company_industry,
      count(*) as adoption_count,
      avg(owns.annual_cost) as avg_annual_cost,
      avg(owns.satisfaction_score) as avg_satisfaction,
      sum(owns.annual_cost) as total_revenue
    ORDER BY adoption_count DESC
    """
    
    ownership_analytics = db.execute_query(ownership_analytics_query)
    
    # Product ratings and recommendations analytics
    product_feedback_query = """
    MATCH (p:Product)
    OPTIONAL MATCH (person)-[rates:RATES]->(p)
    OPTIONAL MATCH (person2)-[rec:RECOMMENDS]->(p)
    RETURN 
      p.name as product_name,
      p.category as category,
      count(DISTINCT rates) as rating_count,
      avg(rates.rating) as avg_user_rating,
      count(DISTINCT rec) as recommendation_count,
      count(DISTINCT CASE WHEN rec.confidence_level = 'High' THEN rec END) as high_confidence_recommendations
    ORDER BY rating_count DESC
    """
    
    product_feedback = db.execute_query(product_feedback_query)
    
    return {
        "coverage_analytics": coverage_analytics,
        "employment_analytics": employment_analytics,
        "ownership_analytics": ownership_analytics,
        "product_feedback": product_feedback
    }

@app.get("/api/analytics/business-insights")
async def get_business_insights():
    """Get strategic business insights and KPIs"""
    
    # Most successful consultant-company pairings
    successful_pairings_query = """
    MATCH (cons:Consultant)-[covers:COVERS]->(comp:Company)
    WHERE covers.satisfaction_score >= 4.5
    RETURN cons.name as consultant, comp.name as company, comp.industry as industry,
           covers.satisfaction_score as satisfaction, covers.contract_value as contract_value,
           covers.coverage_type as coverage_type
    ORDER BY covers.satisfaction_score DESC, covers.contract_value DESC
    LIMIT 10
    """
    
    successful_pairings = db.execute_query(successful_pairings_query)
    
    # Expertise demand analysis
    expertise_demand_query = """
    MATCH (cons:Consultant)-[covers:COVERS]->(comp:Company)
    UNWIND cons.expertise as expertise_area
    RETURN expertise_area,
           count(*) as project_count,
           avg(covers.contract_value) as avg_contract_value,
           avg(covers.satisfaction_score) as avg_satisfaction,
           collect(DISTINCT comp.industry) as industries_served
    ORDER BY project_count DESC
    """
    
    expertise_demand = db.execute_query(expertise_demand_query)
    
    # Regional analysis
    regional_analysis_query = """
    MATCH (cons:Consultant)-[covers:COVERS]->(comp:Company)
    RETURN cons.location as consultant_location, comp.location as company_location,
           count(*) as collaboration_count,
           avg(covers.contract_value) as avg_contract_value,
           avg(covers.satisfaction_score) as avg_satisfaction
    ORDER BY collaboration_count DESC
    LIMIT 15
    """
    
    regional_analysis = db.execute_query(regional_analysis_query)
    
    # Product ROI analysis
    product_roi_query = """
    MATCH (person)-[rec:RECOMMENDS]->(p:Product)
    WHERE rec.expected_roi IS NOT NULL
    RETURN p.name as product_name, p.category as category,
           rec.expected_roi as expected_roi,
           count(*) as recommendation_count,
           avg(CASE WHEN rec.status = 'Implemented' THEN 1.0 ELSE 0.0 END) as implementation_rate
    ORDER BY recommendation_count DESC
    """
    
    product_roi = db.execute_query(product_roi_query)
    
    return {
        "successful_pairings": successful_pairings,
        "expertise_demand": expertise_demand,
        "regional_analysis": regional_analysis,
        "product_roi": product_roi
    }

# ===== FILTER OPTIONS API =====

@app.get("/api/filters/industries")
async def get_industries():
    """Get all unique industries"""
    query = "MATCH (c:Company) RETURN DISTINCT c.industry as industry ORDER BY industry"
    results = db.execute_query(query)
    return [r["industry"] for r in results if r["industry"]]

@app.get("/api/filters/locations")
async def get_locations():
    """Get all unique locations"""
    query = """
    MATCH (c:Company) RETURN DISTINCT c.location as location
    UNION
    MATCH (cons:Consultant) RETURN DISTINCT cons.location as location
    ORDER BY location
    """
    results = db.execute_query(query)
    return [r["location"] for r in results if r["location"]]

@app.get("/api/filters/expertise")
async def get_expertise_areas():
    """Get all unique expertise areas"""
    query = """
    MATCH (cons:Consultant)
    UNWIND cons.expertise as expertise
    RETURN DISTINCT expertise
    ORDER BY expertise
    """
    results = db.execute_query(query)
    return [r["expertise"] for r in results if r["expertise"]]

@app.get("/api/filters/specializations")
async def get_specializations():
    """Get all unique field consultant specializations"""
    query = """
    MATCH (fc:Field_Consultant)
    UNWIND fc.specialization as specialization
    RETURN DISTINCT specialization
    ORDER BY specialization
    """
    results = db.execute_query(query)
    return [r["specialization"] for r in results if r["specialization"]]

@app.get("/api/filters/product-categories")
async def get_product_categories():
    """Get all unique product categories"""
    query = "MATCH (p:Product) RETURN DISTINCT p.category as category ORDER BY category"
    results = db.execute_query(query)
    return [r["category"] for r in results if r["category"]]

@app.get("/api/filters/company-sizes")
async def get_company_sizes():
    """Get all unique company sizes"""
    query = "MATCH (c:Company) RETURN DISTINCT c.size as size ORDER BY size"
    results = db.execute_query(query)
    return [r["size"] for r in results if r["size"]]

@app.get("/api/filters/seniority-levels")
async def get_seniority_levels():
    """Get all unique consultant seniority levels"""
    query = "MATCH (cons:Consultant) RETURN DISTINCT cons.seniority as seniority ORDER BY seniority"
    results = db.execute_query(query)
    return [r["seniority"] for r in results if r["seniority"]]

@app.get("/api/filters/regions")
async def get_regions():
    """Get all unique field consultant regions"""
    query = "MATCH (fc:Field_Consultant) RETURN DISTINCT fc.region as region ORDER BY region"
    results = db.execute_query(query)
    return [r["region"] for r in results if r["region"]]

@app.get("/api/filters/languages")
async def get_languages():
    """Get all unique languages spoken by field consultants"""
    query = """
    MATCH (fc:Field_Consultant)
    UNWIND fc.languages as language
    RETURN DISTINCT language
    ORDER BY language
    """
    results = db.execute_query(query)
    return [r["language"] for r in results if r["language"]]

# ===== BUSINESS QUERIES API =====

@app.get("/api/business/top-performers")
async def get_top_performers(
    metric: str = Query("satisfaction", description="Metric to rank by (satisfaction, revenue, projects)"),
    limit: int = Query(10, description="Number of results")
):
    """Get top performing consultants based on various metrics"""
    
    if metric == "satisfaction":
        query = """
        MATCH (cons:Consultant)-[covers:COVERS]->(comp:Company)
        RETURN cons.name as name, cons.seniority as seniority,
               avg(covers.satisfaction_score) as avg_satisfaction,
               count(covers) as project_count,
               sum(covers.contract_value) as total_revenue
        ORDER BY avg_satisfaction DESC, project_count DESC
        LIMIT $limit
        """
    elif metric == "revenue":
        query = """
        MATCH (cons:Consultant)-[covers:COVERS]->(comp:Company)
        RETURN cons.name as name, cons.seniority as seniority,
               sum(covers.contract_value) as total_revenue,
               count(covers) as project_count,
               avg(covers.satisfaction_score) as avg_satisfaction
        ORDER BY total_revenue DESC
        LIMIT $limit
        """
    elif metric == "projects":
        query = """
        MATCH (cons:Consultant)-[covers:COVERS]->(comp:Company)
        RETURN cons.name as name, cons.seniority as seniority,
               count(covers) as project_count,
               sum(covers.contract_value) as total_revenue,
               avg(covers.satisfaction_score) as avg_satisfaction
        ORDER BY project_count DESC
        LIMIT $limit
        """
    else:
        raise HTTPException(status_code=400, detail="Invalid metric. Use: satisfaction, revenue, or projects")
    
    results = db.execute_query(query, {"limit": limit})
    return results

@app.get("/api/business/recommendations")
async def get_business_recommendations(
    company_id: Optional[str] = Query(None, description="Company ID for specific recommendations"),
    industry: Optional[str] = Query(None, description="Industry for recommendations")
):
    """Get business recommendations for consultants and products"""
    
    if company_id:
        # Recommendations for specific company
        query = """
        MATCH (c:Company {id: $company_id})
        
        // Find consultants with expertise matching company industry
        OPTIONAL MATCH (cons:Consultant)
        WHERE c.industry IN cons.expertise AND cons.availability = 'Available'
        
        // Find products targeting company's market segment
        OPTIONAL MATCH (p:Product)
        WHERE c.size = p.target_market AND c.industry IN p.industry_focus
        
        RETURN {
            company: {id: c.id, name: c.name, industry: c.industry, size: c.size},
            recommended_consultants: collect(DISTINCT {
                id: cons.id, name: cons.name, expertise: cons.expertise, 
                seniority: cons.seniority, rating: cons.rating
            })[0..5],
            recommended_products: collect(DISTINCT {
                id: p.id, name: p.name, category: p.category, rating: p.rating
            })[0..5]
        } as recommendations
        """
        results = db.execute_query(query, {"company_id": company_id})
    
    elif industry:
        # Recommendations for industry
        query = """
        MATCH (c:Company {industry: $industry})
        
        // Top consultants for this industry
        OPTIONAL MATCH (cons:Consultant)-[covers:COVERS]->(comp:Company {industry: $industry})
        
        // Top products for this industry
        OPTIONAL MATCH (p:Product)
        WHERE $industry IN p.industry_focus
        
        RETURN {
            industry: $industry,
            top_consultants: collect(DISTINCT {
                name: cons.name, expertise: cons.expertise,
                avg_satisfaction: avg(covers.satisfaction_score),
                project_count: count(covers)
            })[0..10],
            recommended_products: collect(DISTINCT {
                id: p.id, name: p.name, category: p.category, rating: p.rating
            })[0..10]
        } as recommendations
        """
        results = db.execute_query(query, {"industry": industry})
    
    else:
        raise HTTPException(status_code=400, detail="Provide either company_id or industry")
    
    return results[0] if results else {}

# ===== HEALTH CHECK =====

@app.get("/health")
async def health_check():
    try:
        # Test basic connection
        test_result = db.execute_query("RETURN 1 as test")
        if not test_result:
            raise Exception("Cannot execute basic query")
        
        # Get node counts
        counts = {}
        
        try:
            companies_result = db.execute_query("MATCH (c:Company) RETURN count(c) as count")
            counts['companies'] = companies_result[0]['count'] if companies_result else 0
        except:
            counts['companies'] = 0
            
        try:
            consultants_result = db.execute_query("MATCH (cons:Consultant) RETURN count(cons) as count")
            counts['consultants'] = consultants_result[0]['count'] if consultants_result else 0
        except:
            counts['consultants'] = 0
            
        try:
            field_consultants_result = db.execute_query("MATCH (fc:Field_Consultant) RETURN count(fc) as count")
            counts['field_consultants'] = field_consultants_result[0]['count'] if field_consultants_result else 0
        except:
            counts['field_consultants'] = 0
            
        try:
            products_result = db.execute_query("MATCH (p:Product) RETURN count(p) as count")
            counts['products'] = products_result[0]['count'] if products_result else 0
        except:
            counts['products'] = 0
        
        # Check relationships
        relationships = {}
        rel_types = ["COVERS", "EMPLOYS", "OWNS", "RATES", "RECOMMENDS"]
        
        for rel_type in rel_types:
            try:
                result = db.execute_query(f"MATCH ()-[r:{rel_type}]->() RETURN count(r) as count")
                relationships[rel_type] = result[0]['count'] if result else 0
            except:
                relationships[rel_type] = 0
        
        return {
            "status": "healthy", 
            "database": "connected",
            "database_name": db.database,
            "node_counts": counts,
            "relationship_counts": relationships,
            "total_nodes": sum(counts.values()),
            "total_relationships": sum(relationships.values())
        }
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Database connection failed: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)