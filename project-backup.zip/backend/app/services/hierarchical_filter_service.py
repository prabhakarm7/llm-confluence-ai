"""
Hierarchical Filter Population Process Based on Region
Implementation following the exact workflow from your summary document.
"""
import time
from typing import Dict, List, Any, Optional
from neo4j import GraphDatabase, Session
from neo4j.exceptions import Neo4jError

from app.config import (
    NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD, NEO4J_DATABASE, REGIONS
)


class HierarchicalFilterService:
    """Service implementing hierarchical filter population based on region selection."""
    
    def __init__(self):
        """Initialize the service with Neo4j connection."""
        self.driver = GraphDatabase.driver(
            NEO4J_URI,
            auth=(NEO4J_USERNAME, NEO4J_PASSWORD),
            database=NEO4J_DATABASE
        )
    
    def close(self):
        """Close the database connection."""
        if self.driver:
            self.driver.close()
    
    def health_check(self) -> bool:
        """Check if database connection is healthy."""
        try:
            with self.driver.session() as session:
                result = session.run("RETURN 1 as test")
                return result.single()["test"] == 1
        except Exception:
            return False
    
    def get_region_data(self, region: str) -> Dict[str, Any]:
        """
        Step 1: Initial Region Selection
        Get ALL nodes and relationships for the specified region using your complex query logic.
        FIXED: Based on your data structure where consultants go through field consultants.
        """
        region = region.upper()
        
        try:
            # Define your complex query statements - exactly as they were
            fc_opening_statement = """
            Optional match (a:CONSULTANT)-[f:EMPLOYS]->(b:FIELD_CONSULTANT)
            Optional match (b:FIELD_CONSULTANT)-[i:COVERS]->(c:COMPANY)
            Optional match (c:COMPANY)-[g:OWNS]->(d:PRODUCT)
            Optional match (a:CONSULTANT)-[j:RATES]->(d:PRODUCT)
            with a,b,c,d,f,g,i,j
            """
            
            fc_collection_statement = """
            WITH COLLECT(DISTINCT a) + COLLECT(DISTINCT b) + COLLECT(DISTINCT c) + COLLECT(DISTINCT d) AS allNodes,
            COLLECT(DISTINCT f) + COLLECT(DISTINCT g) + COLLECT(DISTINCT i) + COLLECT(DISTINCT j) AS allRels
            """
            
            fc_reverse_opening_statement = """
            Optional match (d:PRODUCT)<-[g:OWNS]-(c:COMPANY)
            Optional match (c:COMPANY)<-[i:COVERS]-(b:FIELD_CONSULTANT)
            Optional match (b:FIELD_CONSULTANT)<-[f:EMPLOYS]-(a:CONSULTANT)
            Optional match (a:CONSULTANT)-[j:RATES]->(d:PRODUCT)
            with a,b,c,d,f,g,i,j
            """
            
            fc_reverse_collection_statement = """
            WITH COLLECT(DISTINCT a) + COLLECT(DISTINCT b) + COLLECT(DISTINCT c) + COLLECT(DISTINCT d) AS allNodes,
            COLLECT(DISTINCT f) + COLLECT(DISTINCT g) + COLLECT(DISTINCT i) + COLLECT(DISTINCT j) AS allRels
            """
            
            no_fc_opening_statement = """
            Optional match (a:CONSULTANT)-[j:RATES]->(d:PRODUCT)
            Optional match (d:PRODUCT)<-[g:OWNS]-(c:COMPANY)
            with a,c,d,g,j
            """
            
            no_fc_collection_statement = """
            WITH COLLECT(DISTINCT a) + COLLECT(DISTINCT c) + COLLECT(DISTINCT d) AS allNodes,
            COLLECT(DISTINCT g) + COLLECT(DISTINCT j) AS allRels
            """
            
            no_fc_reverse_opening_statement = """
            Optional match (c:COMPANY)-[g:OWNS]->(d:PRODUCT)
            with c,d,g
            """
            
            no_fc_reverse_collection_statement = """
            WITH COLLECT(DISTINCT c) + COLLECT(DISTINCT d) AS allNodes,
            COLLECT(DISTINCT g) AS allRels
            """
            
            with self.driver.session() as session:
                print(f"Step 1: Getting all data for region {region}")
                
                # Execute all query variations as per your original logic
                query_1 = self.create_query_working(fc_opening_statement, fc_collection_statement, has_field_consultant=True)
                query_2 = self.create_query_working(fc_reverse_opening_statement, fc_reverse_collection_statement, has_field_consultant=True)
                query_3 = self.create_query_working(no_fc_opening_statement, no_fc_collection_statement, has_field_consultant=False)
                query_4 = self.create_query_working(no_fc_reverse_opening_statement, no_fc_reverse_collection_statement, has_field_consultant=False)
                
                print(f"Executing Query 1 (FC Main): {query_1[:200]}...")
                result_1 = self.execute_single_query(session, query_1, {"region": region})
                print(f"Query 1 returned {len(result_1.get('nodes', []))} nodes, {len(result_1.get('edges', []))} edges")
                
                print(f"Executing Query 2 (Reverse): {query_2[:200]}...")
                result_2 = self.execute_single_query(session, query_2, {"region": region})
                print(f"Query 2 returned {len(result_2.get('nodes', []))} nodes, {len(result_2.get('edges', []))} edges")
                
                print(f"Executing Query 3 (Direct Rating): {query_3[:200]}...")
                result_3 = self.execute_single_query(session, query_3, {"region": region})
                print(f"Query 3 returned {len(result_3.get('nodes', []))} nodes, {len(result_3.get('edges', []))} edges")
                
                print(f"Executing Query 4 (Company-Product): {query_4[:200]}...")
                result_4 = self.execute_single_query(session, query_4, {"region": region})
                print(f"Query 4 returned {len(result_4.get('nodes', []))} nodes, {len(result_4.get('edges', []))} edges")
                
                # Union all results
                final_result = self.union_query_results(result_1, result_2, result_3, result_4)
                print(f"Final union result: {len(final_result.get('nodes', []))} nodes, {len(final_result.get('edges', []))} edges")
                
                # Convert to expected format (same as before)
                nodes = []
                relationships = []
                
                # Process nodes
                for node_data in final_result.get('nodes', []):
                    if 'data' in node_data:
                        data = node_data['data']
                        nodes.append({
                            "id": str(data.get('node_name', data.get('id', ''))),
                            "labels": [data.get('label', 'UNKNOWN')],
                            "properties": {k: v for k, v in data.items() if k not in ['node_name', 'id', 'label']}
                        })
                
                # Process relationships
                for rel_data in final_result.get('edges', []):
                    if 'data' in rel_data:
                        data = rel_data['data']
                        relationships.append({
                            "id": str(data.get('id', '')),
                            "type": data.get('label', 'UNKNOWN'),
                            "start_node_id": str(data.get('source', '')),
                            "end_node_id": str(data.get('target', '')),
                            "properties": {k: v for k, v in data.items() if k not in ['id', 'label', 'source', 'target']}
                        })
                
                return {
                    "nodes": nodes,
                    "relationships": relationships,
                    "metadata": {
                        "region": region,
                        "node_count": len(nodes),
                        "relationship_count": len(relationships),
                        "timestamp": time.time(),
                        "query_type": "fixed_complex_union",
                        "queries_executed": 4
                    }
                }
                
        except Exception as e:
            raise Exception(f"Failed to get region data using complex query for {region}: {str(e)}")
    
    def test_simple_query(self, region: str) -> Dict[str, Any]:
        """Test with a very simple query to see if we can get any data."""
        try:
            with self.driver.session() as session:
                query = self.create_simple_test_query(region)
                print(f"Testing simple query: {query[:200]}...")
                
                result = session.run(query)
                records = list(result)
                
                if records and 'Relationships' in records[0]:
                    data = records[0]['Relationships']
                    print(f"Simple query returned {len(data.get('nodes', []))} nodes, {len(data.get('edges', []))} edges")
                    return data
                else:
                    print("Simple query returned no data")
                    return {'nodes': [], 'edges': []}
                    
        except Exception as e:
            print(f"Simple query failed: {e}")
            return {'nodes': [], 'edges': []}

    def create_query_working(self, opening_statement: str, collection_statement: str, has_field_consultant: bool = False) -> str:
        """Completely working query with proper Cypher syntax."""
        if has_field_consultant:
            where_clause = " WHERE a.region = $region AND c.region = $region AND d.region = $region AND b.region = $region"
        else:
            where_clause = " WHERE a.region = $region AND c.region = $region AND d.region = $region"
            # Handle cases where 'a' might not exist (company-product only queries)
            if "a:" not in opening_statement:
                where_clause = " WHERE c.region = $region AND d.region = $region"
        
        opening_with_filter = opening_statement + where_clause
        
        return f"""
        {opening_with_filter}
        {collection_statement}
        WITH [node IN allNodes WHERE node IS NOT NULL AND node.name IS NOT NULL AND node.id IS NOT NULL] AS filteredNodes, allRels
        WITH filteredNodes, [rel IN allRels WHERE rel IS NOT NULL AND startNode(rel) IN filteredNodes AND endNode(rel) IN filteredNodes] AS filteredRelationships
        RETURN {{
            nodes: [node IN filteredNodes | {{
                data: {{
                    name: node.name,
                    node_name: node.id,
                    label: labels(node)[0],
                    id: node.id,
                    region: node.region,
                    sales_region: node.sales_region,
                    channel: node.channel,
                    asset_class: node.asset_class,
                    privacy: node.privacy,
                    jpm_flag: node.jpm_flag,
                    pca: node.pca,
                    aca: node.aca
                }}
            }}],
            edges: [rel IN filteredRelationships | {{
                data: {{
                    id: toString(id(rel)),
                    source: startNode(rel).id,
                    target: endNode(rel).id,
                    label: type(rel),
                    rankgroup: rel.rankgroup,
                    level_of_influence: rel.level_of_influence,
                    mandate_status: rel.mandate_status
                }}
            }}]
        }} AS Relationships
        """
        """Build the complete query with region filter - FIXED VERSION."""
        where_clause = " WHERE a.region = $region AND c.region = $region AND d.region = $region"
        if "b" in opening_statement:
            where_clause += " AND b.region = $region"
        
        opening_with_filter = opening_statement + where_clause
        
        return f"""
        {opening_with_filter}
        {collection_statement}
        UNWIND allNodes AS node
        WITH COLLECT(CASE WHEN node.name IS NOT NULL AND node.id IS NOT NULL THEN node ELSE null END) AS validNodes, allRels
        WITH [node IN validNodes WHERE node IS NOT NULL] AS filteredNodes, allRels
        WITH filteredNodes, [rel IN allRels WHERE startNode(rel) IN filteredNodes AND endNode(rel) IN filteredNodes] AS filteredRelationships
        WITH [node IN filteredNodes | {{
            data: {{
                name: node.name, 
                node_name: node.id, 
                label: labels(node)[0],
                region: node.region,
                sales_region: node.sales_region,
                channel: node.channel,
                asset_class: node.asset_class,
                privacy: node.privacy,
                jpm_flag: node.jpm_flag,
                pca: node.pca,
                aca: node.aca,
                mandate_status: node.mandate_status
            }}
        }}] AS nodeData,
        [rel IN filteredRelationships | {{
            data: {{
                id: toString(id(rel)),
                source: startNode(rel).id, 
                target: endNode(rel).id, 
                label: type(rel),
                rankgroup: rel.rankgroup,
                level_of_influence: rel.level_of_influence,
                mandate_status: rel.mandate_status
            }}
        }}] AS relData
        RETURN {{nodes: nodeData, edges: relData}} AS Relationships
        """
    
    def execute_single_query(self, session: Session, query: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a single query and return the result."""
        try:
            result = session.run(query, parameters)
            records = list(result)
            
            if records:
                # The Neo4j record contains our 'Relationships' key
                record = records[0]
                return {'nodes': record['Relationships']['nodes'], 'edges': record['Relationships']['edges']}
                if 'Relationships' in record:
                    relationships_data = record['Relationships']
                    
                    # Extract the actual data
                    nodes = relationships_data.get('nodes', [])
                    edges = relationships_data.get('edges', [])
                    
                    print(f"Query returned: {len(nodes)} nodes, {len(edges)} edges")
                    
                    # Debug: Show what types of nodes we got
                    node_types = {}
                    for node in nodes:
                        if 'data' in node and 'label' in node['data']:
                            label = node['data']['label']
                            node_types[label] = node_types.get(label, 0) + 1
                    
                    if node_types:
                        print(f"Node types: {node_types}")
                    
                    return {'nodes': record['Relationships']['nodes'], 'edges': record['Relationships']['edges']}
                else:
                    print(f"No 'Relationships' key found in result. Available keys: {list(record.keys())}")
                    return {'nodes': [], 'edges': []}
            else:
                print("Query returned no records")
                return {'nodes': [], 'edges': []}
                
        except Exception as e:
            print(f"Query execution error: {e}")
            return {'nodes': [], 'edges': []}
    
    def union_query_results(self, *args) -> Dict[str, Any]:
        """Union multiple query results as per your existing logic."""
        if len(args) == 1:
            return args[0]
        
        if not args or not any(args):
            return {'nodes': [], 'edges': []}
        
        # Get first non-empty result as base
        base_result = None
        for result in args:
            if result and ('nodes' in result or 'edges' in result):
                base_result = result
                break
        
        if not base_result:
            return {'nodes': [], 'edges': []}
        
        nodes = list(base_result.get('nodes', []))
        edges = list(base_result.get('edges', []))
        
        existing_node_ids = {node.get('data', {}).get('id') for node in nodes if node.get('data', {}).get('id')}
        existing_rel_ids = {rel.get('data', {}).get('id') for rel in edges if rel.get('data', {}).get('id')}
        
        # Union with remaining results
        for result in args[1:]:
            if not result:
                continue
                
            for node in result.get('nodes', []):
                node_id = node.get('data', {}).get('id')
                if node_id and node_id not in existing_node_ids:
                    nodes.append(node)
                    existing_node_ids.add(node_id)
            
            for rel in result.get('edges', []):
                rel_id = rel.get('data', {}).get('id')
                if rel_id and rel_id not in existing_rel_ids:
                    edges.append(rel)
                    existing_rel_ids.add(rel_id)
        
        return {'nodes': nodes, 'edges': edges}
    
    def get_param_filter_list_by_node_type(self, param_name: str, elements: List[Dict], node_type: str, unique_only: bool = False) -> List[str]:
        """
        Enhanced helper function to extract parameter values from specific node types.
        """
        values = []
        matching_nodes = 0
        total_nodes = len([e for e in elements if isinstance(e, dict) and e.get('labels')])
        
        print(f"🔍 DEBUG: Searching for '{param_name}' in {node_type} nodes from {total_nodes} total nodes")
        
        for element in elements:
            if isinstance(element, dict):
                # Check if this element matches the desired node type
                labels = element.get('labels', [])
                if node_type in labels:
                    matching_nodes += 1
                    props = element.get('properties', {})
                    # Safely get the property value
                    if param_name in props and props[param_name] is not None and props[param_name] != "":
                        values.append(str(props[param_name]))
                        print(f"  ✅ Found '{param_name}': {props[param_name]} in {node_type} node {props.get('name', props.get('id', 'unknown'))}")
        
        print(f"📊 DEBUG: Found {matching_nodes} {node_type} nodes, extracted {len(values)} '{param_name}' values")
        
        if unique_only:
            original_count = len(values)
            values = list(set(values))
            print(f"🔧 DEBUG: Deduplicated {original_count} values to {len(values)} unique values")
        
        # Filter out empty strings and None values
        filtered_values = [v for v in values if v and v != "null"]
        if len(filtered_values) != len(values):
            print(f"🧹 DEBUG: Filtered out {len(values) - len(filtered_values)} empty/null values")
        
        final_values = sorted(filtered_values)
        print(f"✅ DEBUG: Final {param_name} list for {node_type}: {len(final_values)} values")
        
        return final_values
    
    def get_param_filter_list(self, param_name: str, elements: List[Dict], unique_only: bool = False) -> List[str]:
        """
        Helper function to extract unique parameter values from elements.
        ENHANCED with debug prints.
        """
        values = []
        processed_elements = 0
        
        print(f"🔍 DEBUG: Extracting '{param_name}' from {len(elements)} elements")
        
        for element in elements:
            if isinstance(element, dict):
                processed_elements += 1
                props = element.get('properties', {})
                # Safely get the property value
                if param_name in props and props[param_name] is not None and props[param_name] != "":
                    values.append(str(props[param_name]))
        
        print(f"📊 DEBUG: Processed {processed_elements} elements, found {len(values)} '{param_name}' values")
        
        if unique_only:
            original_count = len(values)
            values = list(set(values))
            print(f"🔧 DEBUG: Deduplicated {original_count} values to {len(values)} unique values")
        
        # Filter out empty strings and None values
        filtered_values = [v for v in values if v and v != "null"]
        if len(filtered_values) != len(values):
            print(f"🧹 DEBUG: Filtered out {len(values) - len(filtered_values)} empty/null values")
        
        final_values = sorted(filtered_values)
        print(f"✅ DEBUG: Final {param_name} list: {len(final_values)} values - {final_values[:5]}{'...' if len(final_values) > 5 else ''}")
        
        return final_values
    
    def get_node_filter_list(self, node_type: str, elements: List[Dict]) -> List[Dict[str, str]]:
        """
        Helper function to get node filter list with id and name.
        ENHANCED with debug prints.
        """
        nodes = []
        matching_nodes = 0
        total_elements = len(elements)
        
        print(f"🔍 DEBUG: Searching for {node_type} nodes in {total_elements} elements")
        
        for element in elements:
            if isinstance(element, dict):
                labels = element.get('labels', [])
                if node_type in labels:
                    matching_nodes += 1
                    props = element.get('properties', {})
                    if props.get('name'):
                        nodes.append({
                            "id": element.get('id', ''),
                            "name": props['name']
                        })
                        print(f"  ✅ Found {node_type}: {props['name']} (ID: {element.get('id', 'unknown')})")
        
        print(f"📊 DEBUG: Found {matching_nodes} {node_type} nodes, {len(nodes)} with valid names")
        
        # Remove duplicates based on id and sort by name
        seen_ids = set()
        unique_nodes = []
        for node in nodes:
            if node['id'] not in seen_ids:
                unique_nodes.append(node)
                seen_ids.add(node['id'])
        
        if len(unique_nodes) != len(nodes):
            print(f"🔧 DEBUG: Deduplicated {len(nodes)} nodes to {len(unique_nodes)} unique nodes")
        
        final_nodes = sorted(unique_nodes, key=lambda x: x['name'])
        print(f"✅ DEBUG: Final {node_type} list: {len(final_nodes)} nodes")
        
        return final_nodes
    
    def get_ca_names(self, region: str, market_options: List[str] = None) -> List[str]:
        """
        Retrieves client advisor names (PCAs and ACAs) from companies.
        Uses a special function that unwraps array properties.
        """
        with self.driver.session() as session:
            # Get PCAs and ACAs from companies in the region
            query = """
            MATCH (c:COMPANY {region: $region})
            WHERE c.pca IS NOT NULL OR c.aca IS NOT NULL
            WITH c.pca as pca, c.aca as aca
            UNWIND (CASE WHEN pca IS NOT NULL THEN [pca] ELSE [] END + 
                    CASE WHEN aca IS NOT NULL THEN [aca] ELSE [] END) as advisor
            RETURN DISTINCT advisor
            ORDER BY advisor
            """
            
            result = session.run(query, {"region": region})
            advisors = [record["advisor"] for record in result if record["advisor"]]
            
            return advisors
    
    def populate_filter_options(self, region_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Step 2: First-Level Filter Population - ENHANCED with Debug Prints and Fixed PCA/ACA Logic
        """
        region = region_data["metadata"]["region"]
        nodes = region_data["nodes"]
        relationships = region_data["relationships"]
        
        print(f"\n🚀 DEBUG: ===== FILTER POPULATION START =====")
        print(f"📍 DEBUG: Processing region: {region}")
        print(f"📊 DEBUG: Input data - {len(nodes)} nodes, {len(relationships)} relationships")
        
        # Extract node type breakdown
        node_type_counts = {}
        for node in nodes:
            labels = node.get("labels", [])
            for label in labels:
                node_type_counts[label] = node_type_counts.get(label, 0) + 1
        
        print(f"📈 DEBUG: Node type breakdown: {node_type_counts}")
        
        # Extract companies and consultants for reference
        companies = [node for node in nodes if "COMPANY" in node.get("labels", [])]
        consultants = [node for node in nodes if "CONSULTANT" in node.get("labels", [])]
        
        print(f"🏢 DEBUG: Found {len(companies)} companies")
        print(f"👨‍💼 DEBUG: Found {len(consultants)} consultants")
        
        filter_options = {}
        
        print(f"\n📋 DEBUG: ===== POPULATING FILTERS =====")
        
        # 1. Markets List
        print(f"🌍 DEBUG: 1. Extracting markets (sales_region from companies)...")
        filter_options["markets"] = self.get_param_filter_list('sales_region', companies, True)
        
        # 2. Channels List
        print(f"📺 DEBUG: 2. Extracting channels (channel from companies)...")
        filter_options["channels"] = self.get_param_filter_list('channel', companies, True)
        
        # 3. Field Consultants
        print(f"👥 DEBUG: 3. Extracting field consultants...")
        filter_options["field_consultants"] = self.get_node_filter_list('FIELD_CONSULTANT', nodes)
        
        # 4. Products
        print(f"📦 DEBUG: 4. Extracting products...")
        filter_options["products"] = self.get_node_filter_list('PRODUCT', nodes)
        
        # 5. Companies
        print(f"🏢 DEBUG: 5. Extracting companies...")
        filter_options["companies"] = self.get_node_filter_list('COMPANY', nodes)
        
        # 6. Consultants
        print(f"👨‍💼 DEBUG: 6. Extracting consultants...")
        filter_options["consultants"] = self.get_node_filter_list('CONSULTANT', nodes)
        
        # 7. Consultant Rankings
        print(f"🏆 DEBUG: 7. Extracting consultant rankings (rankgroup from relationships)...")
        filter_options["consultant_rankings"] = self.get_param_filter_list('rankgroup', relationships, True)
        
        # 8. Influence Levels
        print(f"💪 DEBUG: 8. Extracting influence levels (level_of_influence from relationships)...")
        filter_options["influence_levels"] = self.get_param_filter_list('level_of_influence', relationships, True)
        
        # 9. Asset Classes
        print(f"💼 DEBUG: 9. Extracting asset classes (asset_class from products)...")
        products_only = [node for node in nodes if "PRODUCT" in node.get("labels", [])]
        print(f"   📊 DEBUG: Processing {len(products_only)} product nodes for asset classes")
        filter_options["asset_classes"] = self.get_param_filter_list('asset_class', products_only, True)
        
        # 10. ENHANCED: Client Advisors (Company PCA + ACA) Logic
        print(f"\n👥 DEBUG: 10. ENHANCED PCA/ACA LOGIC - Client Advisors (Company PCA + ACA)...")
        company_pcas = self.get_param_filter_list_by_node_type('pca', nodes, 'COMPANY', False)
        company_acas = self.get_param_filter_list_by_node_type('aca', nodes, 'COMPANY', False)
        filter_options["client_advisors"] = sorted(list(set(company_pcas + company_acas)))
        print(f"   ✅ DEBUG: Combined {len(company_pcas)} Company PCAs + {len(company_acas)} Company ACAs = {len(filter_options['client_advisors'])} Client Advisors")
        
        # 11. ENHANCED: Consultant Advisors (Consultant PCA + Consultant Advisor) Logic
        print(f"👨‍💼 DEBUG: 11. ENHANCED PCA/ACA LOGIC - Consultant Advisors (Consultant PCA + Advisor)...")
        consultant_pcas = self.get_param_filter_list_by_node_type('pca', nodes, 'CONSULTANT', False)
        consultant_advisors = self.get_param_filter_list_by_node_type('consultant_advisor', nodes, 'CONSULTANT', False)
        filter_options["consultant_advisors"] = sorted(list(set(consultant_pcas + consultant_advisors)))
        print(f"   ✅ DEBUG: Combined {len(consultant_pcas)} Consultant PCAs + {len(consultant_advisors)} Consultant Advisors = {len(filter_options['consultant_advisors'])} Consultant Advisors")
        
        # Legacy PCA/ACA for backward compatibility
        print(f"🔄 DEBUG: 12. Legacy PCA/ACA extraction for backward compatibility...")
        filter_options["pcas"] = self.get_param_filter_list('pca', nodes, True)
        filter_options["acas"] = self.get_param_filter_list('aca', nodes, True)
        
        # Additional filters
        print(f"📋 DEBUG: 13. Additional filters...")
        filter_options["mandate_statuses"] = self.get_param_filter_list('mandate_status', relationships, True)
        filter_options["privacy_levels"] = self.get_param_filter_list('privacy', companies, True)
        filter_options["jmp_flags"] = self.get_param_filter_list('jmp_flag', nodes, True)
        
        print(f"\n📊 DEBUG: ===== FILTER POPULATION SUMMARY =====")
        for key, value in filter_options.items():
            count = len(value) if isinstance(value, list) else 0
            print(f"   {key}: {count} options")
        
        total_options = sum(len(options) if isinstance(options, list) else 0 for options in filter_options.values())
        print(f"🎯 DEBUG: Total filter options generated: {total_options}")
        print(f"✅ DEBUG: ===== FILTER POPULATION COMPLETE =====\n")
        
        return {
            "region": region,
            "filter_options": filter_options,
            "metadata": {
                "total_options_count": total_options,
                "populated_at": time.time(),
                "source_node_count": len(nodes),
                "source_relationship_count": len(relationships),
                "node_type_breakdown": node_type_counts,
                "pca_aca_breakdown": {
                    "company_pcas": len(company_pcas),
                    "company_acas": len(company_acas),
                    "consultant_pcas": len(consultant_pcas),
                    "consultant_advisors": len(consultant_advisors),
                    "client_advisors_total": len(filter_options["client_advisors"]),
                    "consultant_advisors_total": len(filter_options["consultant_advisors"])
                }
            }
        }
    
    
    def get_region_with_filters(self, region: str) -> Dict[str, Any]:
        """
        Complete workflow: Get region data and populate filters.
        This is the main function that implements the hierarchical approach.
        """
        try:
            # Step 1: Initial Region Selection - Get ALL data for region
            print(f"Step 1: Getting all data for region {region}")
            region_data = self.get_region_data(region)
            
            # Step 2: First-Level Filter Population - Extract filter options
            print(f"Step 2: Populating filters based on {region} data")
            filter_data = self.populate_filter_options(region_data)
            
            return {
                "success": True,
                "region": region,
                "data": region_data,
                "filters": filter_data["filter_options"],
                "metadata": {
                    "region_metadata": region_data["metadata"],
                    "filter_metadata": filter_data["metadata"],
                    "workflow_completed_at": time.time()
                }
            }
            
        except Exception as e:
            return {
                "success": False,
                "region": region,
                "error": str(e),
                "metadata": {
                    "error_at": time.time()
                }
            }
    
    def change_region(self, new_region: str) -> Dict[str, Any]:
        """
        Step 3: Region Change Handler - FIXED
        When region changes → fetch new data → update all filters
        """
        print(f"Region changed to {new_region} - fetching new data and updating filters")
        # FIXED: Just call the complete workflow
        return self.get_region_with_filters(new_region)
    
    def get_available_regions(self) -> List[str]:
        """Get list of available regions."""
        return REGIONS
    
    def validate_region(self, region: str) -> bool:
        """Validate if region is supported."""
        return region.upper() in REGIONS


# Global service instance
hierarchical_filter_service = HierarchicalFilterService()